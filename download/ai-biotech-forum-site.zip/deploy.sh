#!/bin/bash
# Deploy to GitHub Pages (static HTML)
# 1. Push index.html to GitHub
# 2. Enable GitHub Pages in repo settings
# 3. Site will be live at https://<username>.github.io/<repo>/

# For the interactive demo (Streamlit):
# Push to Streamlit Cloud separately
echo "Static site: deploy index.html to GitHub Pages"
echo "Interactive demo: deploy demo-app.py to Streamlit Cloud"
