
<div align="center">

# TWC-FL Platform

### 三元催化配方联邦学习协作平台

**PyTorch FedAvg + Bayesian Optimization + Vector Search + Streamlit Dashboard**

[![Python](https://img.shields.io/badge/Python-3.10+-blue?logo=python)](https://python.org/)
[![PyTorch](https://img.shields.io/badge/PyTorch-2.0+-ee4c2c?logo=pytorch)](https://pytorch.org/)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.30+-red?logo=streamlit)](https://streamlit.io/)
[![Plotly](https://img.shields.io/badge/Plotly-5.18+-4479A1?logo=plotly)](https://plotly.com/)


</div>

---

## 🎯 What is TWC-FL Platform?

TWC-FL Platform 是面向**三元催化（Three-Way Catalytic converter）**行业的联邦学习协作平台，让多家催化剂企业在**配方数据不出厂**的前提下联合训练AI预测模型，实现全行业共享模型进步、同时单家企业独守配方机密的双赢格局。

### 核心功能

| Module | Description |
|--------|-------------|
| 🏠 Dashboard | 平台概览、关键指标、快速操作 |
| 📁 Data Vault | 配方数据导入（CSV/Excel/JSON）、脱敏、质量报告 |
| 📚 Knowledge Hub | TWC领域知识库（20+ FAQ）、文献参考、配方推荐 |
| 🧪 Bayesian Optimizer | 基于贝叶斯优化的智能实验推荐 |
| 🔄 FL Training | 跨企业联邦学习训练（FedAvg），实时可视化 |
| 🔍 Vector Search | 配方相似度向量检索 |
| ⛓️ Audit Chain | 区块链式不可篡改审计日志 |
| 📖 Research | 方法论、论文引用、团队介绍 |

### 预测目标

| Target | Description | Euro 6d / China 6b |
|--------|-------------|-------------------|
| CO Conv | CO转化率 | ≥ 94% |
| HC Conv | HC转化率 | ≥ 94% |
| NOx Conv | NOx转化率 | ≥ 90% |
| T50 | 起燃温度 | 180-260°C |

---

## 🚀 Quick Start

### Local
```bash
pip install -r requirements.txt
streamlit run app.py
# Open http://localhost:8501
```

### Streamlit Community Cloud (Free)
1. Push to GitHub
2. Go to [share.streamlit.io](https://share.streamlit.io/)
3. Connect repo → deploy
4. Get `https://your-app.streamlit.app`

---

## 🏗️ Architecture

```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│ Enterprise A │    │ Enterprise B │    │ Enterprise C │
│ (配方数据)    │    │ (配方数据)    │    │ (配方数据)    │
└──────┬──────┘    └──────┬──────┘    └──────┬──────┘
       │                  │                  │
       │  模型梯度 (加密上传)                   │
       │  (配方数据不出厂)                      │
       └──────────────┬──────────────────────┘
                      │
              ┌───────┴───────┐
              │  FedAvg Server │
              │  模型聚合       │
              └───────┬───────┘
                      │
         ┌────────────┼────────────┐
         ▼            ▼            ▼
    ┌─────────┐ ┌─────────┐ ┌─────────┐
    │ FL Engine│ │ Bayesian│ │ Vector  │
    │ 催化预测 │ │ 实验推荐 │ │ 配方检索 │
    └─────────┘ └─────────┘ └─────────┘
```

---

## 📁 Project Structure

```
organoid-fl/
├── app.py                    # Streamlit 入口
├── requirements.txt          # Python 依赖
├── modules/                  # Streamlit 页面模块
│   ├── dashboard.py          # 🏠 平台概览
│   ├── data_vault.py         # 📁 配方数据管理
│   ├── knowledge_hub.py      # 📚 领域知识库
│   ├── bayesian_optimizer.py # 🧪 贝叶斯优化
│   ├── fl_training.py        # 🔄 FL 训练
│   ├── vector_search.py      # 🔍 向量检索
│   ├── audit_chain.py        # ⛓️ 审计链
│   └── research.py           # 📖 研究基础
├── analysis/                 # 核心分析引擎
│   ├── fl_engine.py          # FedAvg 联邦学习引擎
│   ├── bayesian_optimizer.py # 贝叶斯优化器
│   ├── knowledge_hub.py      # TWC 知识库
│   ├── vector_engine.py      # 向量搜索引擎
│   └── audit_engine.py       # SHA-256 审计链
├── visualization/            # Plotly 图表
│   └── charts.py
├── utils/                    # 工具
│   ├── constants.py          # 配置与常量
│   └── helpers.py            # 辅助函数
└── tests/                    # 测试
```

---

## 👥 Team

| Role | Name | Responsibility |
|------|------|----------------|
| PI | 徐德昌 | 整体把控、产业对接 |
| FL框架 | 高丽娜 | FL框架、Bayesian优化 |
| 系统架构 | 张凯 | 系统架构、AI Agent |
| 硬件对接 | 朱丽虹 | 硬件平台对接 |
| 企业对接 | 陈东敏 | 企业对接、项目管理 |

**单位**: 西交利物浦大学人工智能学院

---

## 📄 License

MIT

---

<div align="center">

**TWC-FL Platform** — 配方数据不出厂，模型进步全行业共享


</div>
