# ── modules/compliance.py ──
"""
排放法规合规检查模块

功能：
    - 多标准合规检查（Euro 6d/7, China 6b/7）
    - 差距分析与改进建议
    - 老化后性能预测
    - PGE 载量参考检查
    - 多标准雷达图对比
"""

import streamlit as st
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from analysis.compliance_engine import ComplianceEngine, REGULATIONS


def render():
    st.markdown("## 📜 排放法规合规检查")

    if "compliance_engine" not in st.session_state:
        st.session_state["compliance_engine"] = ComplianceEngine()

    engine: ComplianceEngine = st.session_state["compliance_engine"]

    # ── 法规概览 ──
    _render_regulation_overview()

    st.divider()

    # ── Tab 布局 ──
    tab1, tab2, tab3 = st.tabs(["🔍 合规检查", "📉 老化预测", "⚖️ PGE 载量"])

    with tab1:
        _render_compliance_check(engine)
    with tab2:
        _render_aging_prediction(engine)
    with tab3:
        _render_pge_check(engine)


def _render_regulation_overview():
    """法规概览卡片。"""
    st.markdown("### 支持的排放标准")

    cols = st.columns(4)
    for i, (name, reg) in enumerate(REGULATIONS.items()):
        with cols[i]:
            st.markdown(f"**{name}**")
            st.caption(reg.description)
            st.markdown(f"- CO ≥ {reg.co_min}%")
            st.markdown(f"- HC ≥ {reg.hc_min}%")
            st.markdown(f"- NOx ≥ {reg.nox_min}%")
            st.markdown(f"- T50 ≤ {reg.t50_max}°C")
            st.markdown(f"- 耐久 {reg.durability_km // 1000}k km")


def _render_compliance_check(engine: ComplianceEngine):
    """合规检查。"""
    features, targets = _get_data()
    if features is None:
        return

    col_a, col_b = st.columns(2)
    with col_a:
        reg_name = st.selectbox("选择排放标准", list(REGULATIONS.keys()), index=1)
    with col_b:
        formula_idx = st.number_input("配方索引", 0, len(features) - 1, 0)

    result = engine.check_compliance(targets[formula_idx], reg_name)

    # 总体结果
    if result.all_pass:
        st.success(f"✅ 配方 {formula_idx} 完全满足 **{reg_name}** 标准！")
    else:
        n_fail = sum([not result.co_pass, not result.hc_pass, not result.nox_pass, not result.t50_pass])
        st.warning(f"⚠️ 配方 {formula_idx} 有 **{n_fail}** 项不满足 **{reg_name}** 标准")

    # 详细结果
    items = [
        ("CO 转化率", f"{targets[formula_idx][0]:.1f}%", f"≥ {REGULATIONS[reg_name].co_min}%", result.co_pass, result.co_gap),
        ("HC 转化率", f"{targets[formula_idx][1]:.1f}%", f"≥ {REGULATIONS[reg_name].hc_min}%", result.hc_pass, result.hc_gap),
        ("NOx 转化率", f"{targets[formula_idx][2]:.1f}%", f"≥ {REGULATIONS[reg_name].nox_min}%", result.nox_pass, result.nox_gap),
        ("T50 起燃温度", f"{targets[formula_idx][3]:.0f}°C", f"≤ {REGULATIONS[reg_name].t50_max}°C", result.t50_pass, result.t50_gap),
    ]

    cols = st.columns(4)
    for i, (metric, actual, required, passed, gap) in enumerate(items):
        with cols[i]:
            icon = "✅" if passed else "❌"
            st.markdown(f"**{icon} {metric}**")
            st.markdown(f"当前值: **{actual}**")
            st.markdown(f"要求值: {required}")
            gap_str = f"+{gap:.1f}" if gap >= 0 else f"{gap:.1f}"
            color = "green" if passed else "red"
            st.markdown(f"差距: :{color}[{gap_str}]")

    # 改进建议
    if not result.all_pass:
        st.divider()
        st.markdown("### 💡 改进建议")
        suggestions = engine.get_improvement_suggestions(features[formula_idx], targets[formula_idx], reg_name)
        for s in suggestions:
            severity_icon = "🔴" if s["severity"] == "high" else "🟡"
            st.markdown(f"{severity_icon} **{s['target']}**: {s['suggestion']}")

    # 多标准雷达图
    st.divider()
    _render_multi_standard_radar(targets[formula_idx])


def _render_multi_standard_radar(targets: np.ndarray):
    """多标准雷达图。"""
    categories = ["CO 转化率", "HC 转化率", "NOx 转化率", "T50 (反转)"]
    actual = [targets[0], targets[1], targets[2], 100 - (targets[3] - 150) / 1.5]

    fig = go.Figure()
    fig.add_trace(go.Scatterpolar(
        r=actual + [actual[0]], theta=categories + [categories[0]],
        fill="toself", name="当前配方", line_color="#3b82f6", linewidth=2,
    ))

    colors = {"Euro 6d": "#22c55e", "Euro 7": "#ef4444", "China 6b": "#3b82f6", "China 7": "#f59e0b"}
    for name, reg in REGULATIONS.items():
        req = [reg.co_min, reg.hc_min, reg.nox_min, 100 - (reg.t50_max - 150) / 1.5]
        fig.add_trace(go.Scatterpolar(
            r=req + [req[0]], theta=categories + [categories[0]],
            fill="toself", name=name, line_color=colors.get(name, "#999"),
            opacity=0.15, line=dict(dash="dash"),
        ))

    fig.update_layout(
        polar=dict(radialaxis=dict(visible=True, range=[80, 100])),
        template="plotly_white", height=450,
        legend=dict(orientation="h", yanchor="bottom", y=1.02),
        title="多标准合规雷达图",
    )
    st.plotly_chart(fig, use_container_width=True)


def _render_aging_prediction(engine: ComplianceEngine):
    """老化后性能预测。"""
    features, targets = _get_data()
    if features is None:
        return

    col_a, col_b = st.columns(2)
    with col_a:
        formula_idx = st.number_input("配方索引（老化预测）", 0, len(features) - 1, 0, key="aging_idx")
    with col_b:
        reg_name = st.selectbox("目标标准（老化预测）", list(REGULATIONS.keys()), index=1, key="aging_reg")

    predictions = engine.predict_aging(features[formula_idx], targets[formula_idx])

    # 衰减曲线
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=("CO 转化率衰减", "HC 转化率衰减", "NOx 转化率衰减", "T50 变化"),
        vertical_spacing=0.12, horizontal_spacing=0.12,
    )

    km_points = [p.km for p in predictions]
    km_labels = [p.stage for p in predictions]
    co_vals = [p.co_conv for p in predictions]
    hc_vals = [p.hc_conv for p in predictions]
    nox_vals = [p.nox_conv for p in predictions]
    t50_vals = [p.t50 for p in predictions]

    all_series = [
        (co_vals, "CO", "#3b82f6", reg_name and REGULATIONS[reg_name].co_min),
        (hc_vals, "HC", "#22c55e", reg_name and REGULATIONS[reg_name].hc_min),
        (nox_vals, "NOx", "#ef4444", reg_name and REGULATIONS[reg_name].nox_min),
        (t50_vals, "T50", "#f59e0b", reg_name and REGULATIONS[reg_name].t50_max),
    ]

    for t_idx, (values, key, color, limit) in enumerate(all_series):
        row, col = t_idx // 2 + 1, t_idx % 2 + 1
        fig.add_trace(go.Scatter(
            x=km_points, y=values, mode="lines+markers",
            line=dict(color=color, width=2), marker=dict(size=8),
            name=key,
        ), row=row, col=col)

        if limit:
            fig.add_hline(
                y=limit, line_dash="dash", line_color="red",
                annotation_text=f"{reg_name} 限值",
                row=row, col=col,
            )

    fig.update_layout(template="plotly_white", height=600, showlegend=False)
    fig.update_xaxes(title_text="里程 (km)")
    st.plotly_chart(fig, use_container_width=True)

    # 老化后合规表
    st.markdown("### 老化后合规状态")
    rows = []
    for pred in predictions:
        pred_targets = np.array([pred.co_conv, pred.hc_conv, pred.nox_conv, pred.t50])
        check = engine.check_compliance(pred_targets, reg_name)
        rows.append({
            "阶段": pred.stage,
            "里程": f"{pred.km // 1000}k km",
            "CO": f"{pred.co_conv:.1f}%",
            "HC": f"{pred.hc_conv:.1f}%",
            "NOx": f"{pred.nox_conv:.1f}%",
            "T50": f"{pred.t50:.0f}°C",
            "合规": "✅" if check.all_pass else "❌",
        })

    df = pd.DataFrame(rows)
    st.dataframe(df, use_container_width=True, hide_index=True)


def _render_pge_check(engine: ComplianceEngine):
    """PGE 载量检查。"""
    features, targets = _get_data()
    if features is None:
        return

    col_a, col_b = st.columns(2)
    with col_a:
        reg_name = st.selectbox("参考标准（PGE）", list(REGULATIONS.keys()), index=1, key="pge_reg")
    with col_b:
        formula_idx = st.number_input("配方索引（PGE）", 0, len(features) - 1, 0, key="pge_idx")

    result = engine.check_pge_loading(features[formula_idx], reg_name)

    cols = st.columns(3)
    for i, (elem, info) in enumerate(result.items()):
        with cols[i]:
            st.markdown(f"**{elem}**")
            st.markdown(f"当前载量: **{info['loading']} g/L**")
            st.markdown(f"参考范围: {info['ref_range'][0]}-{info['ref_range'][1]} g/L")
            st.markdown(info["status"])


def _get_data():
    """获取当前数据。"""
    if "features" not in st.session_state or "targets" not in st.session_state:
        st.info("📦 请先在「数据管理」模块导入配方数据，或使用「联邦训练」生成合成数据。")
        return None, None
    return st.session_state["features"], st.session_state["targets"]
