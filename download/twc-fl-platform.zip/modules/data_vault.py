# ── modules/data_vault.py ──
"""
Data Vault Page
===============
配方数据管理：导入、脱敏、质量报告、预览。
"""

import streamlit as st
import numpy as np
import pandas as pd
from io import StringIO
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from utils.constants import CATALYST_COMPONENTS, PREDICTION_TARGETS, COLORS
from utils.helpers import features_to_dataframe, targets_to_dataframe, check_compliance


def render():
    st.markdown(
        '<div class="main-header"><h1>📁 Data Vault — 配方数据管理</h1>'
        '<p>导入、脱敏、质量检查催化剂配方数据</p></div>',
        unsafe_allow_html=True,
    )

    tab_import, tab_demo, tab_quality = st.tabs([
        "📤 Import Data", "🧪 Demo Data", "📊 Quality Report"
    ])

    with tab_import:
        _render_import()

    with tab_demo:
        _render_demo()

    with tab_quality:
        _render_quality()


def _render_import():
    """Import CSV/Excel/JSON formula data."""
    st.subheader("Import Formula Data")
    st.markdown("Upload catalyst formula data in CSV, Excel, or JSON format.")

    uploaded = st.file_uploader(
        "Choose file",
        type=["csv", "xlsx", "xls", "json"],
        help="Supported: CSV, Excel (.xlsx/.xls), JSON",
    )

    if uploaded:
        try:
            if uploaded.name.endswith(".csv"):
                df = pd.read_csv(uploaded)
            elif uploaded.name.endswith((".xlsx", ".xls")):
                df = pd.read_excel(uploaded)
            elif uploaded.name.endswith(".json"):
                df = pd.read_json(uploaded)
            else:
                st.error("Unsupported format")
                return

            st.success(f"✅ Loaded {len(df)} rows × {len(df.columns)} columns from `{uploaded.name}`")
            st.dataframe(df.head(20), use_container_width=True)

            # Auto-detect column types
            st.subheader("📋 Column Detection")
            numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
            text_cols = df.select_dtypes(include=['object']).columns.tolist()

            col1, col2 = st.columns(2)
            with col1:
                st.markdown(f"**Numeric columns** ({len(numeric_cols)}):")
                st.write(", ".join(numeric_cols[:10]))
                if len(numeric_cols) > 10:
                    st.write(f"... and {len(numeric_cols) - 10} more")
            with col2:
                st.markdown(f"**Text columns** ({len(text_cols)}):")
                st.write(", ".join(text_cols[:10]))

            # Store in session
            st.session_state["imported_data"] = df
            st.session_state["formula_count"] = len(df)

        except Exception as e:
            st.error(f"❌ Failed to parse file: {e}")

    # Manual entry
    st.markdown("---")
    st.subheader("✏️ Manual Entry")
    st.markdown("Or enter a single formula manually:")

    col1, col2, col3 = st.columns(3)
    with col1:
        pt = st.number_input("Pt (g/L)", 0.0, 10.0, 2.0, 0.1)
        pd_val = st.number_input("Pd (g/L)", 0.0, 15.0, 4.0, 0.1)
        rh = st.number_input("Rh (g/L)", 0.0, 1.0, 0.15, 0.01)
    with col2:
        ceo2 = st.number_input("CeO₂ (g/L)", 0, 300, 120, 5)
        zro2 = st.number_input("ZrO₂ (g/L)", 0, 150, 50, 5)
        al2o3 = st.number_input("Al₂O₃ (g/L)", 0, 350, 180, 10)
    with col3:
        calc_temp = st.number_input("Calcination (°C)", 300, 800, 550, 10)
        aging_temp = st.number_input("Aging (°C)", 600, 1200, 950, 10)

    if st.button("Add Formula", type="primary"):
        formula = {
            "Pt (g/L)": pt, "Pd (g/L)": pd_val, "Rh (g/L)": rh,
            "CeO₂ (g/L)": ceo2, "ZrO₂ (g/L)": zro2, "Al₂O₃ (g/L)": al2o3,
            "Calcination (°C)": calc_temp, "Aging (°C)": aging_temp,
        }
        if "manual_formulas" not in st.session_state:
            st.session_state["manual_formulas"] = []
        st.session_state["manual_formulas"].append(formula)
        st.success(f"✅ Formula added (total: {len(st.session_state['manual_formulas'])})")


def _render_demo():
    """Generate demo formula data."""
    st.subheader("Generate Demo Formula Data")
    st.markdown("Generate synthetic catalyst formula data for testing.")

    col1, col2 = st.columns(2)
    with col1:
        n_samples = st.slider("Number of formulas", 50, 1000, 200, step=50)
    with col2:
        noise_level = st.slider("Noise level", 0.01, 0.2, 0.05, step=0.01)

    if st.button("Generate", type="primary"):
        from utils.helpers import generate_synthetic_formulas, features_to_dataframe, targets_to_dataframe

        features, targets = generate_synthetic_formulas(n_samples=n_samples, noise=noise_level)
        df_features = features_to_dataframe(features)
        df_targets = targets_to_dataframe(targets)
        df = pd.concat([df_features, df_targets], axis=1)

        st.session_state["demo_features"] = features
        st.session_state["demo_targets"] = targets
        st.session_state["formula_count"] = n_samples

        st.success(f"✅ Generated {n_samples} formulas")

        tab_f, tab_t = st.tabs(["Formulas", "Performance"])
        with tab_f:
            st.dataframe(df_features.describe(), use_container_width=True)
        with tab_t:
            st.dataframe(df_targets.describe(), use_container_width=True)

            # Compliance check
            compliant = sum(1 for t in targets if check_compliance(t)["all_pass"])
            st.metric("Compliant Formulas", f"{compliant}/{n_samples}", f"{compliant/n_samples*100:.1f}%")


def _render_quality():
    """Data quality report."""
    st.subheader("Data Quality Report")

    if "imported_data" in st.session_state:
        df = st.session_state["imported_data"]
    elif "demo_features" in st.session_state:
        from utils.helpers import features_to_dataframe, targets_to_dataframe
        df = pd.concat([
            features_to_dataframe(st.session_state["demo_features"]),
            targets_to_dataframe(st.session_state["demo_targets"]),
        ], axis=1)
    else:
        st.info("No data loaded. Import data or generate demo data first.")
        return

    st.dataframe(df.head(10), use_container_width=True)

    # Quality checks
    st.subheader("🔍 Quality Checks")
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()

    checks = []

    # Missing values
    missing = df.isnull().sum()
    total_missing = missing.sum()
    if total_missing == 0:
        checks.append(("Missing Values", "✅ Pass", "No missing values"))
    else:
        checks.append(("Missing Values", "⚠️ Warning", f"{total_missing} missing values in {missing[missing > 0].shape[0]} columns"))

    # Duplicates
    n_dupes = df.duplicated().sum()
    if n_dupes == 0:
        checks.append(("Duplicates", "✅ Pass", "No duplicate rows"))
    else:
        checks.append(("Duplicates", "⚠️ Warning", f"{n_dupes} duplicate rows"))

    # Outliers (IQR method)
    outlier_counts = {}
    for col in numeric_cols:
        Q1, Q3 = df[col].quantile([0.25, 0.75])
        IQR = Q3 - Q1
        outliers = ((df[col] < Q1 - 3 * IQR) | (df[col] > Q3 + 3 * IQR)).sum()
        if outliers > 0:
            outlier_counts[col] = outliers

    if not outlier_counts:
        checks.append(("Outliers", "✅ Pass", "No extreme outliers detected"))
    else:
        checks.append(("Outliers", "⚠️ Warning", f"Outliers in {len(outlier_counts)} columns"))

    # Data size
    checks.append(("Data Size", "✅ Info", f"{len(df)} rows × {len(df.columns)} columns"))

    for name, status, detail in checks:
        st.markdown(f"**{name}**: {status} — {detail}")

    # Distribution charts
    if len(numeric_cols) > 0:
        st.subheader("📊 Feature Distributions")
        import plotly.graph_objects as go
        from plotly.subplots import make_subplots

        n_show = min(len(numeric_cols), 6)
        cols = 3
        rows = (n_show + cols - 1) // cols

        fig = make_subplots(rows=rows, cols=cols, subplot_titles=numeric_cols[:n_show])
        for i, col in enumerate(numeric_cols[:n_show]):
            r, c = i // cols + 1, i % cols + 1
            fig.add_trace(go.Histogram(x=df[col], nbinsx=30, marker_color=COLORS["primary"]), row=r, col=c)

        fig.update_layout(template="plotly_white", height=300 * rows, showlegend=False)
        st.plotly_chart(fig, use_container_width=True)
