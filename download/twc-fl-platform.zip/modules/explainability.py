# ── modules/explainability.py ──
"""
SHAP 可解释性分析模块

功能：
    - 特征重要性排序图
    - 单配方 Waterfall 解释
    - 特征分组贡献
    - 配方对比差异分析
"""

import streamlit as st
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from analysis.explainer import SHAPExplainer, FEATURE_NAMES, TARGET_NAMES, FEATURE_GROUPS


def render():
    st.markdown("## 🔬 SHAP 可解释性分析")

    if "explainer" not in st.session_state:
        st.session_state["explainer"] = SHAPExplainer()

    explainer: SHAPExplainer = st.session_state["explainer"]

    features, targets = _get_data()
    if features is None:
        return

    # 拟合解释器
    if not explainer._fitted:
        with st.spinner("🔄 正在计算特征重要性..."):
            explainer.fit(features, targets)
        st.success("✅ 解释器已就绪！")

    # ── Tab 布局 ──
    tab1, tab2, tab3 = st.tabs(["📊 特征重要性", "💧 Waterfall 解释", "🔄 配方对比"])

    with tab1:
        _render_feature_importance(explainer)
    with tab2:
        _render_waterfall(explainer, features, targets)
    with tab3:
        _render_formula_comparison(explainer, features)


def _render_feature_importance(explainer: SHAPExplainer):
    """特征重要性排序图。"""
    importance = explainer.get_feature_importance()

    # 选择目标
    target = st.selectbox("选择预测目标", TARGET_NAMES, index=0, key="shap_target")

    t_idx = TARGET_NAMES.index(target)
    values = [importance[i][t_idx] for i in range(len(FEATURE_NAMES))]

    # 排序
    sorted_idx = np.argsort(values)
    sorted_names = [FEATURE_NAMES[i] for i in sorted_idx]
    sorted_values = [values[i] for i in sorted_idx]

    # 颜色分组
    colors = []
    group_colors = {
        "贵金属": "#ef4444", "储氧材料": "#3b82f6",
        "助剂": "#22c55e", "工艺参数": "#f59e0b", "物理性质": "#8b5cf6",
    }
    for name in sorted_names:
        for group, indices in FEATURE_GROUPS.items():
            if FEATURE_NAMES.index(name) in indices:
                colors.append(group_colors[group])
                break

    fig = go.Figure(go.Bar(
        x=sorted_values,
        y=sorted_names,
        orientation="h",
        marker_color=colors,
        text=[f"{v:.4f}" for v in sorted_values],
        textposition="outside",
    ))

    fig.update_layout(
        xaxis_title="特征重要性 (排列重要性)",
        template="plotly_white",
        height=500,
        showlegend=False,
        margin=dict(l=200),
    )

    st.plotly_chart(fig, use_container_width=True)

    # 分组贡献
    st.markdown("### 特征分组贡献")
    grouped = explainer.get_grouped_importance()
    group_data = []
    for group_name, targets_imp in grouped.items():
        row = {"分组": group_name}
        for t_name, val in targets_imp.items():
            row[t_name] = val
        group_data.append(row)

    df = pd.DataFrame(group_data)
    st.dataframe(df, use_container_width=True, hide_index=True)


def _render_waterfall(explainer: SHAPExplainer, features: np.ndarray, targets: np.ndarray):
    """单配方 Waterfall 解释。"""
    formula_idx = st.number_input("配方索引", 0, len(features) - 1, 0, key="waterfall_idx")
    target = st.selectbox("预测目标", TARGET_NAMES, index=0, key="waterfall_target")
    t_idx = TARGET_NAMES.index(target)

    explanation = explainer.explain_single(features[formula_idx], targets[formula_idx:formula_idx+1])
    target_data = explanation[target]

    # Waterfall 图
    fig = go.Figure()

    contributions = target_data["contributions"]
    base_value = target_data["base_value"]

    n = len(contributions)
    x = list(range(n + 1))
    y = [base_value]
    for c_name, c_val in contributions:
        y.append(y[-1] + c_val)

    # 颜色
    bar_colors = []
    for c_name, c_val in contributions:
        bar_colors.append("#22c55e" if c_val >= 0 else "#ef4444")

    # 连接线
    fig.add_trace(go.Scatter(
        x=x, y=y, mode="lines",
        line=dict(color="#64748b", width=1, dash="dot"),
        showlegend=False,
    ))

    # 柱状图
    fig.add_trace(go.Bar(
        x=list(range(n)),
        y=[c_val for c_name, c_val in contributions],
        marker_color=bar_colors,
        text=[f"{c_val:+.3f}" for c_name, c_val in contributions],
        textposition="outside",
        name="特征贡献",
    ))

    fig.update_layout(
        xaxis_title="特征",
        template="plotly_white",
        height=500,
        showlegend=False,
    )

    # 自定义 x 轴标签
    fig.update_xaxes(
        tickmode="array",
        tickvals=list(range(n)),
        ticktext=[c_name for c_name, c_val in contributions],
    )

    st.plotly_chart(fig, use_container_width=True)

    # 解释文本
    st.markdown("### 📝 解释")
    st.markdown(f"**基准值**: {explanation['base_value']:.2f}")
    st.markdown(f"**预测值**: {explanation['prediction']:.2f}")

    # 正面/负面贡献排序
    positive = sorted(
        [c for c in explanation["contributions"] if c["value"] > 0],
        key=lambda c: c["value"], reverse=True,
    )
    negative = sorted(
        [c for c in explanation["contributions"] if c["value"] < 0],
        key=lambda c: c["value"],
    )

    col_p, col_n = st.columns(2)
    with col_p:
        st.markdown("#### 🟢 正面贡献")
        for c in positive[:5]:
            st.markdown(f"- **{c['feature']}**: +{c['value']:.3f}")
    with col_n:
        st.markdown("#### 🔴 负面贡献")
        for c in negative[:5]:
            st.markdown(f"- **{c['feature']}**: {c['value']:.3f}")


def _render_formula_comparison(explainer: SHAPExplainer, features: np.ndarray):
    """配方对比差异分析。"""
    col_a, col_b = st.columns(2)
    with col_a:
        idx_a = st.number_input("配方 A 索引", 0, len(features) - 1, 0, key="cmp_a")
    with col_b:
        idx_b = st.number_input("配方 B 索引", 0, len(features) - 1, min(1, len(features) - 1), key="cmp_b")

    result = explainer.compare_formulas(
        features[idx_a], features[idx_b],
        f"配方 {idx_a}", f"配方 {idx_b}",
    )

    if not result["changes"]:
        st.info("两个配方完全相同。")
        return

    # 差异柱状图
    names = [c["feature"] for c in result["changes"]]
    changes = [c["change"] for c in result["changes"]]
    colors = ["#22c55e" if c >= 0 else "#ef4444" for c in changes]

    fig = go.Figure(go.Bar(
        x=names, y=changes, marker_color=colors,
        text=[f"{c:+.3f}" for c in changes], textposition="outside",
    ))
    fig.update_layout(
        title=f"{result['label_a']} → {result['label_b']} 特征变化",
        yaxis_title="变化量",
        template="plotly_white", height=450,
    )
    st.plotly_chart(fig, use_container_width=True)

    # 差异表
    rows = []
    for c in result["changes"]:
        rows.append({
            "特征": c["feature"],
            f"{result['label_a']}": c["value_a"],
            f"{result['label_b']}": c["value_b"],
            "变化量": c["change"],
            "变化率": f"{c['change_pct']:+.1f}%",
        })
    df = pd.DataFrame(rows)
    st.dataframe(df, use_container_width=True, hide_index=True)


def _get_data():
    """获取当前数据。"""
    if "features" not in st.session_state or "targets" not in st.session_state:
        st.info("📦 请先在「数据管理」模块导入配方数据，或使用「联邦训练」生成合成数据。")
        return None, None
    return st.session_state["features"], st.session_state["targets"]
