# ── modules/pareto_optimizer.py ──
"""
多目标 Pareto 前沿优化模块

功能：
    - Pareto 前沿可视化
    - 交互式筛选（成本上限、性能下限）
    - 锚点推荐（性价比/性能/成本最优）
    - Pareto 前沿配方详情
"""

import streamlit as st
import numpy as np
import pandas as pd
import plotly.graph_objects as go

from analysis.pareto_optimizer import ParetoOptimizer
from analysis.cost_analyzer import CostAnalyzer


def render():
    st.markdown("## ⚖️ 多目标 Pareto 优化")

    if "pareto_optimizer" not in st.session_state:
        st.session_state["pareto_optimizer"] = ParetoOptimizer()

    optimizer: ParetoOptimizer = st.session_state["pareto_optimizer"]

    features, targets = _get_data()
    if features is None:
        return

    # 计算成本
    if "cost_analyzer" not in st.session_state:
        st.session_state["cost_analyzer"] = CostAnalyzer()
    analyzer: CostAnalyzer = st.session_state["cost_analyzer"]

    # 添加数据点
    costs = np.array([analyzer.compute_cost(f).total_cost for f in features])
    optimizer.add_points(features, targets, costs)

    # ── Tab 布局 ──
    tab1, tab2, tab3 = st.tabs(["📊 Pareto 前沿", "🎯 智能推荐", "📋 前沿配方详情"])

    with tab1:
        _render_pareto_front(optimizer)
    with tab2:
        _render_recommendation(optimizer)
    with tab3:
        _render_pareto_details(optimizer)


def _render_pareto_front(optimizer: ParetoOptimizer):
    """Pareto 前沿可视化。"""
    stats = optimizer.get_stats()

    # 统计卡片
    cols = st.columns(4)
    cols[0].metric("总配方数", stats["total_points"])
    cols[1].metric("Pareto 前沿点", stats["pareto_points"])
    cols[2].metric("成本范围", f"${stats['cost_range'][0]:.0f}-${stats['cost_range'][1]:.0f}")
    cols[3].metric("性能范围", f"{stats['performance_range'][0]:.1f}-{stats['performance_range'][1]:.1f}")

    # 散点图
    fig = go.Figure()

    non_pareto = [p for p in optimizer.points if not p.is_pareto]
    pareto = [p for p in optimizer.points if p.is_pareto]

    if non_pareto:
        fig.add_trace(go.Scatter(
            x=[p.cost for p in non_pareto],
            y=[p.performance for p in non_pareto],
            mode="markers",
            marker=dict(size=6, color="#cbd5e1", opacity=0.4),
            name="非 Pareto",
            hovertemplate="成本: $%{x:.0f}/L<br>性能: %{y:.1f}<extra></extra>",
        ))

    if pareto:
        pareto_sorted = sorted(pareto, key=lambda p: p.cost)
        fig.add_trace(go.Scatter(
            x=[p.cost for p in pareto_sorted],
            y=[p.performance for p in pareto_sorted],
            mode="lines+markers",
            line=dict(color="#3b82f6", width=2.5),
            marker=dict(size=10, color="#3b82f6"),
            name="Pareto 前沿",
            hovertemplate="成本: $%{x:.0f}/L<br>性能: %{y:.1f}<extra>Pareto</extra>",
        ))

        # 锚点
        anchors = optimizer.get_anchors()
        anchor_styles = {
            "性价比最优": ("💰", "#22c55e", "star"),
            "性能最优": ("🏆", "#ef4444", "diamond"),
            "成本最优": ("💵", "#f59e0b", "square"),
        }
        for anchor_name, point in anchors.items():
            emoji, color, symbol = anchor_styles[anchor_name]
            fig.add_trace(go.Scatter(
                x=[point.cost], y=[point.performance],
                mode="markers+text",
                marker=dict(size=18, color=color, symbol=symbol),
                text=[emoji], textposition="top center",
                textfont=dict(size=20),
                name=anchor_name,
                hovertemplate=f"{emoji} {anchor_name}<br>成本: ${point.cost:.0f}/L<br>性能: {point.performance:.1f}<extra></extra>",
            ))

    fig.update_layout(
        xaxis_title="贵金属成本 ($/L)",
        yaxis_title="综合性能评分",
        template="plotly_white",
        height=550,
        legend=dict(orientation="h", yanchor="bottom", y=1.02),
    )

    st.plotly_chart(fig, use_container_width=True)


def _render_recommendation(optimizer: ParetoOptimizer):
    """智能推荐。"""
    st.markdown("### 设定约束条件")

    col1, col2 = st.columns(2)
    with col1:
        max_cost = st.number_input("成本上限 ($/L)", 0.0, 5000.0, 500.0, step=10.0, key="max_cost")
    with col2:
        min_perf = st.number_input("性能下限", 0.0, 100.0, 60.0, step=1.0, key="min_perf")

    preference = st.radio("优化偏好", ["⚖️ 均衡", "🏆 性能优先", "💰 成本优先"],
                         horizontal=True, key="pref")

    pref_map = {"⚖️ 均衡": "balanced", "🏆 性能优先": "performance", "💰 成本优先": "cost"}
    recommendations = optimizer.recommend(
        max_cost=max_cost, min_performance=min_perf,
        preference=pref_map[preference],
    )

    if not recommendations:
        st.warning("⚠️ 没有满足约束条件的 Pareto 最优配方。请放宽约束。")
        return

    for rec in recommendations:
        st.success(f"🎯 推荐配方: **{rec.formula_id}**")
        cols = st.columns(5)
        cols[0].metric("成本", f"${rec.cost:.1f}/L")
        cols[1].metric("性能评分", f"{rec.performance:.1f}")
        cols[2].metric("CO", f"{rec.co_conv:.1f}%")
        cols[3].metric("HC", f"{rec.hc_conv:.1f}%")
        cols[4].metric("NOx", f"{rec.nox_conv:.1f}%")

        # 配方详情
        st.markdown("**贵金属载量:**")
        c1, c2, c3 = st.columns(3)
        c1.metric("Pt", f"{rec.pt_loading:.3f} g/L")
        c2.metric("Pd", f"{rec.pd_loading:.3f} g/L")
        c3.metric("Rh", f"{rec.rh_loading:.3f} g/L")


def _render_pareto_details(optimizer: ParetoOptimizer):
    """Pareto 前沿配方详情表。"""
    pareto = optimizer.pareto_front
    if not pareto:
        st.info("暂无 Pareto 前沿数据。")
        return

    rows = []
    for p in sorted(pareto, key=lambda x: x.performance, reverse=True):
        anchor_str = f" {p.anchor}" if p.anchor else ""
        rows.append({
            "配方 ID": p.formula_id + anchor_str,
            "成本 ($/L)": f"${p.cost:.1f}",
            "性能评分": f"{p.performance:.1f}",
            "CO (%)": f"{p.co_conv:.1f}",
            "HC (%)": f"{p.hc_conv:.1f}",
            "NOx (%)": f"{p.nox_conv:.1f}",
            "T50 (°C)": f"{p.t50:.0f}",
            "Pt (g/L)": f"{p.pt_loading:.3f}",
            "Pd (g/L)": f"{p.pd_loading:.3f}",
            "Rh (g/L)": f"{p.rh_loading:.3f}",
        })

    df = pd.DataFrame(rows)
    st.dataframe(df, use_container_width=True, hide_index=True)

    st.markdown(f"共 **{len(pareto)}** 个 Pareto 最优配方")


def _get_data():
    """获取当前数据。"""
    if "features" not in st.session_state or "targets" not in st.session_state:
        st.info("📦 请先在「数据管理」模块导入配方数据，或使用「联邦训练」生成合成数据。")
        return None, None
    return st.session_state["features"], st.session_state["targets"]
