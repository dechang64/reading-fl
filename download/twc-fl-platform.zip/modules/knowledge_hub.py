# ── modules/knowledge_hub.py ──
"""
Knowledge Hub Page
==================
TWC domain knowledge base: FAQ, literature, formula recommendations.
"""

import streamlit as st
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from analysis.knowledge_hub import KnowledgeHub


def render():
    st.markdown(
        '<div class="main-header"><h1>📚 TWC Knowledge Hub — 领域知识库</h1>'
        '<p>三元催化行业知识查询、文献参考、配方推荐</p></div>',
        unsafe_allow_html=True,
    )

    # ── Initialize ──
    if "knowledge_hub" not in st.session_state:
        st.session_state["knowledge_hub"] = KnowledgeHub()

    hub: KnowledgeHub = st.session_state["knowledge_hub"]

    # ── Stats ──
    stats = hub.get_stats()
    col1, col2 = st.columns(2)
    col1.metric("Total Questions", stats["total_questions"])
    col2.metric("Categories", stats["categories"])

    st.markdown("---")

    # ── Search ──
    tab_search, tab_browse, tab_recommend = st.tabs([
        "🔍 Search", "📂 Browse by Category", "💡 Formula Recommendation"
    ])

    with tab_search:
        _render_search(hub)

    with tab_browse:
        _render_browse(hub)

    with tab_recommend:
        _render_recommend()


def _render_search(hub: KnowledgeHub):
    """Search FAQ by keyword."""
    st.subheader("Search Knowledge Base")
    query = st.text_input(
        "Enter your question about TWC...",
        placeholder="e.g., 降低Rh载量, 老化机理, NOx转化率...",
    )

    if query:
        results = hub.search(query, top_k=5)
        if results:
            for i, r in enumerate(results):
                with st.expander(f"Q{i+1}: {r['question']} (score: {r['relevance_score']:.1f})", expanded=(i == 0)):
                    st.markdown(f"**Category**: {r['category']}")
                    st.markdown(r['answer'])
                    if r.get('tags'):
                        st.markdown(f"**Tags**: {', '.join(r['tags'])}")
        else:
            st.info("No matching results found. Try different keywords.")


def _render_browse(hub: KnowledgeHub):
    """Browse FAQ by category."""
    categories = hub.get_categories()

    selected_cat = st.selectbox("Select Category", categories)

    if selected_cat:
        items = hub.get_by_category(selected_cat)
        st.markdown(f"### {selected_cat} ({len(items)} items)")

        for item in items:
            with st.expander(f"Q{item['id']}: {item['question']}"):
                st.markdown(item['answer'])
                if item.get('tags'):
                    st.markdown(f"**Tags**: {', '.join(item['tags'])}")


def _render_recommend():
    """Formula recommendation based on target."""
    st.subheader("Formula Recommendation")
    st.markdown("Describe your optimization target, and the system will recommend starting points.")

    col1, col2 = st.columns(2)
    with col1:
        target = st.selectbox("Optimization Target", [
            "降低Rh载量，保持NOx转化率",
            "提高整体转化率",
            "降低T50起燃温度",
            "提高热老化稳定性",
            "降低贵金属总成本",
        ])
    with col2:
        constraint = st.text_input(
            "Additional Constraints",
            placeholder="e.g., Rh < 0.2 g/L, T50 < 220°C",
        )

    if st.button("Get Recommendations", type="primary"):
        # Generate recommendations based on domain knowledge
        recommendations = _generate_recommendations(target, constraint)

        for i, rec in enumerate(recommendations):
            with st.expander(f"Recommendation #{i+1}: {rec['title']}", expanded=(i == 0)):
                st.markdown(f"**Strategy**: {rec['strategy']}")
                st.markdown(f"**Expected Outcome**: {rec['outcome']}")
                st.markdown(f"**Risk**: {rec['risk']}")
                if rec.get('formula'):
                    st.markdown("**Suggested Formula Range**:")
                    for k, v in rec['formula'].items():
                        st.markdown(f"  - {k}: {v}")


def _generate_recommendations(target: str, constraint: str) -> list[dict]:
    """Generate formula recommendations based on target."""
    recs = []

    if "Rh" in target or "铑" in target:
        recs.append({
            "title": "Pd-Rh协同优化方案",
            "strategy": "提高Pd载量至6-8 g/L补偿Rh降低，添加CeO₂-ZrO₂固溶体增强NOx还原",
            "outcome": "Rh降低20-30%，NOx保持>88%",
            "risk": "Pd用量增加导致成本上升，需平衡总贵金属成本",
            "formula": {"Pt": "1.5-2.5 g/L", "Pd": "6.0-8.0 g/L", "Rh": "0.10-0.15 g/L",
                       "CeO₂": "150-200 g/L", "ZrO₂": "50-80 g/L"},
        })
        recs.append({
            "title": "分层涂覆Rh集中方案",
            "strategy": "将Rh集中在涂层表层（<20μm），提高Rh利用率3-5倍",
            "outcome": "Rh用量降低40-50%，转化率不变",
            "risk": "分层工艺复杂度高，需专用涂覆设备",
            "formula": {"Pt": "2.0-3.0 g/L", "Pd": "4.0-6.0 g/L", "Rh": "0.08-0.12 g/L",
                       "Al₂O₃": "150-200 g/L"},
        })

    if "转化率" in target:
        recs.append({
            "title": "高CeO₂储氧方案",
            "strategy": "提高CeO₂载量至180-200 g/L，增强储氧能力，拓宽空燃比窗口",
            "outcome": "CO/HC/NOx综合转化率提升2-5%",
            "risk": "高CeO₂可能导致涂层开裂",
            "formula": {"Pt": "2.0-3.0 g/L", "Pd": "4.0-6.0 g/L", "Rh": "0.15-0.20 g/L",
                       "CeO₂": "180-200 g/L", "ZrO₂": "40-60 g/L"},
        })

    if "T50" in target or "起燃" in target:
        recs.append({
            "title": "低温活性优化方案",
            "strategy": "提高贵金属总载量，添加BaO助剂稳定分散，降低焙烧温度至450°C",
            "outcome": "T50降低20-40°C",
            "risk": "贵金属成本上升，低温活性与热稳定性可能矛盾",
            "formula": {"Pt": "3.0-4.0 g/L", "Pd": "6.0-8.0 g/L", "Rh": "0.20-0.30 g/L",
                       "BaO": "15-25 g/L", "Calcination": "450-500°C"},
        })

    if "老化" in target or "稳定" in target:
        recs.append({
            "title": "热稳定性增强方案",
            "strategy": "使用ZrO₂稳定CeO₂晶相，添加La₂O₃防止Al₂O₃相变",
            "outcome": "1000°C老化后转化率保持率>90%",
            "risk": "助剂过多可能降低初始活性",
            "formula": {"Pt": "2.0-3.0 g/L", "Pd": "4.0-6.0 g/L", "Rh": "0.15-0.20 g/L",
                       "ZrO₂": "60-80 g/L", "La₂O₃": "15-25 g/L"},
        })

    if "成本" in target:
        recs.append({
            "title": "全Pd方案（无Rh）",
            "strategy": "完全去除Rh，用高Pd + 高CeO₂-ZrO₂补偿NOx还原性能",
            "outcome": "贵金属成本降低50%以上",
            "risk": "NOx转化率可能降至85-88%，不满足Euro 6d",
            "formula": {"Pt": "1.0-2.0 g/L", "Pd": "8.0-12.0 g/L", "Rh": "0 g/L",
                       "CeO₂": "150-200 g/L", "ZrO₂": "60-100 g/L"},
        })

    if not recs:
        recs.append({
            "title": "通用优化方案",
            "strategy": "基于当前配方的贝叶斯优化，逐步迭代寻找最优解",
            "outcome": "综合性能提升5-15%",
            "risk": "需要多轮实验验证",
            "formula": {"Pt": "2.0-3.0 g/L", "Pd": "4.0-6.0 g/L", "Rh": "0.15-0.20 g/L"},
        })

    return recs
