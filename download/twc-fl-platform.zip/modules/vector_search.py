# ── modules/vector_search.py ──
"""
Vector Search Page
==================
Search formula database for similar catalyst compositions.
"""

import streamlit as st
import numpy as np
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from utils.constants import COLORS
from utils.helpers import generate_synthetic_formulas, features_to_dataframe, check_compliance, compute_pge_cost
from analysis.vector_engine import VectorEngine
from visualization.charts import knn_distance_chart


def render():
    st.markdown(
        '<div class="main-header"><h1>🔍 Vector Search — 配方相似度检索</h1>'
        '<p>基于向量引擎的毫秒级配方相似度检索</p></div>',
        unsafe_allow_html=True,
    )

    # ── Initialize ──
    if "vector_engine" not in st.session_state:
        st.session_state["vector_engine"] = VectorEngine(dimension=13)
        st.session_state["vector_count"] = 0

    engine: VectorEngine = st.session_state["vector_engine"]

    # ── Populate DB ──
    if len(engine) == 0:
        st.info("Vector database is empty. Load formula data below.")
        n_load = st.slider("Formulas to generate", 50, 500, 200, step=50, key="vs_load")
        if st.button("Load Demo Formulas", type="primary"):
            features, targets = generate_synthetic_formulas(n_samples=n_load)
            ids = [f"formula_{i}" for i in range(n_load)]
            metas = [{"index": i} for i in range(n_load)]
            engine.bulk_insert(ids, features, metas)
            st.session_state["vector_count"] = len(engine)
            st.session_state["vector_features"] = features
            st.session_state["vector_targets"] = targets
            st.success(f"✅ Loaded {n_load} formulas into vector DB!")
            st.rerun()

    if len(engine) == 0:
        return

    # ── Stats ──
    stats = engine.get_stats()
    col1, col2 = st.columns(2)
    col1.metric("Total Formulas", stats["total_vectors"])
    col2.metric("Feature Dimension", stats["dimension"])

    st.markdown("---")

    # ── Search ──
    tab_search, tab_manual, tab_stats = st.tabs([
        "🔍 Search by Formula", "✏️ Manual Input", "📊 Database Stats"
    ])

    with tab_search:
        _render_search(engine)

    with tab_manual:
        _render_manual(engine)

    with tab_stats:
        _render_stats(engine)


def _render_search(engine: VectorEngine):
    """Search by selecting a formula from the database."""
    st.subheader("Find Similar Formulas")

    k = st.slider("Top-K results", 3, 20, 5)

    # Pick a query formula
    query_idx = st.number_input("Query formula index", 0, len(engine) - 1, 0)
    query_id = f"formula_{query_idx}"

    if st.button("🔍 Search", type="primary"):
        query_vec = engine.vectors[query_id]
        results = engine.search(query_vec, k=k)

        if results:
            distances = [1 - sim for _, sim in results]
            fig = knn_distance_chart(distances, k=k, title="Cosine Distance to Nearest Formulas")
            st.plotly_chart(fig, use_container_width=True)

            st.markdown(f"### Top-{k} Similar Formulas")
            for rank, (fid, sim) in enumerate(results):
                vec = engine.vectors[fid]
                idx = engine.metadata[fid].get("index", 0)

                with st.expander(f"#{rank+1}: {fid} (similarity: {sim:.4f})", expanded=(rank < 3)):
                    col_a, col_b = st.columns(2)
                    with col_a:
                        st.markdown("**Composition:**")
                        st.markdown(f"- Pt: {vec[0]:.2f} g/L")
                        st.markdown(f"- Pd: {vec[1]:.2f} g/L")
                        st.markdown(f"- Rh: {vec[2]:.3f} g/L")
                        st.markdown(f"- CeO₂: {vec[3]:.0f} g/L")
                        st.markdown(f"- ZrO₂: {vec[4]:.0f} g/L")
                        cost = compute_pge_cost(vec)
                        st.markdown(f"**PGE Cost**: ${cost:.0f}/L")
                    with col_b:
                        st.markdown("**Distance from query:**")
                        st.markdown(f"  {1 - sim:.4f}")


def _render_manual(engine: VectorEngine):
    """Manual formula input for search."""
    st.subheader("Enter Formula to Search")

    col1, col2 = st.columns(2)
    with col1:
        pt = st.number_input("Pt (g/L)", 0.0, 10.0, 2.0, 0.1, key="vs_pt")
        pd_val = st.number_input("Pd (g/L)", 0.0, 15.0, 4.0, 0.1, key="vs_pd")
        rh = st.number_input("Rh (g/L)", 0.0, 1.0, 0.15, 0.01, key="vs_rh")
    with col2:
        ceo2 = st.number_input("CeO₂ (g/L)", 0, 300, 120, 5, key="vs_ceo2")
        zro2 = st.number_input("ZrO₂ (g/L)", 0, 150, 50, 5, key="vs_zro2")
        al2o3 = st.number_input("Al₂O₃ (g/L)", 0, 350, 180, 10, key="vs_al2o3")

    if st.button("🔍 Find Similar", type="primary"):
        query = np.array([[pt, pd_val, rh, ceo2, zro2, al2o3, 20, 15, 550, 950, 120, 0.5, 0]], dtype=np.float32)
        results = engine.search(query.flatten(), k=5)

        if results:
            st.success(f"Found {len(results)} similar formulas")
            for rank, (fid, sim) in enumerate(results):
                vec = engine.vectors[fid]
                st.markdown(f"**#{rank+1}** {fid}: similarity={sim:.4f} | "
                           f"Pt={vec[0]:.2f} Pd={vec[1]:.2f} Rh={vec[2]:.3f}")


def _render_stats(engine: VectorEngine):
    """Database statistics."""
    st.subheader("Database Statistics")
    stats = engine.get_stats()
    col_a, col_b = st.columns(2)
    col_a.metric("Total Formulas", stats["total_vectors"])
    col_b.metric("Dimension", stats["dimension"])

    # Feature distribution
    if "vector_features" in st.session_state:
        import plotly.graph_objects as go
        features = st.session_state["vector_features"]

        fig = go.Figure()
        labels = ["Pt", "Pd", "Rh", "CeO₂", "ZrO₂", "Al₂O₃"]
        for i, label in enumerate(labels):
            fig.add_trace(go.Histogram(x=features[:, i], name=label, opacity=0.7))

        fig.update_layout(
            title="Feature Distribution in Formula Database",
            template="plotly_white",
            barmode="overlay",
            height=400,
        )
        st.plotly_chart(fig, use_container_width=True)
