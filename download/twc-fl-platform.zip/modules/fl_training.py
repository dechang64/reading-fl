# ── modules/fl_training.py ──
"""
FL Training Page
================
配置和运行联邦学习，实时可视化。
"""

import streamlit as st
import numpy as np
import time
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from utils.constants import DEFAULT_ROUNDS, DEFAULT_CLIENTS, DEFAULT_LR, DEFAULT_BATCH_SIZE, DEFAULT_LOCAL_EPOCHS, REFERENCES, COLORS
from utils.helpers import generate_synthetic_formulas, split_federated_data
from analysis.fl_engine import FLEngine
from visualization.charts import fl_convergence


def render():
    st.markdown(
        '<div class="main-header"><h1>🔄 Federated Learning Training</h1>'
        '<p>跨企业联合训练催化剂性能预测模型 — 配方数据不出厂</p></div>',
        unsafe_allow_html=True,
    )

    # ── Configuration ──
    with st.expander("⚙️ Training Configuration", expanded=True):
        col1, col2, col3 = st.columns(3)
        with col1:
            n_rounds = st.slider("FL Rounds", 1, 50, DEFAULT_ROUNDS)
            n_clients = st.slider("Enterprises (Clients)", 2, 10, DEFAULT_CLIENTS)
        with col2:
            lr = st.slider("Learning Rate", 0.0001, 0.01, DEFAULT_LR, format="%.4f")
            local_epochs = st.slider("Local Epochs", 1, 10, DEFAULT_LOCAL_EPOCHS)
        with col3:
            batch_size = st.selectbox("Batch Size", [16, 32, 64, 128], index=1)
            hidden_dim = st.selectbox("Hidden Dim", [32, 64, 128, 256], index=1)

    # ── Data Setup ──
    st.markdown("---")
    col_data, col_noniid = st.columns(2)
    with col_data:
        n_samples = st.slider("Total formulas", 100, 2000, 600, step=100)
    with col_noniid:
        non_iid = st.slider("Non-IID level", 0.0, 0.9, 0.3, step=0.1,
                            help="0 = uniform distribution, 0.9 = highly skewed")

    # ── Run Training ──
    st.markdown("---")
    if st.button("🚀 Start FL Training", type="primary", use_container_width=True):
        _run_training(n_rounds, n_clients, lr, local_epochs, batch_size,
                      hidden_dim, n_samples, non_iid)


def _run_training(n_rounds, n_clients, lr, local_epochs, batch_size,
                  hidden_dim, n_samples, non_iid):
    """Execute FL training with real-time progress."""
    # Generate data
    features, targets = generate_synthetic_formulas(n_samples=n_samples)
    client_data = split_federated_data(features, targets, n_clients=n_clients, non_iid=non_iid)

    # Initialize engine
    engine = FLEngine(
        input_dim=13,
        hidden_dim=hidden_dim,
        lr=lr,
        batch_size=batch_size,
        local_epochs=local_epochs,
    )

    # Progress
    progress = st.progress(0, text="Starting FL training...")
    status = st.empty()

    def on_progress(round_num, metrics):
        progress.progress((round_num + 1) / n_rounds,
                          text=f"Round {round_num + 1}/{n_rounds}")
        status.markdown(
            f"**Round {round_num + 1}**: "
            f"Val R²={metrics['val_r2']:.4f} | "
            f"Val Loss={metrics['val_loss']:.4f}"
        )

    # Train
    history = engine.train(
        client_data=client_data,
        n_rounds=n_rounds,
        progress_callback=on_progress,
    )

    # Store results
    st.session_state["best_r2"] = f"{history[-1]['val_r2']:.4f}"
    st.session_state["total_rounds"] = n_rounds
    st.session_state["n_clients"] = n_clients
    st.session_state["fl_history"] = history

    progress.progress(1.0, text="Training complete!")
    status.empty()

    # ── Results ──
    st.markdown("---")
    st.subheader("📊 Training Results")

    col1, col2, col3 = st.columns(3)
    final = history[-1]
    col1.metric("Final Val R²", f"{final['val_r2']:.4f}")
    col2.metric("Final Val Loss", f"{final['val_loss']:.4f}")
    col3.metric("Total Time", f"{sum(h['elapsed'] for h in history):.1f}s")

    # Charts
    tab_conv, tab_clients = st.tabs(["Convergence", "Per-Enterprise"])

    with tab_conv:
        fig = fl_convergence(history, title="TWC-FL Convergence")
        st.plotly_chart(fig, use_container_width=True)

    with tab_clients:
        _render_client_comparison(history, n_clients)

    # ── Methodology ──
    with st.expander("📖 Methodology"):
        st.markdown("""
        **FedAvg** (McMahan et al., 2017) — adapted for catalyst performance prediction.

        1. **Local Training**: Each enterprise $k$ trains on its own formula data $\\mathcal{D}_k$:
           $$w_k^{t+1} = w_k^t - \\eta \\nabla F_k(w_k^t)$$

        2. **Aggregation**: Server averages client updates (weighted by data size):
           $$w^{t+1} = \\sum_{k=1}^{K} \\frac{|\\mathcal{D}_k|}{|\\mathcal{D}|} w_k^{t+1}$$

        3. **Privacy**: Only model gradients are shared — **raw formula data never leaves the enterprise**.

        **Prediction Targets**: CO conversion (%), HC conversion (%), NOx conversion (%), T50 (°C)
        """)
        for key, ref in REFERENCES.items():
            st.markdown(f"- **{key}**: {ref}")


def _render_client_comparison(history, n_clients):
    """Per-enterprise performance comparison."""
    import plotly.graph_objects as go

    if not history or "client_metrics" not in history[0]:
        st.info("No per-client data available.")
        return

    fig = go.Figure()
    client_colors = ["#3b82f6", "#8b5cf6", "#06b6d4", "#ec4899", "#f59e0b",
                     "#22c55e", "#ef4444", "#6366f1", "#14b8a6", "#f97316"]

    for rnd_data in history:
        for ci, cm in enumerate(rnd_data["client_metrics"]):
            fig.add_trace(go.Scatter(
                x=[rnd_data["round"]],
                y=[cm["train_r2"]],
                mode="markers+lines",
                name=f"Enterprise {cm['client_id']+1}",
                marker_color=client_colors[ci % len(client_colors)],
                showlegend=(rnd_data == history[0]),
            ))

    fig.update_layout(
        title="Per-Enterprise Training R²",
        template="plotly_white",
        xaxis_title="FL Round",
        yaxis_title="R² Score",
        height=400,
    )
    st.plotly_chart(fig, use_container_width=True)
