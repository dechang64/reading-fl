# ── modules/cost_dashboard.py ──
"""
贵金属成本仪表盘模块

功能：
    - PGE 实时价格展示
    - 配方成本明细
    - 成本-性能散点图
    - 配方对比（节省百分比）
"""

import streamlit as st
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from analysis.cost_analyzer import CostAnalyzer, PGE_PRICES


def render():
    st.markdown("## 💰 贵金属成本分析")

    if "cost_analyzer" not in st.session_state:
        st.session_state["cost_analyzer"] = CostAnalyzer()

    analyzer: CostAnalyzer = st.session_state["cost_analyzer"]

    # ── 价格概览 ──
    _render_price_overview(analyzer)

    st.divider()

    # ── Tab 布局 ──
    tab1, tab2, tab3 = st.tabs(["📊 成本-性能分析", "📋 配方成本明细", "🔄 配方对比"])

    with tab1:
        _render_cost_performance(analyzer)
    with tab2:
        _render_cost_breakdown(analyzer)
    with tab3:
        _render_comparison(analyzer)


def _render_price_overview(analyzer: CostAnalyzer):
    """PGE 价格概览卡片。"""
    st.markdown("### 当前 PGE 价格")

    summary = analyzer.get_price_summary()

    cols = st.columns(3)
    for i, (elem, info) in enumerate(summary.items()):
        with cols[i]:
            st.metric(
                label=f"{info['emoji']} {info['name']} ({elem})",
                value=f"${info['price_per_oz']:,.0f}/oz",
                delta=f"${info['price_per_g']:.2f}/g",
            )

    # 手动更新价格
    with st.expander("⚙️ 更新价格"):
        new_prices = {}
        cols = st.columns(3)
        for i, (elem, info) in enumerate(summary.items()):
            with cols[i]:
                new_prices[elem] = st.number_input(
                    f"{elem} ($/g)",
                    value=info["price_per_g"],
                    min_value=0.0,
                    step=0.1,
                    key=f"price_{elem}",
                )
        if st.button("更新价格", type="primary"):
            analyzer.update_prices(new_prices)
            st.success("✅ 价格已更新！")
            st.rerun()


def _render_cost_performance(analyzer: CostAnalyzer):
    """成本-性能散点图。"""
    features, targets = _get_data()
    if features is None:
        return

    points = analyzer.analyze_cost_performance(features, targets)

    fig = go.Figure()

    # 非 Pareto 点
    non_pareto = [p for p in points if not p.is_pareto]
    pareto = [p for p in points if p.is_pareto]

    if non_pareto:
        fig.add_trace(go.Scatter(
            x=[p.total_cost for p in non_pareto],
            y=[p.performance_score for p in non_pareto],
            mode="markers",
            marker=dict(size=8, color="#94a3b8", opacity=0.5),
            name="配方",
            hovertemplate="成本: $%{x:.0f}/L<br>性能: %{y:.1f}<extra></extra>",
        ))

    if pareto:
        pareto_sorted = sorted(pareto, key=lambda p: p.total_cost)
        fig.add_trace(go.Scatter(
            x=[p.total_cost for p in pareto_sorted] + [pareto_sorted[-1].total_cost],
            y=[p.performance_score for p in pareto_sorted] + [pareto_sorted[-1].performance_score],
            mode="lines+markers",
            line=dict(color="#ef4444", width=2, dash="dash"),
            marker=dict(size=10, color="#ef4444"),
            name="Pareto 前沿",
            hovertemplate="成本: $%{x:.0f}/L<br>性能: %{y:.1f}<extra>Pareto</extra>",
        ))

        # 性价比最优点
        best = max(pareto, key=lambda p: p.performance_score / max(p.total_cost, 0.01))
        fig.add_trace(go.Scatter(
            x=[best.total_cost], y=[best.performance_score],
            mode="markers+text",
            marker=dict(size=16, color="#22c55e", symbol="star"),
            text=["💰"], textposition="top center",
            textfont=dict(size=20),
            name="性价比最优",
            hovertemplate=f"💰 {best.formula_id}<br>成本: ${best.total_cost:.0f}/L<br>性能: {best.performance_score:.1f}<extra></extra>",
        ))

    fig.update_layout(
        xaxis_title="贵金属成本 ($/L)",
        yaxis_title="综合性能评分",
        template="plotly_white",
        height=500,
        legend=dict(orientation="h", yanchor="bottom", y=1.02),
    )

    st.plotly_chart(fig, use_container_width=True)


def _render_cost_breakdown(analyzer: CostAnalyzer):
    """配方成本明细表。"""
    features, targets = _get_data()
    if features is None:
        return

    n_show = min(20, len(features))
    rows = []
    for i in range(n_show):
        cost = analyzer.compute_cost(features[i])
        perf = analyzer.compute_performance_score(targets[i])
        rows.append({
            "配方 ID": cost.formula_id,
            "Pt 成本": f"${cost.pt_cost:.1f}",
            "Pd 成本": f"${cost.pd_cost:.1f}",
            "Rh 成本": f"${cost.rh_cost:.1f}",
            "总成本": f"${cost.total_cost:.1f}",
            "Pt 占比": f"{cost.pt_pct:.0f}%",
            "Pd 占比": f"{cost.pd_pct:.0f}%",
            "Rh 占比": f"{cost.rh_pct:.0f}%",
            "性能评分": f"{perf:.1f}",
        })

    df = pd.DataFrame(rows)
    st.dataframe(df, use_container_width=True, hide_index=True)

    # 成本构成饼图
    if len(features) > 0:
        avg_cost = analyzer.compute_cost(np.mean(features, axis=0))
        fig = go.Figure(data=[
            go.Pie(
                labels=["Pt (铂)", "Pd (钯)", "Rh (铑)"],
                values=[avg_cost.pt_cost, avg_cost.pd_cost, avg_cost.rh_cost],
                marker_colors=["#94a3b8", "#64748b", "#fbbf24"],
                textinfo="label+percent+value",
                texttemplate="%{label}<br>%{percent:.0f}%<br>$%{value:.0f}/L",
                hole=0.4,
            )
        ])
        fig.update_layout(
            title="平均配方成本构成",
            template="plotly_white",
            height=400,
            margin=dict(t=60),
        )
        st.plotly_chart(fig, use_container_width=True)


def _render_comparison(analyzer: CostAnalyzer):
    """配方对比。"""
    features, targets = _get_data()
    if features is None:
        return

    col_a, col_b = st.columns(2)
    with col_a:
        idx_a = st.number_input("基准配方索引", 0, len(features) - 1, 0, key="comp_a")
    with col_b:
        idx_b = st.number_input("对比配方索引", 0, len(features) - 1, min(1, len(features) - 1), key="comp_b")

    cost_a = analyzer.compute_cost(features[idx_a])
    cost_b = analyzer.compute_cost(features[idx_b])
    perf_a = analyzer.compute_performance_score(targets[idx_a])
    perf_b = analyzer.compute_performance_score(targets[idx_b])

    cols = st.columns(4)
    cols[0].metric("基准成本", f"${cost_a.total_cost:.1f}/L")
    cols[1].metric("对比成本", f"${cost_b.total_cost:.1f}/L",
                   delta=f"{(cost_b.total_cost - cost_a.total_cost) / cost_a.total_cost * 100:+.1f}%")
    cols[2].metric("基准性能", f"{perf_a:.1f}")
    cols[3].metric("对比性能", f"{perf_b:.1f}",
                   delta=f"{perf_b - perf_a:+.1f}")

    # 对比雷达图
    categories = ["CO 转化率", "HC 转化率", "NOx 转化率", "T50 (反转)", "成本 (反转)"]
    t_a = targets[idx_a]
    t_b = targets[idx_b]
    vals_a = [t_a[0], t_a[1], t_a[2], 100 - (t_a[3] - 180) / 1.2, 100 - cost_a.total_cost / 5]
    vals_b = [t_b[0], t_b[1], t_b[2], 100 - (t_b[3] - 180) / 1.2, 100 - cost_b.total_cost / 5]

    fig = go.Figure()
    fig.add_trace(go.Scatterpolar(
        r=vals_a + [vals_a[0]], theta=categories + [categories[0]],
        fill="toself", name=f"配方 {idx_a}", line_color="#3b82f6",
    ))
    fig.add_trace(go.Scatterpolar(
        r=vals_b + [vals_b[0]], theta=categories + [categories[0]],
        fill="toself", name=f"配方 {idx_b}", line_color="#ef4444",
    ))
    fig.update_layout(polar=dict(radialaxis=dict(visible=True, range=[0, 100])),
                      template="plotly_white", height=450)
    st.plotly_chart(fig, use_container_width=True)


def _get_data():
    """获取当前数据。"""
    if "features" not in st.session_state or "targets" not in st.session_state:
        st.info("📦 请先在「数据管理」模块导入配方数据，或使用「联邦训练」生成合成数据。")
        return None, None
    return st.session_state["features"], st.session_state["targets"]
