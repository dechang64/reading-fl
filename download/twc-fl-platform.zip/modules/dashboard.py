# ── modules/dashboard.py ──
"""
Dashboard Page
==============
Platform overview: key metrics, system status, quick actions.
"""

import streamlit as st
import numpy as np
from utils.constants import REFERENCES, COLORS, TWC_TARGETS, PGE_INFO


def render():
    st.markdown(
        '<div class="main-header"><h1>⚗️ TWC-FL Platform Dashboard</h1>'
        '<p>三元催化配方联邦学习协作平台 — 隐私保护下的跨企业AI模型协作</p></div>',
        unsafe_allow_html=True,
    )

    # ── Key Metrics ──
    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.metric(
            label="FL Model R²",
            value=st.session_state.get("best_r2", "—"),
            delta="FedAvg" if st.session_state.get("best_r2") else None,
        )

    with col2:
        st.metric(
            label="FL Rounds",
            value=st.session_state.get("total_rounds", "—"),
            delta=f"{st.session_state.get('n_clients', 3)} enterprises",
        )

    with col3:
        st.metric(
            label="Formulas in DB",
            value=st.session_state.get("formula_count", "—"),
            delta="Vector Search" if st.session_state.get("formula_count") else None,
        )

    with col4:
        st.metric(
            label="Audit Chain",
            value=f"{st.session_state.get('audit_blocks', 1)} blocks",
            delta="✅ Valid" if st.session_state.get("audit_valid", True) else "❌ Broken",
        )

    st.markdown("---")

    # ── Platform Overview ──
    col_a, col_b = st.columns(2)

    with col_a:
        st.subheader("🎯 Platform Modules")
        st.markdown("""
        | Module | Status | Description |
        |--------|--------|-------------|
        | 📁 Data Vault | ✅ Ready | 配方数据导入、脱敏、质量报告 |
        | 📚 Knowledge Hub | ✅ Ready | TWC领域知识库，20+常见问题 |
        | 🧪 Bayesian Optimizer | ✅ Ready | 贝叶斯优化推荐实验配方 |
        | 🔄 FL Training | ✅ Ready | 联邦学习训练与可视化 |
        | 🔍 Vector Search | ✅ Ready | 配方相似度检索 |
        | ⛓️ Audit Chain | ✅ Ready | 区块链式操作审计 |
        """)

    with col_b:
        st.subheader("📊 Emission Targets (Euro 6d / China 6b)")
        for gas, info in TWC_TARGETS.items():
            if "min" in info:
                st.markdown(f"**{gas}**: ≥ {info['min']}{info['unit']} — {info['desc']}")
            else:
                lo, hi = info["target_range"]
                st.markdown(f"**{gas}**: {lo}-{hi}{info['unit']} — {info['desc']}")

        st.markdown("---")
        st.subheader("💰 PGE Prices (2024)")
        for elem, info in PGE_INFO.items():
            st.markdown(f"{info['emoji']} **{elem}** ({info['name']}): ${info['price_per_oz_usd']:,}/oz")

    st.markdown("---")

    # ── Research Context ──
    st.subheader("🔬 平台定位")
    st.markdown("""
    TWC-FL Platform 让多家催化剂企业在**配方数据不出厂**的前提下联合训练AI预测模型，
    实现全行业共享模型进步、同时单家企业独守配方机密的双赢格局。

    - **催化剂企业**：用全行业数据训练模型，但配方永远在自己服务器里
    - **高校/科研机构**：把实验室成果快速导入产业端，形成真实数据闭环
    - **主机厂/OEM**：更早介入上游催化剂R&D，缩短认证周期
    - **政府/园区**：建立产业技术标准，占据AI for Science制高点
    """)

    st.markdown("---")

    # ── Quick Actions ──
    st.subheader("⚡ Quick Actions")
    col_a, col_b, col_c = st.columns(3)

    with col_a:
        if st.button("📁 Import Formula Data", use_container_width=True, type="primary"):
            st.session_state["current_page"] = "data_vault"

    with col_b:
        if st.button("🧪 Bayesian Optimize", use_container_width=True):
            st.session_state["current_page"] = "bayesian_optimizer"

    with col_c:
        if st.button("🔄 Run FL Training", use_container_width=True):
            st.session_state["current_page"] = "fl_training"

    # ── References ──
    with st.expander("📚 References"):
        for key, ref in REFERENCES.items():
            st.markdown(f"**{key}**: {ref}")
