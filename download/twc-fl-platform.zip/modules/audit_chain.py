# ── modules/audit_chain.py ──
"""
Audit Chain Page
================
区块链式不可篡改审计日志。
"""

import streamlit as st
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from analysis.audit_engine import AuditEngine
from visualization.charts import audit_timeline


def render():
    st.markdown(
        '<div class="main-header"><h1>⛓️ Audit Chain — 审计链</h1>'
        '<p>区块链式不可篡改操作日志 — 每次FL操作都有存证</p></div>',
        unsafe_allow_html=True,
    )

    # ── Initialize ──
    if "audit_engine" not in st.session_state:
        st.session_state["audit_engine"] = AuditEngine(max_blocks=1000)
        st.session_state["audit_blocks"] = 1
        st.session_state["audit_valid"] = True

    engine: AuditEngine = st.session_state["audit_engine"]

    # ── Stats ──
    col1, col2, col3 = st.columns(3)
    stats = engine.get_stats()
    with col1:
        st.metric("Chain Length", stats["chain_length"])
    with col2:
        st.metric("Chain Valid", "✅ Yes" if stats["chain_valid"] else "❌ No")
    with col3:
        st.metric("Latest Hash", stats["latest_hash"])

    st.markdown("---")

    # ── Add Test Operations ──
    with st.expander("➕ Add Test Operation"):
        col_a, col_b = st.columns(2)
        with col_a:
            op = st.selectbox("Operation", [
                "formula_import", "fl_round", "bayesian_suggest",
                "model_update", "data_desensitize", "compliance_check",
            ])
        with col_b:
            client_id = st.text_input("Client/Enterprise ID", "enterprise_01")

        if st.button("Add Block"):
            engine.append(op, {"client": client_id, "status": "success"})
            st.session_state["audit_blocks"] = len(engine)
            st.session_state["audit_valid"] = engine.verify_chain()
            st.success(f"✅ Block #{len(engine)} added!")
            st.rerun()

    # ── Verify ──
    col_v, col_s = st.columns(2)
    with col_v:
        if st.button("🔍 Verify Chain Integrity"):
            valid = engine.verify_chain()
            if valid:
                st.success(f"✅ Chain valid! {len(engine)} blocks verified.")
            else:
                st.error("❌ Chain broken! Tampering detected.")

    with col_s:
        st.markdown("### How it works")
        st.markdown("""
        1. 每次FL操作创建一个审计区块
        2. 区块哈希 = SHA256(index + timestamp + operation + data + prev_hash)
        3. 每个区块通过 `prev_hash` 链接到前一个区块
        4. 验证链确保没有任何区块被篡改

        **合规性**: 提供符合数据安全法规的审计追踪，
        不暴露任何配方数据。
        """)

    st.markdown("---")

    # ── Recent Blocks ──
    n_show = st.slider("Show last N blocks", 5, 50, 10)
    recent = engine.recent(n_show)

    if recent:
        df = engine.to_dataframe()
        st.dataframe(df.tail(n_show), use_container_width=True, hide_index=True)

        fig = audit_timeline(recent)
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No blocks yet. Add test operations above.")
