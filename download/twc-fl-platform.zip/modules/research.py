# ── modules/research.py ──
"""
Research Page
=============
Methodology, references, and theoretical foundation.
"""

import streamlit as st
from utils.constants import REFERENCES


def render():
    st.markdown(
        '<div class="main-header"><h1>📖 Research — 研究基础</h1>'
        '<p>方法论、论文引用、理论基础</p></div>',
        unsafe_allow_html=True,
    )

    # ── Core Methodology ──
    st.subheader("🔬 核心方法论")

    tab_fl, tab_bo, tab_audit = st.tabs([
        "Federated Learning", "Bayesian Optimization", "Audit Chain"
    ])

    with tab_fl:
        st.markdown("""
        ### 联邦学习 (Federated Learning)

        **问题**: 催化剂配方是核心竞争力，企业不愿共享数据。
        **方案**: 数据不动模型动 — 只交换模型梯度，不交换配方数据。

        **FedAvg 算法** (McMahan et al., 2017):

        1. **本地训练**: 每个企业 $k$ 在本地配方数据 $\\mathcal{D}_k$ 上训练:
           $$w_k^{t+1} = w_k^t - \\eta \\nabla F_k(w_k^t)$$

        2. **聚合**: 服务器按数据量加权平均:
           $$w^{t+1} = \\sum_{k=1}^{K} \\frac{|\\mathcal{D}_k|}{|\\mathcal{D}|} w_k^{t+1}$$

        3. **重复** $T$ 轮直到收敛。

        **Non-IID 挑战**: 不同企业的配方空间差异大，
        需要个性化联邦学习策略。
        """)

    with tab_bo:
        st.markdown("""
        ### 贝叶斯优化 (Bayesian Optimization)

        **问题**: 催化剂实验成本极高（一次老化实验几万至几十万）。
        **方案**: 用高斯过程作为代理模型，智能推荐最有价值的实验配方。

        **采集函数**: Expected Improvement (EI)
        $$EI(x) = \\mathbb{E}[\\max(f(x) - f(x^+), 0)]$$

        **多目标优化**: 同时优化转化率和贵金属成本。
        """)

    with tab_audit:
        st.markdown("""
        ### 审计链 (Audit Chain)

        **问题**: FL协作需要可追溯的操作记录。
        **方案**: SHA-256 哈希链，每次操作不可篡改。

        **区块结构**:
        - `index`: 区块编号
        - `timestamp`: ISO 8601 时间戳
        - `operation`: 操作类型
        - `details`: 操作元数据
        - `prev_hash`: 前一区块哈希
        - `hash`: 当前区块哈希
        """)

    st.markdown("---")

    # ── References ──
    st.subheader("📚 References")
    for key, ref in REFERENCES.items():
        st.markdown(f"**{key}**: {ref}")

    st.markdown("---")

    # ── Team ──
    st.subheader("👥 Team")
    st.markdown("""
    | Role | Name | Responsibility |
    |------|------|----------------|
    | PI | 徐德昌 | 整体把控、产业对接 |
    | FL框架 | 高丽娜 | FL框架、Bayesian优化 |
    | 系统架构 | 张凯 | 系统架构、AI Agent |
    | 硬件对接 | 朱丽虹 | 硬件平台对接 |
    | 企业对接 | 陈东敏 | 企业对接、项目管理 |

    **单位**: 西交利物浦大学人工智能学院
    """)

    st.markdown("---")

    # ── Roadmap ──
    st.subheader("🗺️ Roadmap")
    st.markdown("""
    | Phase | Timeline | Milestone |
    |-------|----------|-----------|
    | Phase 1 | 2026-06-30 | MVP上线，2家种子企业试用 |
    | Phase 2 | 2026-09-30 | FL v1上线，2家以上真实FL参与 |
    | Phase 3 | 2026-12-31 | 平台化，5家以上企业接入 |
    | Phase 4 | 2027-03-31 | 课题结题，论文+专利 |
    """)
