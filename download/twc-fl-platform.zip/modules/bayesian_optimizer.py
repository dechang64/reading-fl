# ── modules/bayesian_optimizer.py ──
"""
Bayesian Optimizer Page
=======================
推荐实验配方批次，基于贝叶斯优化。
"""

import streamlit as st
import numpy as np
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from analysis.bayesian_optimizer import BayesianOptimizer
from utils.helpers import (
    generate_synthetic_formulas, features_to_dataframe, targets_to_dataframe,
    check_compliance, compute_pge_cost,
)
from utils.constants import COLORS


def render():
    st.markdown(
        '<div class="main-header"><h1>🧪 Bayesian Optimizer — 配方优化</h1>'
        '<p>基于贝叶斯优化的智能实验推荐：用最少实验次数找到最优配方</p></div>',
        unsafe_allow_html=True,
    )

    # ── Initialize ──
    if "bayes_opt" not in st.session_state:
        st.session_state["bayes_opt"] = BayesianOptimizer(n_features=13)
        st.session_state["bayes_history"] = []

    opt: BayesianOptimizer = st.session_state["bayes_opt"]

    # ── Stats ──
    stats = opt.get_stats()
    col1, col2 = st.columns(2)
    col1.metric("Observations", stats["n_observations"])
    col2.metric("GP Surrogate", "✅ Fitted" if stats["gp_fitted"] else "⏳ Not fitted")

    st.markdown("---")

    tab_setup, tab_suggest, tab_history = st.tabs([
        "📋 Setup", "🎯 Suggest Batch", "📊 Optimization History"
    ])

    with tab_setup:
        _render_setup(opt)

    with tab_suggest:
        _render_suggest(opt)

    with tab_history:
        _render_history()


def _render_setup(opt: BayesianOptimizer):
    """Load historical data and fit surrogate model."""
    st.subheader("Load Historical Data")

    use_demo = st.checkbox("Use demo data (synthetic formulas)", value=True)

    if use_demo:
        n_hist = st.slider("Historical formulas", 20, 200, 50, step=10)
        if st.button("Load & Fit Model", type="primary"):
            features, targets = generate_synthetic_formulas(n_samples=n_hist)
            opt.add_observations(features, targets)
            st.session_state["bayes_history"].append({
                "action": "load_data",
                "n_samples": n_hist,
            })
            st.success(f"✅ Loaded {n_hist} formulas, GP surrogate fitted!")
            st.rerun()

    st.markdown("---")
    st.subheader("Or Add Manual Observation")
    st.markdown("Enter a formula and its measured performance:")

    col1, col2, col3 = st.columns(3)
    with col1:
        pt = st.number_input("Pt (g/L)", 0.0, 10.0, 2.0, 0.1, key="bo_pt")
        pd_val = st.number_input("Pd (g/L)", 0.0, 15.0, 4.0, 0.1, key="bo_pd")
        rh = st.number_input("Rh (g/L)", 0.0, 1.0, 0.15, 0.01, key="bo_rh")
    with col2:
        ceo2 = st.number_input("CeO₂ (g/L)", 0, 300, 120, 5, key="bo_ceo2")
        zro2 = st.number_input("ZrO₂ (g/L)", 0, 150, 50, 5, key="bo_zro2")
        al2o3 = st.number_input("Al₂O₃ (g/L)", 0, 350, 180, 10, key="bo_al2o3")
    with col3:
        co = st.number_input("CO Conv (%)", 0, 100, 95, 0.5, key="bo_co")
        hc = st.number_input("HC Conv (%)", 0, 100, 95, 0.5, key="bo_hc")
        nox = st.number_input("NOx Conv (%)", 0, 100, 92, 0.5, key="bo_nox")
        t50 = st.number_input("T50 (°C)", 150, 350, 220, 5, key="bo_t50")

    if st.button("Add Observation"):
        feature = np.array([[pt, pd_val, rh, ceo2, zro2, al2o3, 20, 15, 550, 950, 120, 0.5, 0]], dtype=np.float32)
        target = np.array([[co, hc, nox, t50]], dtype=np.float32)
        opt.add_observations(feature, target)
        st.success("✅ Observation added!")


def _render_suggest(opt: BayesianOptimizer):
    """Suggest next experiment batch."""
    st.subheader("Suggest Next Experiment Batch")

    if not opt.gp_fitted:
        st.warning("⚠️ No data loaded yet. Go to Setup tab to load historical data.")
        return

    col1, col2 = st.columns(2)
    with col1:
        n_candidates = st.slider("Candidates per batch", 3, 10, 5, step=1)
    with col2:
        strategy = st.selectbox("Acquisition Function", [
            "Expected Improvement (EI)",
            "Upper Confidence Bound (UCB)",
            "Probability of Improvement (PI)",
        ])

    if st.button("🧪 Generate Candidates", type="primary"):
        candidates = opt.suggest_batch(n_candidates=n_candidates)
        predictions = opt.predict(candidates)

        st.success(f"✅ Generated {n_candidates} candidate formulas")

        for i in range(n_candidates):
            with st.expander(f"Formula #{i+1}", expanded=(i < 3)):
                c = candidates[i]
                p = predictions[i]

                col_a, col_b = st.columns(2)
                with col_a:
                    st.markdown("**Composition:**")
                    st.markdown(f"- Pt: {c[0]:.2f} g/L")
                    st.markdown(f"- Pd: {c[1]:.2f} g/L")
                    st.markdown(f"- Rh: {c[2]:.3f} g/L")
                    st.markdown(f"- CeO₂: {c[3]:.0f} g/L")
                    st.markdown(f"- ZrO₂: {c[4]:.0f} g/L")
                    st.markdown(f"- Al₂O₃: {c[5]:.0f} g/L")
                    cost = compute_pge_cost(c)
                    st.markdown(f"**PGE Cost**: ${cost:.0f}/L")

                with col_b:
                    st.markdown("**Predicted Performance:**")
                    compliance = check_compliance(p)
                    st.markdown(f"- CO: {p[0]:.1f}% {'✅' if compliance['CO']['pass'] else '❌'}")
                    st.markdown(f"- HC: {p[1]:.1f}% {'✅' if compliance['HC']['pass'] else '❌'}")
                    st.markdown(f"- NOx: {p[2]:.1f}% {'✅' if compliance['NOx']['pass'] else '❌'}")
                    st.markdown(f"- T50: {p[3]:.0f}°C {'✅' if compliance['T50']['pass'] else '❌'}")

                    if compliance["all_pass"]:
                        st.success("✅ Meets Euro 6d / China 6b")
                    else:
                        st.warning("⚠️ Does not meet all targets")

        st.session_state["bayes_history"].append({
            "action": "suggest",
            "n_candidates": n_candidates,
            "strategy": strategy,
        })


def _render_history():
    """Show optimization history."""
    st.subheader("Optimization History")

    history = st.session_state.get("bayes_history", [])
    if not history:
        st.info("No optimization steps yet.")
        return

    for i, step in enumerate(history):
        st.markdown(f"**Step {i+1}**: {step['action']}")
        for k, v in step.items():
            if k != "action":
                st.markdown(f"  - {k}: {v}")
