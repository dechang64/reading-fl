# ── analysis/cost_analyzer.py ──
"""
贵金属成本分析引擎

功能：
    - 实时 PGE 价格管理（Pt/Pd/Rh）
    - 配方成本计算（$/L）
    - 成本-性能散点分析
    - Pareto 前沿上的性价比最优点标注
"""

import numpy as np
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, field
from datetime import datetime


# PGE 价格数据（$/oz，可手动更新或接入 API）
PGE_PRICES = {
    "Pt": {"price_per_oz": 1020, "price_per_g": 1020 / 31.103, "name": "Platinum", "emoji": "⚪"},
    "Pd": {"price_per_oz": 980, "price_per_g": 980 / 31.103, "name": "Palladium", "emoji": "🩶"},
    "Rh": {"price_per_oz": 4750, "price_per_g": 4750 / 31.103, "name": "Rhodium", "emoji": "🟡"},
}

# 转化率目标权重（用于综合性能评分）
PERFORMANCE_WEIGHTS = {
    "CO_conv": 0.30,
    "HC_conv": 0.30,
    "NOx_conv": 0.25,
    "T50": 0.15,  # T50 越低越好，需反转
}

# T50 参考范围（用于归一化）
T50_RANGE = (180, 300)


@dataclass
class CostBreakdown:
    """单配方成本明细。"""
    formula_id: str
    pt_cost: float      # $/L
    pd_cost: float      # $/L
    rh_cost: float      # $/L
    total_cost: float   # $/L
    pt_pct: float       # Pt 占比 %
    pd_pct: float       # Pd 占比 %
    rh_pct: float       # Rh 占比 %


@dataclass
class CostPerformancePoint:
    """成本-性能散点上的一个点。"""
    formula_id: str
    total_cost: float       # $/L
    performance_score: float  # 0-100 综合评分
    co_conv: float
    hc_conv: float
    nox_conv: float
    t50: float
    is_pareto: bool = False


class CostAnalyzer:
    """贵金属成本分析器。"""

    def __init__(self, prices: Optional[Dict[str, float]] = None):
        """初始化，可自定义价格。"""
        self.prices = {}
        for elem, info in PGE_PRICES.items():
            self.prices[elem] = prices.get(elem, info["price_per_g"]) if prices else info["price_per_g"]

        self.price_history = {elem: [(datetime.now().strftime("%Y-%m-%d"), self.prices[elem])]
                              for elem in PGE_PRICES}

    def update_price(self, element: str, price_per_oz: float) -> None:
        """更新某元素价格。"""
        if element not in PGE_PRICES:
            raise ValueError(f"Unknown element: {element}")
        self.prices[element] = price_per_oz / 31.103
        self.price_history[element].append((datetime.now().strftime("%Y-%m-%d"), self.prices[element]))

    def compute_cost(self, features: np.ndarray, formula_id: str = "") -> CostBreakdown:
        """计算配方贵金属成本。

        Args:
            features: 配方特征向量，前 3 列为 [Pt, Pd, Rh] g/L
            formula_id: 配方 ID
        """
        pt_loading = features[0]  # g/L
        pd_loading = features[1]
        rh_loading = features[2]

        pt_cost = pt_loading * self.prices["Pt"]
        pd_cost = pd_loading * self.prices["Pd"]
        rh_cost = rh_loading * self.prices["Rh"]
        total = pt_cost + pd_cost + rh_cost

        if total > 0:
            pt_pct = pt_cost / total * 100
            pd_pct = pd_cost / total * 100
            rh_pct = rh_cost / total * 100
        else:
            pt_pct = pd_pct = rh_pct = 0

        return CostBreakdown(
            formula_id=formula_id,
            pt_cost=round(pt_cost, 2),
            pd_cost=round(pd_cost, 2),
            rh_cost=round(rh_cost, 2),
            total_cost=round(total, 2),
            pt_pct=round(pt_pct, 1),
            pd_pct=round(pd_pct, 1),
            rh_pct=round(rh_pct, 1),
        )

    def compute_performance_score(self, targets: np.ndarray) -> float:
        """计算综合性能评分（0-100）。

        转化率越高越好，T50 越低越好。
        """
        co_score = min(targets[0] / 100.0, 1.0) * 100
        hc_score = min(targets[1] / 100.0, 1.0) * 100
        nox_score = min(targets[2] / 100.0, 1.0) * 100

        # T50: 越低越好，180°C=满分，300°C=0分
        t50_norm = 1.0 - np.clip((targets[3] - T50_RANGE[0]) / (T50_RANGE[1] - T50_RANGE[0]), 0, 1)
        t50_score = t50_norm * 100

        score = (PERFORMANCE_WEIGHTS["CO_conv"] * co_score +
                 PERFORMANCE_WEIGHTS["HC_conv"] * hc_score +
                 PERFORMANCE_WEIGHTS["NOx_conv"] * nox_score +
                 PERFORMANCE_WEIGHTS["T50"] * t50_score)
        return round(score, 2)

    def compute_cost_performance_points(
        self,
        features: np.ndarray,
        targets: np.ndarray,
        formula_ids: Optional[List[str]] = None,
    ) -> List[CostPerformancePoint]:
        """计算一批配方的成本-性能散点。"""
        n = len(features)
        ids = formula_ids or [f"f_{i}" for i in range(n)]
        points = []

        for i in range(n):
            cost = self.compute_cost(features[i], ids[i])
            perf = self.compute_performance_score(targets[i])
            points.append(CostPerformancePoint(
                formula_id=ids[i],
                total_cost=cost.total_cost,
                performance_score=perf,
                co_conv=targets[i][0],
                hc_conv=targets[i][1],
                nox_conv=targets[i][2],
                t50=targets[i][3],
            ))

        return points

    def analyze_cost_performance(
        self,
        features: np.ndarray,
        targets: np.ndarray,
        formula_ids: Optional[List[str]] = None,
    ) -> List[CostPerformancePoint]:
        """计算成本-性能散点并标记 Pareto 前沿。"""
        points = self.compute_cost_performance_points(features, targets, formula_ids)
        self.find_pareto_frontier(points)
        return points

    def find_pareto_frontier(self, points: List[CostPerformancePoint]) -> List[CostPerformancePoint]:
        """找 Pareto 前沿（成本最小 + 性能最大）。

        返回前沿上的点，并标记 is_pareto=True。
        """
        if not points:
            return []

        # 标记所有点
        for p in points:
            p.is_pareto = False

        pareto = []
        for i, p in enumerate(points):
            dominated = False
            for j, q in enumerate(points):
                if i == j:
                    continue
                # q dominates p if q is cheaper AND better performing
                if q.total_cost <= p.total_cost and q.performance_score >= p.performance_score:
                    if q.total_cost < p.total_cost or q.performance_score > p.performance_score:
                        dominated = True
                        break
            if not dominated:
                p.is_pareto = True
                pareto.append(p)

        return sorted(pareto, key=lambda x: x.total_cost)

    def find_best_value(self, points: List[CostPerformancePoint]) -> Optional[CostPerformancePoint]:
        """找性价比最优点（Pareto 前沿上性能/成本比最高的）。"""
        pareto = [p for p in points if p.is_pareto]
        if not pareto:
            return None
        return max(pareto, key=lambda p: p.performance_score / max(p.total_cost, 0.01))

    def compare_with_baseline(
        self,
        features: np.ndarray,
        targets: np.ndarray,
        baseline_idx: int = 0,
    ) -> Dict[str, float]:
        """与基准配方对比，计算节省百分比。"""
        base_cost = self.compute_cost(features[baseline_idx])
        base_perf = self.compute_performance_score(targets[baseline_idx])

        results = []
        for i in range(len(features)):
            if i == baseline_idx:
                continue
            cost = self.compute_cost(features[i])
            perf = self.compute_performance_score(targets[i])
            cost_saving = (base_cost.total_cost - cost.total_cost) / base_cost.total_cost * 100
            perf_change = perf - base_perf
            results.append({
                "formula_id": f"f_{i}",
                "cost_saving_pct": round(cost_saving, 1),
                "perf_change": round(perf_change, 1),
                "cost": cost.total_cost,
                "perf": perf,
            })

        return sorted(results, key=lambda x: x["cost_saving_pct"], reverse=True)

    def get_price_summary(self) -> Dict[str, Dict]:
        """获取当前价格摘要。"""
        summary = {}
        for elem, info in PGE_PRICES.items():
            summary[elem] = {
                "name": info["name"],
                "emoji": info["emoji"],
                "price_per_oz": round(self.prices[elem] * 31.103, 0),
                "price_per_g": round(self.prices[elem], 2),
            }
        return summary
