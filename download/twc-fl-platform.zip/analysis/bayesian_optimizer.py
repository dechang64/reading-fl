# ── analysis/bayesian_optimizer.py ──
"""
Bayesian Optimizer for TWC Formulation
======================================
Recommends next experiment batches using Gaussian Process surrogate model.
"""

import numpy as np
from typing import Optional
from scipy.stats import norm
from scipy.optimize import minimize


class BayesianOptimizer:
    """Bayesian optimization for catalyst formulation.

    Uses Gaussian Process with RBF kernel as surrogate model.
    Optimizes for: maximize conversion rates, minimize PGE cost.

    Usage:
        opt = BayesianOptimizer(n_features=13)
        opt.add_observations(X_known, y_known)
        candidates = opt.suggest_batch(n_candidates=5)
    """

    def __init__(
        self,
        n_features: int = 13,
        objective_weights: Optional[dict] = None,
    ):
        self.n_features = n_features
        self.X_obs = None  # observed features
        self.y_obs = None  # observed targets
        self.gp_mean = None
        self.gp_cov = None

        # Objective: maximize weighted sum of (CO + HC + NOx) - cost_penalty
        self.objective_weights = objective_weights or {
            "CO": 1.0,
            "HC": 1.0,
            "NOx": 1.0,
            "cost_penalty": 0.001,
        }

        # Feature bounds for candidate generation
        self.bounds = np.array([
            [0.5, 5.0],    # Pt
            [0.5, 8.0],    # Pd
            [0.05, 0.5],   # Rh
            [50, 200],     # CeO2
            [20, 100],     # ZrO2
            [100, 250],    # Al2O3
            [5, 30],       # La2O3
            [5, 25],       # BaO
            [400, 700],    # Calcination temp
            [800, 1100],   # Aging temp
            [50, 200],     # Surface area
            [0.3, 1.0],    # Pore volume
            [0.0, 1.0],    # Extra feature (placeholder)
        ], dtype=np.float64)

    def add_observations(self, X: np.ndarray, y: np.ndarray):
        """Add observed (features, targets) to the surrogate model."""
        if self.X_obs is None:
            self.X_obs = X.copy()
            self.y_obs = y.copy()
        else:
            self.X_obs = np.vstack([self.X_obs, X])
            self.y_obs = np.vstack([self.y_obs, y])

        self._fit_gp()

    def _compute_objective(self, y: np.ndarray, X: np.ndarray) -> np.ndarray:
        """Compute scalar objective from targets.

        Higher is better: weighted conversion - cost penalty.
        """
        w = self.objective_weights
        obj = (
            w["CO"] * y[:, 0] +
            w["HC"] * y[:, 1] +
            w["NOx"] * y[:, 2] -
            w["cost_penalty"] * self._estimate_cost(X)
        )
        return obj

    def _estimate_cost(self, X: np.ndarray) -> np.ndarray:
        """Rough PGE cost estimate from features."""
        # Pt ~$1020/oz, Pd ~$980/oz, Rh ~$4750/oz, 1oz=31.103g
        return (
            X[:, 0] / 31.103 * 1020 +
            X[:, 1] / 31.103 * 980 +
            X[:, 2] / 31.103 * 4750
        )

    def _rbf_kernel(self, X1: np.ndarray, X2: np.ndarray, length_scale: float = 1.0) -> np.ndarray:
        """RBF (squared exponential) kernel."""
        # Normalize features for kernel computation
        X1_norm = X1 / (self.bounds[:, 1] - self.bounds[:, 0])
        X2_norm = X2 / (self.bounds[:, 1] - self.bounds[:, 0])

        sq_dist = np.sum((X1_norm[:, None, :] - X2_norm[None, :, :]) ** 2, axis=2)
        return np.exp(-0.5 * sq_dist / (length_scale ** 2))

    def _fit_gp(self, length_scale: float = 0.5, noise: float = 0.01):
        """Fit GP to observed data."""
        if self.X_obs is None or len(self.X_obs) < 2:
            return

        K = self._rbf_kernel(self.X_obs, self.X_obs, length_scale)
        K += noise * np.eye(len(K))

        # Compute objective for observed data
        obj = self._compute_objective(self.y_obs, self.X_obs)

        try:
            L = np.linalg.cholesky(K)
            alpha = np.linalg.solve(L.T, np.linalg.solve(L, obj))
            self.gp_mean = alpha
            self.gp_cov = K
            self._gp_L = L
            self._gp_length_scale = length_scale
        except np.linalg.LinAlgError:
            self.gp_mean = None

    def _predict_gp(self, X_new: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """GP prediction at new points. Returns (mean, std)."""
        if self.gp_mean is None:
            return np.zeros(len(X_new)), np.ones(len(X_new))

        K_star = self._rbf_kernel(X_new, self.X_obs, self._gp_length_scale)
        K_ss = self._rbf_kernel(X_new, X_new, self._gp_length_scale)

        mean = K_star @ self.gp_mean
        v = np.linalg.solve(self._gp_L, K_star.T)
        var = np.diag(K_ss) - np.sum(v ** 2, axis=0)
        std = np.sqrt(np.maximum(var, 1e-10))

        return mean, std

    def _expected_improvement(self, X: np.ndarray, xi: float = 0.01) -> np.ndarray:
        """Compute Expected Improvement acquisition function."""
        if self.gp_mean is None:
            return np.random.rand(len(X))

        mu, sigma = self._predict_gp(X)
        best_observed = self._compute_objective(self.y_obs, self.X_obs).max()

        with np.errstate(divide="warn"):
            imp = mu - best_observed - xi
            Z = imp / sigma
            ei = imp * norm.cdf(Z) + sigma * norm.pdf(Z)
            ei[sigma < 1e-10] = 0.0

        return ei

    def suggest_batch(
        self,
        n_candidates: int = 5,
        n_random: int = 1000,
        seed: int = 42,
    ) -> np.ndarray:
        """Suggest next batch of candidate formulations.

        Uses Expected Improvement + random exploration.
        """
        rng = np.random.RandomState(seed)

        # Generate random candidates within bounds
        random_candidates = np.column_stack([
            rng.uniform(lo, hi, n_random)
            for lo, hi in self.bounds
        ])

        # If we have observations, use EI to select
        if self.gp_mean is not None and len(self.X_obs) >= 3:
            ei_scores = self._expected_improvement(random_candidates)
            # Select top candidates by EI
            top_idx = np.argsort(ei_scores)[-n_candidates:]
            candidates = random_candidates[top_idx]
        else:
            # Pure random exploration
            idx = rng.choice(n_random, n_candidates, replace=False)
            candidates = random_candidates[idx]

        # Ensure candidates are within bounds
        candidates = np.clip(candidates, self.bounds[:, 0], self.bounds[:, 1])

        return candidates.astype(np.float32)

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict targets for given features using GP surrogate."""
        if self.gp_mean is None:
            # No model fitted — return mean of observations
            if self.y_obs is not None:
                return np.tile(self.y_obs.mean(axis=0), (len(X), 1))
            return np.zeros((len(X), 4))

        # Use GP to predict objective, then map back to rough target estimates
        mu, _ = self._predict_gp(X)
        # Simple mapping: scale objective back to approximate targets
        obj_mean = self._compute_objective(self.y_obs, self.X_obs).mean()
        obj_std = self._compute_objective(self.y_obs, self.X_obs).std()
        if obj_std > 0:
            scale = (mu - obj_mean) / obj_std
        else:
            scale = np.zeros_like(mu)

        # Approximate: shift targets proportionally
        base_targets = self.y_obs.mean(axis=0)
        predictions = np.outer(1 + scale * 0.1, base_targets)
        return predictions.astype(np.float32)

    def get_stats(self) -> dict:
        """Return optimizer statistics."""
        n_obs = len(self.X_obs) if self.X_obs is not None else 0
        return {
            "n_observations": n_obs,
            "gp_fitted": self.gp_mean is not None,
            "feature_dim": self.n_features,
        }
