# ── analysis/knowledge_hub.py ──
"""
TWC Knowledge Hub
=================
Domain knowledge base for three-way catalyst R&D.
Provides FAQ, literature references, and formula recommendations.
"""

import numpy as np
from typing import Optional


# ── TWC FAQ Database ──
TWC_FAQ = [
    {
        "id": 1,
        "question": "三元催化器的核心工作原理是什么？",
        "answer": "三元催化器通过贵金属（Pt/Pd/Rh）催化剂，同时将三种有害气体转化为无害物质：CO→CO₂（氧化），HC→CO₂+H₂O（氧化），NOx→N₂（还原）。\"三元\"即指同时处理这三种气体。催化剂负载在蜂窝状陶瓷载体（堇青石）上，工作温度窗口通常为200-400°C。",
        "category": "配方设计原理",
        "tags": ["基础原理", "氧化还原", "工作温度"],
    },
    {
        "id": 2,
        "question": "为什么Rh（铑）如此重要且稀缺？",
        "answer": "Rh是NOx还原反应最有效的催化剂，对NO→N₂的选择性远高于Pt和Pd。全球Rh年产量仅约25吨，价格高达$4750/盎司（2024）。Rh主要产自南非和俄罗斯，地缘政治风险极高。降低Rh用量是TWC行业最紧迫的研发目标之一。",
        "category": "贵金属优化",
        "tags": ["Rh", "稀缺性", "NOx还原", "成本"],
    },
    {
        "id": 3,
        "question": "如何降低Rh载量同时保持NOx转化率？",
        "answer": "主要策略：(1) 使用CeO₂-ZrO₂固溶体作为储氧材料，增强低温NOx还原；(2) 优化Pd/Rh比例，Pd可以部分替代Rh的氧化功能；(3) 添加BaO、La₂O₃等助剂稳定Rh分散度；(4) 采用分层涂覆技术，将Rh集中在表层提高利用率；(5) 通过FL联合训练AI模型，在全行业数据上学习最优配方空间。",
        "category": "贵金属优化",
        "tags": ["Rh替代", "CeO2", "助剂", "分层涂覆"],
    },
    {
        "id": 4,
        "question": "老化机理是什么？如何提高热稳定性？",
        "answer": "TWC老化主要有三种机制：(1) 烧结：高温（>800°C）导致贵金属颗粒长大，比表面积下降；(2) 活性涂层剥落：热循环导致涂层开裂；(3) 毒化：P、S、Pb等杂质覆盖活性位点。提高稳定性的方法：添加ZrO₂稳定CeO₂晶相、使用高热稳定性Al₂O₃（如θ-Al₂O₃）、优化焙烧温度。",
        "category": "老化机理",
        "tags": ["烧结", "热稳定性", "ZrO2", "毒化"],
    },
    {
        "id": 5,
        "question": "Euro 6d和China 6b排放标准的具体要求是什么？",
        "answer": "Euro 6d (2023+)：CO≤1.0g/km, HC≤0.1g/km, NOx≤0.06g/km (汽油), PM≤4.5mg/km。China 6b (2023)：与Euro 6d基本一致，但增加了RDE（实际驾驶排放）测试要求。催化转化率通常需要达到：CO≥94%, HC≥94%, NOx≥90%才能满足标准。T50（起燃温度）应低于250°C。",
        "category": "排放法规",
        "tags": ["Euro 6d", "China 6b", "排放标准", "RDE"],
    },
    {
        "id": 6,
        "question": "CeO₂在TWC中的作用是什么？",
        "answer": "CeO₂（二氧化铈）是TWC中最关键的储氧材料（OSC）。其核心功能：(1) 储氧/释氧：Ce⁴⁺⇌Ce³⁺+½O₂，在贫燃/富燃循环中缓冲氧浓度；(2) 促进水煤气变换反应：CO+H₂O→CO₂+H₂；(3) 稳定贵金属分散度；(4) 与ZrO₂形成固溶体可显著提高热稳定性和还原能力。典型添加量50-200 g/L。",
        "category": "配方设计原理",
        "tags": ["CeO2", "储氧", "OSC", "水煤气变换"],
    },
    {
        "id": 7,
        "question": "联邦学习如何保护催化剂配方数据？",
        "answer": "TWC-FL平台采用以下隐私保护机制：(1) 数据不出厂：每家企业的配方数据始终存储在本地服务器；(2) 仅上传梯度：FL训练时只上传模型参数更新（梯度），不传输原始数据；(3) 梯度加密：使用安全聚合协议加密梯度传输；(4) 区块链存证：每次数据交换记录在不可篡改的审计链上；(5) 差分隐私：可选添加噪声进一步保护隐私。",
        "category": "FL协作指南",
        "tags": ["隐私保护", "数据安全", "梯度加密", "区块链"],
    },
    {
        "id": 8,
        "question": "如何表征催化剂的性能？",
        "answer": "核心表征方法：(1) 活性评价：使用固定床反应器测量CO/HC/NOx转化率随温度变化曲线，获取T50/T90；(2) BET比表面积：N₂吸附测定比表面积和孔结构；(3) XRD：分析活性相晶相组成和晶粒尺寸；(4) TEM/SEM：观察贵金属分散度和颗粒大小；(5) H₂-TPR：程序升温还原评估氧化还原性能；(6) CO化学吸附：测定贵金属分散度和活性表面积。",
        "category": "表征方法",
        "tags": ["BET", "XRD", "TEM", "TPR", "活性评价"],
    },
    {
        "id": 9,
        "question": "Pd和Pt在TWC中有什么区别？",
        "answer": "Pt（铂）：对CO和HC氧化活性高，耐高温性好，但价格较高。Pd（钯）：对HC氧化活性优异，价格相对较低，但高温稳定性不如Pt。现代TWC趋势：(1) 汽油车：Pd基催化剂为主（Pd/Rh体系），成本更低；(2) 柴油车：Pt基为主（Pt/Pd/Rh三元体系），因柴油需要更好的NOx还原；(3) 超低排放：需要全PGE组合以覆盖宽温度窗口。",
        "category": "贵金属优化",
        "tags": ["Pt", "Pd", "汽油车", "柴油车"],
    },
    {
        "id": 10,
        "question": "什么是T50温度？为什么它很重要？",
        "answer": "T50（Light-off Temperature）是催化剂达到50%转化率时的温度，是衡量催化剂低温活性的关键指标。T50越低，催化剂冷启动性能越好。典型值：新鲜催化剂T50≈180-220°C，老化后T50可能升至250-300°C。降低T50的策略：提高贵金属分散度、优化储氧材料、增加比表面积。",
        "category": "配方设计原理",
        "tags": ["T50", "起燃温度", "冷启动", "低温活性"],
    },
    {
        "id": 11,
        "question": "如何参与TWC-FL联邦学习？",
        "answer": "参与步骤：(1) 注册：在平台注册企业账号，获取FL节点凭证；(2) 数据准备：将配方数据整理为CSV格式（列：Pt/Pd/Rh载量、涂层成分、热处理条件、性能指标）；(3) 数据脱敏：平台自动脱敏，移除企业标识信息；(4) 本地训练：在本地服务器运行FL客户端，训练数据不离开企业；(5) 梯度上传：加密上传模型更新，参与全局模型聚合；(6) 模型获取：获得融合全行业知识的全局预测模型。",
        "category": "FL协作指南",
        "tags": ["参与流程", "数据准备", "本地训练"],
    },
    {
        "id": 12,
        "question": "贝叶斯优化如何帮助配方设计？",
        "answer": "贝叶斯优化（Bayesian Optimization）用高斯过程（GP）构建配方-性能的代理模型，然后用采集函数（如Expected Improvement）智能选择下一批实验配方。优势：(1) 样本高效：比随机搜索减少60%以上的实验次数；(2) 全局优化：平衡探索（新区域）和利用（已知好区域）；(3) 自动更新：每轮实验结果回填后模型自动改进。TWC-FL平台的Bayesian Optimizer模块可直接推荐3-5个候选配方。",
        "category": "配方设计原理",
        "tags": ["贝叶斯优化", "实验设计", "高斯过程"],
    },
    {
        "id": 13,
        "question": "ZrO₂在TWC中的作用是什么？",
        "answer": "ZrO₂（二氧化锆）在TWC中的核心作用：(1) 与CeO₂形成CeO₂-ZrO₂固溶体，显著提高储氧能力和热稳定性；(2) 抑制CeO₂从立方相向单斜相转变，保持OSC性能；(3) 提高涂层的热机械稳定性，减少开裂；(4) 适量的ZrO₂（20-100 g/L）可降低T50约20-30°C。最佳Ce/Zr比通常为3:1到1:1。",
        "category": "配方设计原理",
        "tags": ["ZrO2", "固溶体", "热稳定性", "CeZrO"],
    },
    {
        "id": 14,
        "question": "如何评估催化剂的老化性能？",
        "answer": "标准老化测试方法：(1) 水热老化：在10% H₂O/空气中，800-1000°C处理4-24小时；(2) 热冲击：快速升温-降温循环（100°C→900°C→100°C）；(3) 累积老化：模拟实际行驶里程（如10万公里等效）；(4) 化学老化：暴露于P、S等毒化物。老化后重新测量T50和转化率，合格标准：老化后T50升高不超过50°C，转化率下降不超过10个百分点。",
        "category": "老化机理",
        "tags": ["水热老化", "热冲击", "累积老化", "评价方法"],
    },
    {
        "id": 15,
        "question": "分层涂覆技术是什么？",
        "answer": "分层涂覆（Layered Washcoat）是将不同功能的催化层依次涂覆在载体上的技术。典型结构：底层（靠近载体）— 高比表面积Al₂O₃+Pd，负责HC/CO氧化；顶层（靠近气流）— Rh+CeO₂-ZrO₂，负责NOx还原。优势：(1) Rh集中在表层，利用率提高30-50%；(2) 各层独立优化，避免组分干扰；(3) 可减少总贵金属用量20-40%。",
        "category": "配方设计原理",
        "tags": ["分层涂覆", "涂层结构", "Rh利用率"],
    },
    {
        "id": 16,
        "question": "AI如何加速催化剂研发？",
        "answer": "AI在催化剂研发中的应用：(1) 性能预测：ML模型从配方直接预测转化率和T50，替代部分实验（MAE目标<±5°C）；(2) 配方优化：贝叶斯优化+遗传算法搜索最优配方空间；(3) 老化预测：预测催化剂寿命，减少老化实验次数；(4) 联邦学习：多家企业联合训练，数据量越大模型越准；(5) 文献挖掘：NLP自动提取论文中的配方-性能数据。据Nature Chemical Biology (2025)，AI+自动化可将实验次数压缩60%以上。",
        "category": "FL协作指南",
        "tags": ["AI", "机器学习", "性能预测", "文献挖掘"],
    },
    {
        "id": 17,
        "question": "Al₂O₃载体的选择标准是什么？",
        "answer": "TWC用Al₂O₃载体的关键指标：(1) 比表面积：γ-Al₂O₃通常150-250 m²/g，老化后应保持>80 m²/g；(2) 相稳定性：高温下γ→α相转变导致比表面积骤降，添加La₂O₃/BaO可稳定γ相；(3) 孔结构：中孔（5-20nm）有利于贵金属分散和反应物扩散；(4) 纯度：Na₂O、Fe₂O₃等杂质应<0.05%，避免毒化贵金属。常用La稳定Al₂O₃（La₂O₃含量2-5 wt%）。",
        "category": "配方设计原理",
        "tags": ["Al2O3", "载体", "比表面积", "相稳定性"],
    },
    {
        "id": 18,
        "question": "什么是储氧能力（OSC）？如何测量？",
        "answer": "储氧能力（Oxygen Storage Capacity, OSC）是TWC性能的关键指标，定义为催化剂在贫燃/富燃切换时可储存和释放的氧量（μmol O₂/g cat）。测量方法：(1) 脉冲法：交替通入O₂和CO脉冲，测量CO₂生成量；(2) 程序升温法：在H₂/Ar中程序升温还原，积分H₂消耗量。典型值：新鲜催化剂OSC≈500-1000 μmol O₂/g，老化后降至200-400 μmol O₂/g。CeO₂-ZrO₂固溶体的OSC比纯CeO₂高30-50%。",
        "category": "表征方法",
        "tags": ["OSC", "储氧", "测量方法", "CeO2"],
    },
    {
        "id": 19,
        "question": "主机厂（OEM）如何从TWC-FL平台受益？",
        "answer": "OEM获益方式：(1) 供应商筛选：OEM Bridge模块根据排放目标自动匹配已认证供应商；(2) 缩短认证周期：AI预测+FL联合模型可提前预判配方合规性，认证周期从18个月缩短至11个月；(3) 早期介入R&D：主机厂可在配方设计阶段就参与，而非等到样品阶段；(4) 供应链透明：区块链审计链提供完整的配方验证和合规记录。",
        "category": "FL协作指南",
        "tags": ["OEM", "主机厂", "供应商筛选", "认证"],
    },
    {
        "id": 20,
        "question": "如何将实验室成果导入产业端？",
        "answer": "成果转化路径：(1) 数据标准化：将实验室配方数据整理为平台标准格式（CSV/JSON）；(2) 模型验证：用平台预测模型交叉验证实验室结果，确保一致性；(3) 脱敏共享：通过FL将实验室数据贡献到全局模型，不泄露具体配方；(4) 中试验证：用Bayesian Optimizer推荐中试配方，减少试错；(5) 产业认证：通过平台对接主机厂认证流程。西浦AI融创工坊（AMR+机械臂+CNC+3D打印+MES）提供硬件验证能力。",
        "category": "FL协作指南",
        "tags": ["成果转化", "中试", "标准化", "认证"],
    },
]


class KnowledgeHub:
    """TWC domain knowledge base with search capability."""

    def __init__(self):
        self.faq = TWC_FAQ
        self._build_index()

    def _build_index(self):
        """Build simple keyword index for FAQ search."""
        self._index = {}
        for item in self.faq:
            words = set()
            for field in ["question", "answer", "category"]:
                for tag in item.get("tags", []):
                    words.add(tag.lower())
                for char in field:
                    if '\u4e00' <= char <= '\u9fff':
                        words.add(char)
            for word in words:
                if word not in self._index:
                    self._index[word] = []
                self._index[word].append(item["id"])

    def search(self, query: str, top_k: int = 5) -> list[dict]:
        """Search FAQ by query string.

        Uses simple keyword matching + category scoring.
        """
        query_lower = query.lower()
        scores = {}

        for item in self.faq:
            score = 0.0
            # Exact match in question
            if query_lower in item["question"].lower():
                score += 10.0
            # Keyword match in tags
            for tag in item.get("tags", []):
                if tag.lower() in query_lower or query_lower in tag.lower():
                    score += 5.0
            # Character overlap in question
            q_chars = set(query_lower)
            item_chars = set(item["question"].lower())
            overlap = len(q_chars & item_chars)
            score += overlap * 0.5
            # Category match
            for cat in item.get("category", ""):
                if cat in query:
                    score += 3.0

            if score > 0:
                scores[item["id"]] = score

        # Sort by score
        ranked_ids = sorted(scores.keys(), key=lambda x: scores[x], reverse=True)[:top_k]

        results = []
        for item_id in ranked_ids:
            item = next(f for f in self.faq if f["id"] == item_id)
            results.append({
                **item,
                "relevance_score": scores[item_id],
            })

        return results

    def get_by_category(self, category: str) -> list[dict]:
        """Get all FAQ items in a category."""
        return [f for f in self.faq if f["category"] == category]

    def get_categories(self) -> list[str]:
        """Get all FAQ categories."""
        return sorted(set(f["category"] for f in self.faq))

    def get_stats(self) -> dict:
        """Return knowledge base statistics."""
        categories = self.get_categories()
        return {
            "total_questions": len(self.faq),
            "categories": len(categories),
            "category_distribution": {
                cat: len(self.get_by_category(cat)) for cat in categories
            },
        }
