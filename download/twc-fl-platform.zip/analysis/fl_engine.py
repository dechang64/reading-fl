# ── analysis/fl_engine.py ──
"""
Federated Learning Engine for TWC Platform
===========================================
Core FL simulation: FedAvg aggregation for catalyst performance prediction.
Pure PyTorch — no external FL framework dependency.

Predicts: CO conversion, HC conversion, NOx conversion, T50 temperature
"""

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from collections import OrderedDict
from typing import Optional, Callable
import time


class CatalystPredictor(nn.Module):
    """MLP regressor for catalyst performance prediction.

    Input: catalyst composition features (13 dims)
    Output: [CO_conv, HC_conv, NOx_conv, T50]
    """

    def __init__(self, input_dim: int = 13, hidden_dim: int = 64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, 4),  # 4 targets
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


def set_params(model: nn.Module, params: OrderedDict) -> None:
    """Load parameters into model."""
    model.load_state_dict(params)


def get_params(model: nn.Module) -> OrderedDict:
    """Extract parameters from model."""
    return OrderedDict(
        (name, param.data.clone()) for name, param in model.named_parameters()
    )


def fedavg_aggregate(
    client_params: list[OrderedDict],
    weights: Optional[list[int]] = None,
) -> OrderedDict:
    """FedAvg aggregation: weighted average of client parameters."""
    if weights is None:
        weights = [1] * len(client_params)

    total = sum(weights)
    aggregated = OrderedDict()

    for key in client_params[0].keys():
        weighted_sum = sum(
            w * params[key].float() for params, w in zip(client_params, weights)
        )
        aggregated[key] = weighted_sum / total

    return aggregated


def train_local(
    model: nn.Module,
    X: np.ndarray,
    y: np.ndarray,
    epochs: int = 2,
    lr: float = 0.001,
    batch_size: int = 32,
) -> tuple[float, float]:
    """Train model on local data. Returns (loss, r2_score)."""
    model.train()
    optimizer = optim.Adam(model.parameters(), lr=lr)

    # Loss: MSE (targets are already normalized)
    criterion = nn.MSELoss()

    dataset = TensorDataset(
        torch.FloatTensor(X), torch.FloatTensor(y)
    )
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

    total_loss = 0.0
    n_batches = 0

    for _ in range(epochs):
        for bx, by in loader:
            optimizer.zero_grad()
            pred = model(bx)
            loss = criterion(pred, by)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
            n_batches += 1

    avg_loss = total_loss / max(n_batches, 1)

    # Compute R² score
    model.eval()
    with torch.no_grad():
        all_pred = model(torch.FloatTensor(X)).numpy()
    ss_res = np.sum((y - all_pred) ** 2)
    ss_tot = np.sum((y - y.mean(axis=0)) ** 2)
    r2 = 1 - ss_res / max(ss_tot, 1e-8)

    return avg_loss, float(r2)


def evaluate_model(
    model: nn.Module,
    X: np.ndarray,
    y: np.ndarray,
    batch_size: int = 64,
) -> tuple[float, float]:
    """Evaluate model. Returns (loss, r2_score)."""
    model.eval()
    with torch.no_grad():
        pred = model(torch.FloatTensor(X)).numpy()

    mse = np.mean((y - pred) ** 2)
    ss_res = np.sum((y - pred) ** 2)
    ss_tot = np.sum((y - y.mean(axis=0)) ** 2)
    r2 = 1 - ss_res / max(ss_tot, 1e-8)

    return float(mse), float(r2)


class FLEngine:
    """Federated Learning engine for catalyst performance prediction.

    Usage:
        engine = FLEngine(input_dim=13)
        history = engine.train(client_data, n_rounds=10)
    """

    def __init__(
        self,
        input_dim: int = 13,
        hidden_dim: int = 64,
        lr: float = 0.001,
        batch_size: int = 32,
        local_epochs: int = 2,
    ):
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.lr = lr
        self.batch_size = batch_size
        self.local_epochs = local_epochs
        self.global_model = None
        self.global_params = None
        self.history = []

    def train(
        self,
        client_data: list[tuple[np.ndarray, np.ndarray]],
        n_rounds: int = 10,
        progress_callback: Optional[Callable] = None,
    ) -> list[dict]:
        """Run federated training across clients.

        Args:
            client_data: list of (features, targets) per client
            n_rounds: number of FL rounds
            progress_callback: optional callback(round, metrics)
        """
        # Initialize global model
        global_model = CatalystPredictor(
            input_dim=self.input_dim, hidden_dim=self.hidden_dim
        )
        global_params = get_params(global_model)

        # Normalize targets for stable training
        # Collect all targets to compute global stats
        all_targets = np.concatenate([cy for _, cy in client_data], axis=0)
        self.target_mean = all_targets.mean(axis=0)
        self.target_std = all_targets.std(axis=0).clip(min=1e-6)

        # Normalize client data
        norm_client_data = []
        for cX, cy in client_data:
            norm_cy = (cy - self.target_mean) / self.target_std
            norm_client_data.append((cX, norm_cy))

        # Create validation set from last 20% of each client
        val_parts_X, val_parts_y = [], []
        for cX, cy in norm_client_data:
            split = int(len(cX) * 0.8)
            val_parts_X.append(cX[split:])
            val_parts_y.append(cy[split:])
        val_X = np.concatenate(val_parts_X, axis=0)
        val_y = np.concatenate(val_parts_y, axis=0)

        history = []

        for rnd in range(1, n_rounds + 1):
            t0 = time.time()
            client_params_list = []
            client_metrics = []

            for cid, (cX, cy) in enumerate(norm_client_data):
                # Split local train/val
                split = int(len(cX) * 0.8)
                train_X, train_y = cX[:split], cy[:split]

                # Create local model from global params
                local_model = CatalystPredictor(
                    input_dim=self.input_dim, hidden_dim=self.hidden_dim
                )
                set_params(local_model, global_params)

                # Train locally
                train_loss, train_r2 = train_local(
                    local_model, train_X, train_y,
                    epochs=self.local_epochs, lr=self.lr,
                    batch_size=self.batch_size,
                )

                # Collect params
                client_params_list.append(get_params(local_model))
                client_metrics.append({
                    "client_id": cid,
                    "train_loss": train_loss,
                    "train_r2": train_r2,
                    "n_samples": len(train_X),
                })

            # Aggregate with sample weighting
            client_weights = [m["n_samples"] for m in client_metrics]
            global_params = fedavg_aggregate(client_params_list, client_weights)

            # Evaluate global model
            set_params(global_model, global_params)
            val_loss, val_r2 = evaluate_model(global_model, val_X, val_y, self.batch_size)

            elapsed = time.time() - t0
            round_metrics = {
                "round": rnd,
                "avg_train_loss": np.mean([m["train_loss"] for m in client_metrics]),
                "avg_train_r2": np.mean([m["train_r2"] for m in client_metrics]),
                "val_loss": val_loss,
                "val_r2": val_r2,
                "elapsed": elapsed,
                "client_metrics": client_metrics,
            }
            history.append(round_metrics)

            if progress_callback:
                progress_callback(rnd, round_metrics)

        self.global_model = global_model
        self.global_params = global_params
        self.history = history

        return history
