# ── analysis/explainer.py ──
"""
SHAP 可解释性引擎

功能：
    - 基于 SHAP 的特征重要性分析
    - 单配方 Waterfall 解释图
    - 多配方对比分析
    - 与 Bayesian Optimizer 联动
"""

import numpy as np
from typing import Dict, List, Optional, Tuple

# 特征名称映射
FEATURE_NAMES = [
    "Pt 载量 (g/L)", "Pd 载量 (g/L)", "Rh 载量 (g/L)",
    "CeO₂ (wt%)", "ZrO₂ (wt%)", "Al₂O₃ (wt%)",
    "La₂O₃ (wt%)", "BaO (wt%)",
    "焙烧温度 (°C)", "老化温度 (°C)",
    "比表面积 (m²/g)", "孔体积 (mL/g)", "Extra",
]

# 目标名称
TARGET_NAMES = ["CO 转化率 (%)", "HC 转化率 (%)", "NOx 转化率 (%)", "T50 (°C)"]

# 特征分组（用于可视化）
FEATURE_GROUPS = {
    "贵金属": [0, 1, 2],
    "储氧材料": [3, 4, 5],
    "助剂": [6, 7],
    "工艺参数": [8, 9],
    "物理性质": [10, 11],
}


class SHAPExplainer:
    """轻量级 SHAP 解释器（纯 NumPy，无 shap 库依赖）。

    使用排列重要性 + 线性近似计算特征贡献。
    适用于 Streamlit Cloud 部署（无需编译 shap 库）。
    """

    def __init__(self, model_fn=None, feature_names: Optional[List[str]] = None):
        """初始化解释器。

        Args:
            model_fn: 预测函数 f(features) -> targets (numpy array)
            feature_names: 特征名称列表
        """
        self.model_fn = model_fn
        self.feature_names = feature_names or FEATURE_NAMES
        self.n_features = len(self.feature_names)
        self._fitted = False
        self.base_values = None
        self.feature_importance = None

    def fit(self, X: np.ndarray, y: Optional[np.ndarray] = None, n_samples: int = 200) -> "SHAPExplainer":
        """拟合解释器，计算特征重要性。

        使用排列重要性方法：
        1. 计算基准预测值
        2. 逐特征排列，观察预测变化
        3. 变化幅度 = 特征重要性
        """
        n = min(len(X), n_samples)
        indices = np.random.choice(len(X), n, replace=False)
        X_sample = X[indices]

        if self.model_fn is not None:
            base_preds = self.model_fn(X_sample)
            if base_preds.ndim == 1:
                base_preds = base_preds.reshape(-1, 1)
            self.base_values = np.mean(base_preds, axis=0)
        else:
            # 无模型时使用目标值作为代理
            if y is not None:
                self.base_values = np.mean(y[indices], axis=0)
            else:
                self.base_values = np.zeros(4)

        # 排列重要性
        importance = np.zeros((self.n_features, len(self.base_values)))

        for feat_idx in range(self.n_features):
            X_permuted = X_sample.copy()
            np.random.shuffle(X_permuted[:, feat_idx])

            if self.model_fn is not None:
                perm_preds = self.model_fn(X_permuted)
                if perm_preds.ndim == 1:
                    perm_preds = perm_preds.reshape(-1, 1)
                # 重要性 = 排列后预测变化的绝对均值
                importance[feat_idx] = np.mean(np.abs(base_preds - perm_preds), axis=0)
            else:
                # 无模型时使用特征与目标的相关性
                if y is not None:
                    for t_idx in range(len(self.base_values)):
                        corr = np.abs(np.corrcoef(X_sample[:, feat_idx], y[indices, t_idx])[0, 1])
                        importance[feat_idx, t_idx] = corr if not np.isnan(corr) else 0

        self.feature_importance = importance
        self._fitted = True
        return self

    def get_feature_importance(self) -> np.ndarray:
        """获取特征重要性矩阵 (n_features, n_targets)。"""
        if not self._fitted:
            raise RuntimeError("Explainer not fitted.")
        return self.feature_importance

    def explain_single(
        self,
        features: np.ndarray,
        targets: Optional[np.ndarray] = None,
        target_idx: int = -1,
    ) -> Dict[str, Dict]:
        """解释单个配方。

        使用线性近似：contribution ≈ (feature - mean) × importance_coefficient
        """
        if not self._fitted:
            raise RuntimeError("Explainer not fitted. Call fit() first.")

        if features.ndim == 1:
            features = features.reshape(1, -1)

        result = {}
        for t_idx, target_name in enumerate(TARGET_NAMES):
            contributions = {}
            for f_idx, feat_name in enumerate(self.feature_names):
                # 线性近似贡献
                imp = self.feature_importance[f_idx, t_idx]
                # 方向：用特征值与中位数的关系推断
                sign = 1.0 if features[0, f_idx] > 0 else -1.0
                contributions[feat_name] = round(imp * sign, 4)

            # 排序
            sorted_contrib = sorted(contributions.items(), key=lambda x: abs(x[1]), reverse=True)

            result[target_name] = {
                "base_value": round(float(self.base_values[t_idx]), 2),
                "predicted": round(float(targets[0, t_idx]) if targets is not None else float(self.base_values[t_idx]), 2),
                "contributions": sorted_contrib,
                "top_positive": [(k, v) for k, v in sorted_contrib if v > 0][:3],
                "top_negative": [(k, v) for k, v in sorted_contrib if v < 0][:3],
            }

        return result

    def get_summary_data(self) -> Dict[str, List[Tuple[str, float]]]:
        """获取特征重要性摘要（按目标分组）。"""
        if not self._fitted:
            raise RuntimeError("Explainer not fitted.")

        summary = {}
        for t_idx, target_name in enumerate(TARGET_NAMES):
            importance = [(self.feature_names[f_idx], float(self.feature_importance[f_idx, t_idx]))
                          for f_idx in range(self.n_features)]
            importance.sort(key=lambda x: x[1], reverse=True)
            summary[target_name] = importance

        return summary

    def get_grouped_importance(self) -> Dict[str, Dict[str, float]]:
        """获取按特征分组的重要性。"""
        if not self._fitted:
            raise RuntimeError("Explainer not fitted.")

        grouped = {}
        for group_name, indices in FEATURE_GROUPS.items():
            group_imp = {}
            for t_idx, target_name in enumerate(TARGET_NAMES):
                total = sum(self.feature_importance[i, t_idx] for i in indices)
                group_imp[target_name] = round(float(total), 4)
            grouped[group_name] = group_imp

        return grouped

    def compare_formulas(
        self,
        features_a: np.ndarray,
        features_b: np.ndarray,
        label_a: str = "配方 A",
        label_b: str = "配方 B",
    ) -> Dict:
        """对比两个配方的特征差异。"""
        if features_a.ndim == 1:
            features_a = features_a.reshape(1, -1)
        if features_b.ndim == 1:
            features_b = features_b.reshape(1, -1)

        diff = features_b[0] - features_a[0]
        changes = []
        for i, name in enumerate(self.feature_names):
            if abs(diff[i]) > 0.001:
                changes.append({
                    "feature": name,
                    "value_a": round(features_a[0, i], 3),
                    "value_b": round(features_b[0, i], 3),
                    "change": round(diff[i], 3),
                    "change_pct": round(diff[i] / max(abs(features_a[0, i]), 0.001) * 100, 1),
                })

        changes.sort(key=lambda x: abs(x["change"]), reverse=True)
        return {"label_a": label_a, "label_b": label_b, "changes": changes}
