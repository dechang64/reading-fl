# ── analysis/compliance_engine.py ──
"""
排放法规合规检查引擎

支持标准：
    - Euro 6d (EU)
    - Euro 7 (EU, 2027 实施)
    - China 6b
    - China 7 (征求意见)

检查维度：
    - 转化率限值（CO/HC/NOx）
    - 起燃温度限值（T50）
    - 老化后性能（100k km / 200k km）
    - 贵金属载量参考值
"""

import numpy as np
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


@dataclass
class RegulationLimit:
    """单条法规限值。"""
    co_min: float      # CO 转化率最低要求 %
    hc_min: float      # HC 转化率最低要求 %
    nox_min: float     # NOx 转化率最低要求 %
    t50_max: float     # T50 最高要求 °C
    durability_km: int  # 耐久里程要求 km
    description: str


# ── 法规数据库 ──
REGULATIONS: Dict[str, RegulationLimit] = {
    "Euro 6d": RegulationLimit(
        co_min=94.0, hc_min=94.0, nox_min=90.0, t50_max=260,
        durability_km=100_000,
        description="Euro 6d-TEMP (EU), 2020 年实施，当前主流标准",
    ),
    "Euro 7": RegulationLimit(
        co_min=96.0, hc_min=96.0, nox_min=93.0, t50_max=240,
        durability_km=200_000,
        description="Euro 7 (EU), 2025 年发布，2027 年实施，新增 OBM 全生命周期监控",
    ),
    "China 6b": RegulationLimit(
        co_min=94.0, hc_min=94.0, nox_min=90.0, t50_max=260,
        durability_km=100_000,
        description="国六 b，2023 年全面实施",
    ),
    "China 7": RegulationLimit(
        co_min=95.0, hc_min=95.0, nox_min=92.0, t50_max=250,
        durability_km=160_000,
        description="国七（征求意见），2026 年发布，预计 2028 年实施",
    ),
}

# 老化衰减系数（经验值，基于文献）
# 老化后性能 ≈ fresh × aging_factor
AGING_FACTORS = {
    "fresh": 1.00,
    "50k_km": 0.97,
    "100k_km": 0.93,
    "150k_km": 0.88,
    "200k_km": 0.83,
}

# 贵金属载量参考范围（g/L）
PGE_LOADING_REFS = {
    "Euro 6d": {"Pt": (1.0, 3.0), "Pd": (2.0, 6.0), "Rh": (0.1, 0.5)},
    "Euro 7":  {"Pt": (1.5, 4.0), "Pd": (3.0, 8.0), "Rh": (0.15, 0.6)},
    "China 6b": {"Pt": (1.0, 3.0), "Pd": (2.0, 6.0), "Rh": (0.1, 0.5)},
    "China 7":  {"Pt": (1.2, 3.5), "Pd": (2.5, 7.0), "Rh": (0.12, 0.55)},
}


@dataclass
class ComplianceResult:
    """单标准合规检查结果。"""
    regulation: str
    co_pass: bool
    hc_pass: bool
    nox_pass: bool
    t50_pass: bool
    all_pass: bool
    co_gap: float       # 距限值差距（正=达标，负=不达标）
    hc_gap: float
    nox_gap: float
    t50_gap: float      # 正=达标（T50 低于限值），负=不达标
    durability_pass: bool
    durability_km: int
    description: str


@dataclass
class AgingPrediction:
    """老化预测结果。"""
    stage: str
    km: int
    co_conv: float
    hc_conv: float
    nox_conv: float
    t50: float
    aging_factor: float


class ComplianceEngine:
    """排放法规合规检查引擎。"""

    def __init__(self):
        self.regulations = REGULATIONS
        self.aging_factors = AGING_FACTORS

    def check_compliance(
        self,
        targets: np.ndarray,
        regulation: str = "Euro 7",
        aging_stage: str = "fresh",
    ) -> ComplianceResult:
        """检查配方是否满足指定法规。

        Args:
            targets: [CO_conv, HC_conv, NOx_conv, T50]
            regulation: 法规名称
            aging_stage: 老化阶段
        """
        if regulation not in self.regulations:
            raise ValueError(f"Unknown regulation: {regulation}. Available: {list(self.regulations.keys())}")

        reg = self.regulations[regulation]
        af = self.aging_factors.get(aging_stage, 1.0)

        # 应用老化衰减
        co = targets[0] * af
        hc = targets[1] * af
        nox = targets[2] * af
        # T50 随老化升高（性能下降）
        t50 = targets[3] + (1 - af) * 80  # 最多升高 80°C

        co_pass = co >= reg.co_min
        hc_pass = hc >= reg.hc_min
        nox_pass = nox >= reg.nox_min
        t50_pass = t50 <= reg.t50_max

        co_gap = co - reg.co_min
        hc_gap = hc - reg.hc_min
        nox_gap = nox - reg.nox_min
        t50_gap = reg.t50_max - t50  # 正=达标

        durability_pass = True  # 默认通过，需要老化数据验证

        return ComplianceResult(
            regulation=regulation,
            co_pass=co_pass, hc_pass=hc_pass, nox_pass=nox_pass, t50_pass=t50_pass,
            all_pass=co_pass and hc_pass and nox_pass and t50_pass,
            co_gap=round(co_gap, 1), hc_gap=round(hc_gap, 1),
            nox_gap=round(nox_gap, 1), t50_gap=round(t50_gap, 1),
            durability_pass=durability_pass,
            durability_km=reg.durability_km,
            description=reg.description,
        )

    def check_all_regulations(
        self,
        targets: np.ndarray,
        aging_stage: str = "fresh",
    ) -> List[ComplianceResult]:
        """检查所有法规。"""
        return [self.check_compliance(targets, reg, aging_stage) for reg in self.regulations]

    def predict_aging_trajectory(
        self,
        targets: np.ndarray,
        stages: Optional[List[str]] = None,
    ) -> List[AgingPrediction]:
        """预测老化轨迹。"""
        stages = stages or list(self.aging_factors.keys())
        predictions = []

        for stage in stages:
            af = self.aging_factors[stage]
            km_map = {"fresh": 0, "50k_km": 50_000, "100k_km": 100_000,
                      "150k_km": 150_000, "200k_km": 200_000}
            km = km_map.get(stage, 0)

            predictions.append(AgingPrediction(
                stage=stage, km=km, aging_factor=af,
                co_conv=round(targets[0] * af, 1),
                hc_conv=round(targets[1] * af, 1),
                nox_conv=round(targets[2] * af, 1),
                t50=round(targets[3] + (1 - af) * 80, 1),
            ))

        return predictions

    def predict_aging(self, features: np.ndarray, targets: np.ndarray) -> List[AgingPrediction]:
        """别名：predict_aging_trajectory（兼容 UI 调用）。"""
        return self.predict_aging_trajectory(targets)

    def get_improvement_suggestions(
        self,
        features: np.ndarray,
        targets: np.ndarray,
        regulation: str = "Euro 7",
    ) -> List[Dict]:
        """别名：suggest_improvements（兼容 UI 调用）。"""
        return self.suggest_improvements(targets, regulation)

    def suggest_improvements(
        self,
        targets: np.ndarray,
        regulation: str = "Euro 7",
    ) -> List[Dict]:
        """针对不达标项给出改进建议。"""
        result = self.check_compliance(targets, regulation)
        suggestions = []

        if not result.co_pass:
            gap = abs(result.co_gap)
            suggestions.append({
                "target": "CO 转化率",
                "current": round(targets[0], 1),
                "required": self.regulations[regulation].co_min,
                "gap": round(gap, 1),
                "suggestion": f"CO 转化率差 {gap:.1f}%，建议增加 Pt 载量 0.1-0.3 g/L 或提高焙烧温度 20-50°C",
                "severity": "high" if gap > 5 else "medium",
            })

        if not result.hc_pass:
            gap = abs(result.hc_gap)
            suggestions.append({
                "target": "HC 转化率",
                "current": round(targets[1], 1),
                "required": self.regulations[regulation].hc_min,
                "gap": round(gap, 1),
                "suggestion": f"HC 转化率差 {gap:.1f}%，建议增加 Pd 载量 0.2-0.5 g/L 或优化 CeO₂-ZrO₂ 固溶体比例",
                "severity": "high" if gap > 5 else "medium",
            })

        if not result.nox_pass:
            gap = abs(result.nox_gap)
            suggestions.append({
                "target": "NOx 转化率",
                "current": round(targets[2], 1),
                "required": self.regulations[regulation].nox_min,
                "gap": round(gap, 1),
                "suggestion": f"NOx 转化率差 {gap:.1f}%，建议增加 Rh 载量 0.02-0.05 g/L 或添加 BaO 助剂",
                "severity": "high" if gap > 5 else "medium",
            })

        if not result.t50_pass:
            gap = abs(result.t50_gap)
            suggestions.append({
                "target": "T50 起燃温度",
                "current": round(targets[3], 1),
                "required": self.regulations[regulation].t50_max,
                "gap": round(gap, 1),
                "suggestion": f"T50 超标 {gap:.1f}°C，建议提高比表面积 20-40 m²/g 或增加 Pd/Rh 比例",
                "severity": "high" if gap > 20 else "medium",
            })

        return suggestions

    def get_regulation_summary(self) -> List[Dict]:
        """获取所有法规摘要。"""
        summary = []
        for name, reg in self.regulations.items():
            summary.append({
                "name": name,
                "co_min": reg.co_min,
                "hc_min": reg.hc_min,
                "nox_min": reg.nox_min,
                "t50_max": reg.t50_max,
                "durability_km": reg.durability_km,
                "description": reg.description,
            })
        return summary

    def check_pge_loading(
        self,
        features: np.ndarray,
        regulation: str = "Euro 7",
    ) -> Dict[str, Dict]:
        """检查贵金属载量是否在参考范围内。"""
        refs = PGE_LOADING_REFS.get(regulation, PGE_LOADING_REFS["Euro 6d"])
        pge_names = ["Pt", "Pd", "Rh"]
        result = {}

        for i, elem in enumerate(pge_names):
            loading = features[i]
            lo, hi = refs[elem]
            result[elem] = {
                "loading": round(loading, 3),
                "ref_range": (lo, hi),
                "in_range": lo <= loading <= hi,
                "status": "✅ 正常" if lo <= loading <= hi else ("⚠️ 偏低" if loading < lo else "🔴 偏高"),
            }

        return result
