# ── analysis/pareto_optimizer.py ──
"""
多目标 Pareto 前沿优化器

功能：
    - 多目标优化（性能最大化 + 成本最小化）
    - Pareto 前沿计算与可视化
    - 交互式筛选（成本上限、性能下限）
    - 锚点推荐（性价比最优 / 性能最优 / 成本最优）
"""

import numpy as np
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass


@dataclass
class ParetoPoint:
    """Pareto 前沿上的一个点。"""
    formula_id: str
    cost: float              # $/L
    performance: float       # 综合评分 0-100
    co_conv: float
    hc_conv: float
    nox_conv: float
    t50: float
    pt_loading: float
    pd_loading: float
    rh_loading: float
    is_pareto: bool = False
    anchor: Optional[str] = None  # "性价比最优" / "性能最优" / "成本最优"


class ParetoOptimizer:
    """多目标 Pareto 前沿优化器。"""

    def __init__(self):
        self.points: List[ParetoPoint] = []
        self.pareto_front: List[ParetoPoint] = []

    def add_points(
        self,
        features: np.ndarray,
        targets: np.ndarray,
        costs: Optional[np.ndarray] = None,
        formula_ids: Optional[List[str]] = None,
        performance_fn=None,
    ) -> None:
        """添加数据点。

        Args:
            features: 配方特征 (n, 13)
            targets: 性能目标 (n, 4) [CO, HC, NOx, T50]
            costs: 贵金属成本 (n,)，如为 None 则自动计算
            formula_ids: 配方 ID
            performance_fn: 自定义性能评分函数
        """
        n = len(features)
        ids = formula_ids or [f"f_{i}" for i in range(n)]

        # 默认成本计算（简化版）
        if costs is None:
            # Pt: $32.8/g, Pd: $31.5/g, Rh: $152.7/g (2026 年均价)
            costs = (features[:, 0] * 32.8 +
                     features[:, 1] * 31.5 +
                     features[:, 2] * 152.7)

        for i in range(n):
            if performance_fn is not None:
                perf = performance_fn(targets[i])
            else:
                perf = self._default_performance_score(targets[i])

            self.points.append(ParetoPoint(
                formula_id=ids[i],
                cost=round(float(costs[i]), 2),
                performance=round(float(perf), 2),
                co_conv=round(float(targets[i][0]), 1),
                hc_conv=round(float(targets[i][1]), 1),
                nox_conv=round(float(targets[i][2]), 1),
                t50=round(float(targets[i][3]), 1),
                pt_loading=round(float(features[i][0]), 3),
                pd_loading=round(float(features[i][1]), 3),
                rh_loading=round(float(features[i][2]), 3),
            ))

        # 重新计算 Pareto 前沿
        self._compute_pareto()

    def _default_performance_score(self, targets: np.ndarray) -> float:
        """默认综合性能评分。"""
        co_score = min(targets[0] / 100.0, 1.0) * 100
        hc_score = min(targets[1] / 100.0, 1.0) * 100
        nox_score = min(targets[2] / 100.0, 1.0) * 100
        t50_norm = 1.0 - np.clip((targets[3] - 180) / (300 - 180), 0, 1)
        t50_score = t50_norm * 100
        return 0.30 * co_score + 0.30 * hc_score + 0.25 * nox_score + 0.15 * t50_score

    def _compute_pareto(self) -> None:
        """计算 Pareto 前沿。"""
        # 重置标记
        for p in self.points:
            p.is_pareto = False
            p.anchor = None

        self.pareto_front = []
        for i, p in enumerate(self.points):
            dominated = False
            for j, q in enumerate(self.points):
                if i == j:
                    continue
                # q dominates p: 更便宜且更好
                if q.cost <= p.cost and q.performance >= p.performance:
                    if q.cost < p.cost or q.performance > p.performance:
                        dominated = True
                        break
            if not dominated:
                p.is_pareto = True
                self.pareto_front.append(p)

        self.pareto_front.sort(key=lambda x: x.cost)

        # 标注锚点
        if self.pareto_front:
            # 性价比最优
            best_value = max(self.pareto_front, key=lambda x: x.performance / max(x.cost, 0.01))
            best_value.anchor = "💰 性价比最优"

            # 性能最优
            best_perf = max(self.pareto_front, key=lambda x: x.performance)
            best_perf.anchor = "🏆 性能最优"

            # 成本最优
            best_cost = min(self.pareto_front, key=lambda x: x.cost)
            best_cost.anchor = "💵 成本最优"

    def filter_by_cost(self, max_cost: float) -> List[ParetoPoint]:
        """按成本上限筛选。"""
        return [p for p in self.points if p.cost <= max_cost]

    def filter_by_performance(self, min_perf: float) -> List[ParetoPoint]:
        """按性能下限筛选。"""
        return [p for p in self.points if p.performance >= min_perf]

    def filter_pareto_by_cost(self, max_cost: float) -> List[ParetoPoint]:
        """在 Pareto 前沿上按成本筛选。"""
        return [p for p in self.pareto_front if p.cost <= max_cost]

    def get_anchors(self) -> Dict[str, Optional[ParetoPoint]]:
        """获取三个锚点。"""
        anchors = {}
        for p in self.pareto_front:
            if p.anchor:
                anchors[p.anchor] = p
        return anchors

    def get_cost_range(self) -> Tuple[float, float]:
        """获取成本范围。"""
        if not self.points:
            return (0, 0)
        costs = [p.cost for p in self.points]
        return (min(costs), max(costs))

    def get_performance_range(self) -> Tuple[float, float]:
        """获取性能范围。"""
        if not self.points:
            return (0, 100)
        perfs = [p.performance for p in self.points]
        return (min(perfs), max(perfs))

    def get_stats(self) -> Dict:
        """获取统计信息。"""
        return {
            "total_points": len(self.points),
            "pareto_points": len(self.pareto_front),
            "cost_range": self.get_cost_range(),
            "performance_range": self.get_performance_range(),
            "anchors": {k: v.formula_id for k, v in self.get_anchors().items()},
        }

    def recommend(
        self,
        max_cost: Optional[float] = None,
        min_performance: Optional[float] = None,
        preference: str = "balanced",
    ) -> List[ParetoPoint]:
        """推荐配方。

        Args:
            max_cost: 成本上限
            min_performance: 性能下限
            preference: "balanced" / "performance" / "cost"
        """
        candidates = self.pareto_front.copy()

        if max_cost is not None:
            candidates = [p for p in candidates if p.cost <= max_cost]
        if min_performance is not None:
            candidates = [p for p in candidates if p.performance >= min_performance]

        if not candidates:
            return []

        if preference == "performance":
            return [max(candidates, key=lambda x: x.performance)]
        elif preference == "cost":
            return [min(candidates, key=lambda x: x.cost)]
        else:  # balanced
            return [max(candidates, key=lambda x: x.performance / max(x.cost, 0.01))]
