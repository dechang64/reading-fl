"""
TWC-FL Platform — 三元催化配方联邦学习协作平台
=================================================
Streamlit-based collaborative platform for catalyst R&D.

Architecture:
  - Python FL Engine (FedAvg) — catalyst performance prediction
  - Bayesian Optimizer — intelligent experiment recommendation
  - TWC Knowledge Hub — domain FAQ and literature
  - SHA-256 Audit Chain — immutable operation log
  - Vector Search — formula similarity retrieval
  - Plotly interactive visualizations

Quick Start:
  pip install -r requirements.txt
  streamlit run app.py

Deployment:
  Streamlit Cloud: Push to GitHub → auto-deploy
"""

import streamlit as st
import sys
import os

# Ensure project root is in path
sys.path.insert(0, os.path.dirname(__file__))

# ── Page Config ──
st.set_page_config(
    page_title="TWC-FL Platform | 三元催化联邦学习平台",
    page_icon="⚗️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ──
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 50%, #0f172a 100%);
        padding: 2rem 2.5rem;
        border-radius: 12px;
        margin-bottom: 1.5rem;
        color: white;
    }
    .main-header h1 {
        margin: 0 0 0.5rem 0;
        font-size: 1.8rem;
        font-weight: 700;
    }
    .main-header p {
        margin: 0;
        opacity: 0.85;
        font-size: 0.95rem;
    }
    .metric-card {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        padding: 1rem;
        text-align: center;
    }
    .stTabs [data-baseweb="tab-list"] {
        gap: 2px;
    }
    .stTabs [data-baseweb="tab"] {
        border-radius: 4px 4px 0 0;
        padding: 8px 16px;
        background-color: #f1f5f9;
    }
    .stTabs [aria-selected="true"] {
        background-color: #3b82f6 !important;
        color: white !important;
    }
    div[data-testid="stSidebar"] {
        background: linear-gradient(180deg, #f8fafc 0%, #e2e8f0 100%);
    }
</style>
""", unsafe_allow_html=True)

# ── Session State Init ──
if "current_page" not in st.session_state:
    st.session_state["current_page"] = "dashboard"

# ── Sidebar Navigation ──
with st.sidebar:
    st.markdown("## ⚗️ TWC-FL Platform")
    st.caption("三元催化配方联邦学习协作平台")
    st.markdown("---")

    pages = [
        ("🏠 Dashboard", "dashboard"),
        ("📁 Data Vault", "data_vault"),
        ("💰 Cost Analysis", "cost_dashboard"),
        ("📜 Compliance", "compliance"),
        ("📚 Knowledge Hub", "knowledge_hub"),
        ("🧪 Bayesian Optimizer", "bayesian_optimizer"),
        ("⚖️ Pareto Optimizer", "pareto_optimizer"),
        ("🔄 FL Training", "fl_training"),
        ("🔍 Vector Search", "vector_search"),
        ("🔬 Explainability", "explainability"),
        ("⛓️ Audit Chain", "audit_chain"),
        ("📖 Research", "research"),
    ]

    for label, key in pages:
        if st.button(label, use_container_width=True, key=f"nav_{key}"):
            st.session_state["current_page"] = key

    st.markdown("---")
    st.caption("v1.1 | XJTLU AI Academy")
    st.caption("徐德昌课题组")

# ── Page Router ──
page = st.session_state.get("current_page", "dashboard")

if page == "dashboard":
    from modules import dashboard
    dashboard.render()
elif page == "data_vault":
    from modules import data_vault
    data_vault.render()
elif page == "cost_dashboard":
    from modules import cost_dashboard
    cost_dashboard.render()
elif page == "compliance":
    from modules import compliance
    compliance.render()
elif page == "knowledge_hub":
    from modules import knowledge_hub
    knowledge_hub.render()
elif page == "bayesian_optimizer":
    from modules import bayesian_optimizer
    bayesian_optimizer.render()
elif page == "pareto_optimizer":
    from modules import pareto_optimizer
    pareto_optimizer.render()
elif page == "fl_training":
    from modules import fl_training
    fl_training.render()
elif page == "vector_search":
    from modules import vector_search
    vector_search.render()
elif page == "explainability":
    from modules import explainability
    explainability.render()
elif page == "audit_chain":
    from modules import audit_chain
    audit_chain.render()
elif page == "research":
    from modules import research
    research.render()
