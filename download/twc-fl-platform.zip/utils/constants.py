# ── utils/constants.py ──
"""Shared constants for TWC-FL Platform (Three-Way Catalytic converter Federated Learning)."""

# ── TWC Domain Constants ──
# Target conversion rates (Euro 6d / China 6b)
TWC_TARGETS = {
    "CO": {"min": 94.0, "unit": "%", "desc": "CO conversion rate"},
    "HC": {"min": 94.0, "unit": "%", "desc": "HC conversion rate"},
    "NOx": {"min": 90.0, "unit": "%", "desc": "NOx conversion rate"},
    "T50": {"target_range": (180, 260), "unit": "°C", "desc": "Light-off temperature"},
}

# Precious metals (PGE - Platinum Group Elements)
PGE_ELEMENTS = ["Pt", "Pd", "Rh"]
PGE_INFO = {
    "Pt": {"name": "Platinum", "color": "#e5e4e2", "emoji": "⚪", "price_per_oz_usd": 1020},
    "Pd": {"name": "Palladium", "color": "#C0C0C0", "emoji": "🩶", "price_per_oz_usd": 980},
    "Rh": {"name": "Rhodium", "color": "#FFD700", "emoji": "🟡", "price_per_oz_usd": 4750},
}

# Catalyst components
CATALYST_COMPONENTS = [
    "Pt_loading", "Pd_loading", "Rh_loading",       # g/L precious metal loading
    "CeO2_loading", "ZrO2_loading", "Al2O3_loading", # g/L washcoat components
    "La2O3_loading", "BaO_loading",                  # g/L promoters
    "calcination_temp", "aging_temp",                 # °C thermal conditions
    "surface_area", "pore_volume",                    # m²/g, mL/g textural properties
]

# Prediction targets
PREDICTION_TARGETS = ["CO_conv", "HC_conv", "NOx_conv", "T50"]

# FL defaults
DEFAULT_ROUNDS = 10
DEFAULT_CLIENTS = 3
DEFAULT_LR = 0.001
DEFAULT_BATCH_SIZE = 32
DEFAULT_LOCAL_EPOCHS = 5

# Model defaults
DEFAULT_INPUT_DIM = 13  # catalyst features
DEFAULT_HIDDEN_DIM = 64
DEFAULT_NUM_CLASSES = 4  # regression heads: CO, HC, NOx, T50

# HNSW defaults
HNSW_M = 16
HNSW_M0 = 32

# Client (enterprise) names for demo
DEMO_ENTERPRISES = [
    "威孚高科 (WEIFU)",
    "贵研铂业 (GUIYAN)",
    "凯立新材 (KAILI)",
    "庄信万丰 (JM)",
    "巴斯夫 (BASF)",
]

# Knowledge base categories
KB_CATEGORIES = [
    "配方设计原理",
    "贵金属优化",
    "老化机理",
    "表征方法",
    "排放法规",
    "FL协作指南",
]

# Research references (TWC-specific)
REFERENCES = {
    "McMahan 2017": "McMahan, B. et al. (2017). Communication-Efficient Learning of Deep Networks from Decentralized Data. AISTATS.",
    "Li 2020": "Li, T. et al. (2020). Federated Optimization in Heterogeneous Networks. MLSys.",
    "Kairouz 2021": "Kairouz, P. et al. (2021). Advances and Open Problems in Federated Learning. Foundations and Trends.",
    "Bonawitz 2019": "Bonawitz, K. et al. (2019). Towards Federated Learning at Scale: A System Design. MLSys.",
    "Noel 2025": "Noel, T. et al. (2025). AI-driven autonomous experimentation in chemistry. Nature Chemical Biology.",
    "Shelef 1995": "Shelef, M. & Graham, G.W. (1995). Why Rhodium in Automotive Three-Way Catalysts? Catalysis Reviews.",
    "Kaspar 1999": "Kaspar, J. et al. (1999). Automotive catalytic converters: current status and future perspectives. Topics in Catalysis.",
}

# Color palette for charts
COLORS = {
    "Pt": "#e5e4e2",
    "Pd": "#C0C0C0",
    "Rh": "#FFD700",
    "CO": "#ef4444",
    "HC": "#f59e0b",
    "NOx": "#22c55e",
    "T50": "#3b82f6",
    "primary": "#3b82f6",
    "secondary": "#8b5cf6",
    "accent": "#06b6d4",
    "bg": "#fafbfc",
    "grid": "#e5e7eb",
    "text": "#1f2937",
    "muted": "#6b7280",
    "success": "#22c55e",
    "warning": "#f59e0b",
    "danger": "#ef4444",
}

# Streamlit Cloud deployment
STREAMLIT_CLOUD = True
