# ── utils/helpers.py ──
"""Utility functions for TWC-FL Platform."""

import numpy as np
import pandas as pd
from typing import Optional


def generate_synthetic_formulas(
    n_samples: int = 600,
    seed: int = 42,
) -> tuple[np.ndarray, np.ndarray]:
    """Generate synthetic catalyst formula data for demo purposes.

    Returns:
        (features, targets) where features are catalyst compositions
        and targets are [CO_conv, HC_conv, NOx_conv, T50].
    """
    rng = np.random.RandomState(seed)

    # Feature columns: precious metal loadings + washcoat + thermal + textural
    n_features = 13
    features = np.zeros((n_samples, n_features), dtype=np.float32)

    # Pt loading: 0.5 - 5.0 g/L
    features[:, 0] = rng.uniform(0.5, 5.0, n_samples)
    # Pd loading: 0.5 - 8.0 g/L
    features[:, 1] = rng.uniform(0.5, 8.0, n_samples)
    # Rh loading: 0.05 - 0.5 g/L (scarce!)
    features[:, 2] = rng.uniform(0.05, 0.5, n_samples)
    # CeO2: 50 - 200 g/L
    features[:, 3] = rng.uniform(50, 200, n_samples)
    # ZrO2: 20 - 100 g/L
    features[:, 4] = rng.uniform(20, 100, n_samples)
    # Al2O3: 100 - 250 g/L
    features[:, 5] = rng.uniform(100, 250, n_samples)
    # La2O3: 5 - 30 g/L
    features[:, 6] = rng.uniform(5, 30, n_samples)
    # BaO: 5 - 25 g/L
    features[:, 7] = rng.uniform(5, 25, n_samples)
    # Calcination temp: 400 - 700 °C
    features[:, 8] = rng.uniform(400, 700, n_samples)
    # Aging temp: 800 - 1100 °C
    features[:, 9] = rng.uniform(800, 1100, n_samples)
    # Surface area: 50 - 200 m²/g
    features[:, 10] = rng.uniform(50, 200, n_samples)
    # Pore volume: 0.3 - 1.0 mL/g
    features[:, 11] = rng.uniform(0.3, 1.0, n_samples)

    # Generate targets with realistic physics-inspired relationships
    noise = rng.randn(n_samples, 4) * 0.02

    # CO conversion: higher PGE → higher conversion
    pge_total = features[:, 0] + features[:, 1] + features[:, 2]
    co_conv = np.clip(0.7 + 0.05 * pge_total + 0.001 * features[:, 10] + noise[:, 0], 0.5, 0.99)

    # HC conversion: similar but Rh has more effect
    hc_conv = np.clip(0.65 + 0.04 * pge_total + 0.15 * features[:, 2] + 0.0005 * features[:, 10] + noise[:, 1], 0.5, 0.99)

    # NOx conversion: Rh is critical, CeO2/ZrO2 help
    nox_conv = np.clip(0.6 + 0.3 * features[:, 2] + 0.001 * features[:, 3] + 0.001 * features[:, 4] + noise[:, 2], 0.4, 0.99)

    # T50: lower is better, affected by PGE and surface area
    t50 = np.clip(350 - 15 * pge_total - 0.3 * features[:, 10] + 0.05 * features[:, 9] + noise[:, 3] * 50, 150, 400)

    targets = np.column_stack([co_conv, hc_conv, nox_conv, t50]).astype(np.float32)

    return features, targets


def split_federated_data(
    features: np.ndarray,
    targets: np.ndarray,
    n_clients: int = 3,
    non_iid: float = 0.0,
    seed: int = 42,
) -> list[tuple[np.ndarray, np.ndarray]]:
    """Split data across federated clients (enterprises).

    Args:
        non_iid: 0.0 = IID split, 1.0 = highly non-IID
    """
    rng = np.random.RandomState(seed)
    n_samples = len(features)
    indices = rng.permutation(n_samples)

    if non_iid > 0:
        # Sort by a weighted combination of features to create non-IID
        sort_key = features[:, 0] * 0.3 + features[:, 2] * 0.5 + features[:, 10] * 0.2
        sorted_idx = np.argsort(sort_key)
        indices = sorted_idx

    client_data = {}
    chunk_size = n_samples // n_clients
    for i in range(n_clients):
        start = i * chunk_size
        end = start + chunk_size if i < n_clients - 1 else n_samples
        client_data[i] = indices[start:end].tolist()

    return [(features[indices], targets[indices]) for indices in client_data.values()]


def format_conversion(val: float) -> str:
    """Format conversion rate as percentage."""
    return f"{val * 100:.1f}%"


def format_temperature(val: float) -> str:
    """Format temperature."""
    return f"{val:.1f} °C"


def compute_pge_cost(features: np.ndarray) -> float:
    """Estimate PGE cost per liter based on formula.

    Prices: Pt ~$1020/oz, Pd ~$980/oz, Rh ~$4750/oz
    1 oz = 31.103 g
    """
    pt_cost = features[0] / 31.103 * 1020
    pd_cost = features[1] / 31.103 * 980
    rh_cost = features[2] / 31.103 * 4750
    return pt_cost + pd_cost + rh_cost


def check_compliance(targets: np.ndarray) -> dict:
    """Check if formula meets Euro 6d / China 6b standards.

    Returns dict with pass/fail for each metric.
    """
    co_pass = targets[0] >= 0.94
    hc_pass = targets[1] >= 0.94
    nox_pass = targets[2] >= 0.90
    t50_ok = 180 <= targets[3] <= 260

    return {
        "CO": {"value": targets[0], "target": 0.94, "pass": co_pass},
        "HC": {"value": targets[1], "target": 0.94, "pass": hc_pass},
        "NOx": {"value": targets[2], "target": 0.90, "pass": nox_pass},
        "T50": {"value": targets[3], "range": (180, 260), "pass": t50_ok},
        "all_pass": co_pass and hc_pass and nox_pass and t50_ok,
    }


def features_to_dataframe(features: np.ndarray) -> pd.DataFrame:
    """Convert feature array to labeled DataFrame."""
    columns = [
        "Pt (g/L)", "Pd (g/L)", "Rh (g/L)",
        "CeO₂ (g/L)", "ZrO₂ (g/L)", "Al₂O₃ (g/L)",
        "La₂O₃ (g/L)", "BaO (g/L)",
        "Calcination (°C)", "Aging (°C)",
        "Surface Area (m²/g)", "Pore Volume (mL/g)",
    ]
    return pd.DataFrame(features[:, :12], columns=columns)


def targets_to_dataframe(targets: np.ndarray) -> pd.DataFrame:
    """Convert target array to labeled DataFrame."""
    return pd.DataFrame(targets, columns=["CO Conv (%)", "HC Conv (%)", "NOx Conv (%)", "T50 (°C)"])
