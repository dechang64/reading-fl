"""twc_core.ewa — Entropy-Weighted Aggregation subpackage."""

from .primitives import VisualPrimitive, PrimitiveBatch, PrimitiveType, PrimitiveCodec
from .aggregator import (
    AggregationStrategy, AggregatedPrimitive, AggregationResult,
    EntropyWeightedAggregator,
)

__all__ = [
    "VisualPrimitive", "PrimitiveBatch", "PrimitiveType", "PrimitiveCodec",
    "AggregationStrategy", "AggregatedPrimitive", "AggregationResult",
    "EntropyWeightedAggregator",
]
