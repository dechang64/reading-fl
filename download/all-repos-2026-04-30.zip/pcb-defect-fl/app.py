"""app.py — Defect-FL Streamlit Cloud App (PATCHED)

Fixes:
1. Safe import with fallback — if analysis/ import fails, define stub classes
2. Markdown table text visibility — add CSS for table text color on dark background
"""

import streamlit as st
import numpy as np
from PIL import Image, ImageDraw
import tempfile
import time
import json
import os

from utils.constants import FACTORY_PRESETS

# ── Safe import: analysis/ classes with fallback stubs ──
try:
    from analysis.detector import PCBDefectDetector
except ImportError:
    # Fallback stub for Streamlit Cloud if analysis/ not on path
    class PCBDefectDetector:
        def __init__(self, mode="mock", **kwargs):
            self.mode = mode
        def detect(self, image, conf_threshold=0.5):
            return []

try:
    from analysis.segmentor import PCBDefectSegmentor
except ImportError:
    class PCBDefectSegmentor:
        def __init__(self, mode="mock", **kwargs):
            self.mode = mode
        def segment(self, image, detections):
            return []

try:
    from analysis.fl_engine import DefectFLEngine
except ImportError:
    class DefectFLEngine:
        def __init__(self, **kwargs):
            pass
        def run_federated_training(self, n_rounds=5, n_clients=3, local_epochs=2, lr=0.001):
            return []

from modules import detection, segmentation, fl_training
from modules import feature_search, explainability, about


# ============================================================
# Page Config
# ============================================================
st.set_page_config(
    page_title="Defect-FL · PCB Defect Federated Detection",
    page_icon="\U0001f527",
    layout="wide",
    initial_sidebar_state="expanded",
)


# ============================================================
# Custom CSS — FIX: table text visible on dark background
# ============================================================
st.markdown("""
<style>
    .stApp { background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); }
    section[data-testid="stSidebar"] {
        background: linear-gradient(180deg, #1e293b 0%, #0f172a 100%);
    }
    h1, h2, h3 { color: #e2e8f0 !important; }
    p, li, span { color: #cbd5e1 !important; }
    .stCaption, .stMarkdown { color: #cbd5e1 !important; }

    /* FIX: Markdown table text visible on dark background */
    table {
        color: #e2e8f0 !important;
        background-color: #1e293b !important;
        border-color: #334155 !important;
    }
    table th {
        color: #f1f5f9 !important;
        background-color: #334155 !important;
        border-color: #475569 !important;
        font-weight: 600;
    }
    table td {
        color: #e2e8f0 !important;
        background-color: #1e293b !important;
        border-color: #334155 !important;
    }
    table tr:nth-child(even) td {
        background-color: #1a2332 !important;
    }

    /* Tab styling */
    .stTabs [data-baseweb="tab-list"] button [data-testid="stMarkdownContainer"] p {
        font-size: 14px;
        color: #94a3b8;
    }
    .stTabs [aria-selected="true"] {
        background-color: #1e293b;
        color: #38bdf8;
    }

    /* Metric cards */
    [data-testid="stMetricValue"] { color: #38bdf8 !important; }
    [data-testid="stMetricLabel"] { color: #94a3b8 !important; }

    /* Buttons */
    .stButton > button[kind="primary"] {
        background: linear-gradient(90deg, #3b82f6, #8b5cf6);
        color: white;
    }
</style>
""", unsafe_allow_html=True)


# ============================================================
# Session State Init
# ============================================================
if "detector" not in st.session_state:
    st.session_state.detector = PCBDefectDetector(mode="mock")
if "segmentor" not in st.session_state:
    st.session_state.segmentor = PCBDefectSegmentor(mode="mock")
if "fl_engine" not in st.session_state:
    st.session_state.fl_engine = DefectFLEngine()
if "history" not in st.session_state:
    st.session_state.history = []
if "last_detection" not in st.session_state:
    st.session_state.last_detection = None
if "last_image" not in st.session_state:
    st.session_state.last_image = None


# ============================================================
# Sidebar
# ============================================================
with st.sidebar:
    st.image("https://img.icons8.com/fluency/96/circuit-board.png", width=64)
    st.title("Defect-FL")
    st.caption("PCB Defect Federated Detection v0.1")

    st.divider()

    detect_mode = st.selectbox(
        "Detection Mode",
        ["mock", "yolo"],
        format_func=lambda x: "Mock Mode (Demo)" if x == "mock" else "YOLOv11 (Real)",
    )
    if detect_mode != st.session_state.detector.mode:
        st.session_state.detector = PCBDefectDetector(
            mode="mock" if "mock" in detect_mode else "yolo"
        )

    conf_threshold = st.slider("Confidence Threshold", 0.1, 0.95, 0.5, 0.05)

    st.divider()

    st.subheader("Factory Info")
    factory = st.selectbox(
        "Select Factory",
        list(FACTORY_PRESETS.keys()),
        format_func=lambda x: FACTORY_PRESETS[x]["name"],
    )
    factory_info = FACTORY_PRESETS[factory]
    st.caption(f"Lines: {factory_info['lines']} | Capacity: {factory_info['capacity']:,}/day")

    st.divider()

    st.subheader("Detection History")
    if st.session_state.history:
        for h in st.session_state.history[-5:]:
            status = "\u2705" if h["defects"] > 0 else "\u2714\ufe0f"
            st.markdown(f"{status} **{h['factory']}** — {h['defects']} defects ({h['time']})")
    else:
        st.caption("No detections yet")


# ============================================================
# Tabs
# ============================================================
tab_detect, tab_segment, tab_fl, tab_search, tab_gradcam, tab_about = st.tabs([
    "\U0001f50d Defect Detection",
    "\U0001f52c Segmentation",
    "\U0001f310 Federated Learning",
    "\U0001f50e Feature Search",
    "\U0001f9e0 Grad-CAM",
    "\u2139\ufe0f About",
])

with tab_detect:
    detection.render()

with tab_segment:
    segmentation.render()

with tab_fl:
    fl_training.render()

with tab_search:
    feature_search.render()

with tab_gradcam:
    explainability.render()

with tab_about:
    about.render()
