<div align="center">

# Defect-FL v2

### PCB Defect Federated Detection Platform

**Privacy-preserving PCB quality control — defect images never leave the factory.**

[![Python](https://img.shields.io/badge/Python-3.10+-blue?logo=python)](https://python.org/)
[![Rust](https://img.shields.io/badge/Rust-2021-orange?logo=rust)](https://www.rust-lang.org/)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.40+-red?logo=streamlit)](https://streamlit.io/)
[![YOLOv11](https://img.shields.io/badge/YOLO-v11-9b59b6)](https://docs.ultralytics.com/)
[![DINOv2](https://img.shields.io/badge/DINOv2-Meta-blueviolet)](https://github.com/facebookresearch/dinov2)
[![Tests](https://img.shields.io/badge/Tests-54%20passed-brightgreen)]()
[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](LICENSE)


</div>

---

## Problem

PCB quality control needs deep learning, but:
- **Data silos**: Each factory's defect images are NDA-protected
- **Class imbalance**: Rare defects underrepresented in any single factory
- **Domain shift**: Different PCB designs → different defect distributions

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    Rust Backend (:8080)                  │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌───────────┐  │
│  │ FedServer│ │  HNSW    │ │  Audit   │ │Contribution│  │
│  │ (FedAvg) │ │ VectorDB │ │  Chain   │ │  Tracker  │  │
│  └────┬─────┘ └────┬─────┘ └────┬─────┘ └─────┬─────┘  │
│       │            │            │              │         │
│  ┌────┴────────────┴────────────┴──────────────┴─────┐  │
│  │              gRPC + REST API                       │  │
│  └────────────────────┬──────────────────────────────┘  │
│                       │                                  │
│  ┌────────────────────┴──────────────────────────────┐  │
│  │              Web Dashboard (axum)                  │  │
│  └───────────────────────────────────────────────────┘  │
└──────────────────────────┬──────────────────────────────┘
                           │ gRPC
          ┌────────────────┼────────────────┐
          │                │                │
   ┌──────┴──────┐  ┌─────┴──────┐  ┌──────┴──────┐
   │  Factory A  │  │  Factory B  │  │  Factory C  │
   │ (Python SDK)│  │ (Python SDK)│  │ (Python SDK)│
   └─────────────┘  └────────────┘  └─────────────┘

┌─────────────────────────────────────────────────────────┐
│              Streamlit UI (:8501)                        │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌───────────┐  │
│  │Detection │ │Segment-  │ │   FL     │ │ Feature   │  │
│  │  (YOLO)  │ │ation(SAM)│ │ Training │ │  Search   │  │
│  └──────────┘ └──────────┘ └──────────┘ └───────────┘  │
│  ┌──────────┐ ┌──────────┐                              │
│  │ Grad-CAM │ │  About   │                              │
│  └──────────┘ └──────────┘                              │
└─────────────────────────────────────────────────────────┘
```

## Project Structure

```
defect-fl/
├── src/                          # Rust backend
│   ├── main.rs                   #   Entry point (axum + tonic)
│   ├── fed_server.rs             #   FedAvg aggregation engine
│   ├── hnsw_index.rs             #   HNSW approximate nearest neighbor
│   ├── vector_db.rs              #   768-dim DINOv2 vector database
│   ├── audit.rs                  #   SHA-256 hash chain (tamper-proof)
│   ├── contribution_tracker.rs   #   Data contribution quantification
│   ├── task_registry.rs          #   Factory task management (SQLite)
│   ├── grpc_service.rs           #   gRPC service definitions
│   ├── rest_api.rs               #   REST endpoints (/api/v1/*)
│   └── web_dashboard.rs          #   Built-in HTML dashboard
├── proto/
│   └── defect_fl.proto           #   gRPC service + message definitions
├── python/                       # Factory client SDK
│   ├── analysis/                 #   Client-side ML (detector, segmentor, FL)
│   ├── utils/constants.py        #   Shared constants
│   └── tests/test_defect_fl.py   #   Client SDK tests
├── analysis/                     # Streamlit ML core
│   ├── detector.py               #   YOLOv11 PCB defect detector
│   ├── segmentor.py              #   SAM2 pixel-level segmentor
│   ├── fl_engine.py              #   FedAvg simulation
│   ├── feature_extractor.py      #   DINOv2 768-dim features
│   └── gradcam.py                #   Grad-CAM explainability
├── modules/                      # Streamlit UI layer
│   ├── detection.py              #   Defect detection tab
│   ├── segmentation.py           #   Segmentation tab
│   ├── fl_training.py            #   FL simulation tab
│   ├── feature_search.py         #   Feature search tab
│   ├── explainability.py         #   Grad-CAM tab
│   └── about.py                  #   About page
├── data/synthetic.py             # Synthetic PCB data generation
├── tests/                        # 54 tests
├── app.py                        # Streamlit entry point
├── Cargo.toml                    # Rust dependencies
├── Dockerfile                    # Streamlit container
└── docker-compose.yml            # Docker Compose
```

## Defect Types

| # | Type | Severity |
|---|------|----------|
| 1 | Missing Hole | Critical |
| 2 | Mouse Bite | Major |
| 3 | Open Circuit | Critical |
| 4 | Short | Critical |
| 5 | Spur | Minor |
| 6 | Spurious Copper | Major |

## Quick Start

### Streamlit UI (Demo)

```bash
pip install -r requirements.txt
streamlit run app.py
```

### Rust Backend (Production)

```bash
cargo run                    # Start gRPC + REST server on :8080
# Open http://localhost:8080  # Web dashboard
```

### Factory Client

```bash
cd python
pip install -r requirements.txt
python -m analysis.detector  # Run factory client
```

### Docker

```bash
docker compose up -d
```

### With Real Models

```bash
pip install torch ultralytics transformers
```

## Rust Backend Features

| Component | Description |
|-----------|-------------|
| **FedServer** | FedAvg aggregation with round management |
| **HNSW Index** | Approximate nearest neighbor for 768-dim vectors |
| **VectorDB** | DINOv2 feature storage + similarity search |
| **Audit Chain** | SHA-256 hash chain for tamper-proof logging |
| **Contribution Tracker** | Quantify per-factory data contribution |
| **Task Registry** | SQLite-backed factory task management |
| **gRPC Service** | 9 RPCs (register, detect, aggregate, search, audit...) |
| **REST API** | `/api/v1/health`, `/api/v1/tasks`, `/api/v1/rounds`, `/api/v1/audit` |
| **Web Dashboard** | Built-in HTML dashboard at `/` |

## gRPC API

```protobuf
service DefectService {
  rpc RegisterFactory(FactoryRequest) returns (FactoryResponse);
  rpc UploadDefectImage(ImageUpload) returns (DetectionResult);
  rpc GetGlobalModel(ModelRequest) returns (ModelResponse);
  rpc UploadUpdate(UpdateRequest) returns (UpdateResponse);
  rpc GetRoundStatus(RoundStatusRequest) returns (RoundStatusResponse);
  rpc TriggerAggregation(AggregationRequest) returns (AggregationResponse);
  rpc SearchSimilarDefects(SearchRequest) returns (SearchResponse);
  rpc GetAuditLogs(AuditRequest) returns (AuditResponse);
  rpc HealthCheck(HealthCheckRequest) returns (HealthCheckResponse);
}
```

## Tests

```bash
pytest tests/ -v
# 54 passed
```

## Related Projects

| Project | Domain | Shared Infra |
|---------|--------|-------------|
| [organoid-fl](https://github.com/dechang64/organoid-fl) | Medical imaging | YOLOv11, DINOv2, SAM2, Grad-CAM |
| [embodied-fl](https://github.com/dechang64/embodied-fl) | Robotics | DINOv2, Multi-Task FL |
| [FundFL](https://github.com/dechang64/fundfl) | Finance | HNSW, audit chain |
| [Reading-FL](https://github.com/dechang64/reading-fl) | Reading | DINOv2, FedAvg |

## License

Apache-2.0

---

<div align="center">

**Defect-FL v2** — Rust backend + Python ML + Streamlit UI<br>
Privacy-preserving PCB defect detection via federated learning

</div>
