"""feature_search module for Defect-FL."""

import streamlit as st
import numpy as np
from PIL import Image, ImageDraw
import time

from utils.constants import DEFECT_CLASSES, SEVERITY_LEVELS



def render():
    st.header("DINOv2 特征检索")
    st.caption("基于768维自监督特征向量的PCB相似性检索，支持跨工厂缺陷模式匹配")

    st.markdown("""
    ### 🔎 工作原理

    ```
    PCB图像 → DINOv2 (768-dim) → HNSW索引 → 相似度排序 → Top-K结果
    ```

    **核心优势**:
    - 无需标注数据（自监督学习）
    - 跨工厂缺陷模式匹配（域适应）
    - 零样本缺陷聚类（发现未知缺陷类型）
    """)

    col_s1, col_s2 = st.columns([1, 1])

    with col_s1:
        st.subheader("📤 查询图像")
        query_file = st.file_uploader(
            "上传查询PCB图像",
            type=["png", "jpg", "jpeg", "webp"],
            key="search_upload",
        )
        if query_file:
            query_img = Image.open(query_file).convert("RGB")
            st.image(query_img, use_container_width=True, caption="查询图像")

            st.subheader("⚙️ 检索参数")
            top_k = st.slider("返回结果数", 1, 20, 5)
            sim_threshold = st.slider("相似度阈值", 0.5, 1.0, 0.7, 0.05)

            search_btn = st.button("🔎 开始检索", type="primary", use_container_width=True)

    with col_s2:
        st.subheader("📊 检索结果")
        if query_file and search_btn:
            with st.spinner("🔎 正在检索相似PCB..."):
                time.sleep(0.5)

                # Mock search results using DINOv2-like features
                np.random.seed(hash(query_file.name) % 2**31)
                query_array = np.array(query_img)

                MOCK_DATABASE = [
                    {"id": "PCB-001", "factory": "深圳SMT厂", "defect": "short", "similarity": 0.94, "date": "2026-04-20"},
                    {"id": "PCB-002", "factory": "东莞PCB厂", "defect": "open_circuit", "similarity": 0.89, "date": "2026-04-19"},
                    {"id": "PCB-003", "factory": "苏州HDI厂", "defect": "missing_hole", "similarity": 0.85, "date": "2026-04-18"},
                    {"id": "PCB-004", "factory": "深圳SMT厂", "defect": "spurious_copper", "similarity": 0.82, "date": "2026-04-17"},
                    {"id": "PCB-005", "factory": "东莞PCB厂", "defect": "mouse_bite", "similarity": 0.78, "date": "2026-04-16"},
                    {"id": "PCB-006", "factory": "苏州HDI厂", "defect": "short", "similarity": 0.75, "date": "2026-04-15"},
                    {"id": "PCB-007", "factory": "深圳SMT厂", "defect": "spur", "similarity": 0.72, "date": "2026-04-14"},
                    {"id": "PCB-008", "factory": "东莞PCB厂", "defect": "open_circuit", "similarity": 0.68, "date": "2026-04-13"},
                ]

                results = [r for r in MOCK_DATABASE if r["similarity"] >= sim_threshold][:top_k]

                if results:
                    for i, r in enumerate(results):
                        sev = SEVERITY_LEVELS.get(r["defect"], {}).get("severity", "minor")
                        sev_icon = "🔴" if sev == "critical" else ("🟡" if sev == "major" else "🟢")
                        st.markdown(f"""
                        **#{i+1} {r['id']}** — {sev_icon} {r['defect']}
                        | 指标 | 值 |
                        |------|-----|
                        | 相似度 | {r['similarity']:.1%} |
                        | 来源工厂 | {r['factory']} |
                        | 缺陷类型 | {r['defect']} |
                        | 记录日期 | {r['date']} |
                        """)
                        st.progress(r["similarity"])
                        if i < len(results) - 1:
                            st.divider()
                else:
                    st.info("未找到相似度超过阈值的PCB记录")
        else:
            st.info("请上传查询图像并点击检索按钮")

    # Feature space visualization
    st.subheader("🌌 特征空间可视化")
    st.caption("DINOv2 768维特征降维至2D (t-SNE)")

    np.random.seed(42)
    n_points = 50
    tsne_x = np.random.randn(n_points) * 3
    tsne_y = np.random.randn(n_points) * 3
    # Cluster by defect type
    for i in range(n_points):
        defect_idx = i % 6
        tsne_x[i] += defect_idx * 1.5
        tsne_y[i] += (defect_idx % 3) * 1.5

    chart_data = {
        "x": tsne_x,
        "y": tsne_y,
        "defect": [DEFECT_CLASSES[i % 6] for i in range(n_points)],
    }
    st.scatter_chart(
        chart_data,
        x="x", y="y", color="defect",
        use_container_width=True,
    )


    # ============================================================
    # Tab 5: Grad-CAM Explainability
    # ============================================================
