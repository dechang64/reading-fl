"""segmentation module for Defect-FL."""

import streamlit as st
import numpy as np
from PIL import Image, ImageDraw
import time




def render():
    st.header("缺陷分割与形态分析")
    st.caption("基于SAM2的像素级缺陷分割，提取缺陷形态学特征")

    if st.session_state.last_detection is None or st.session_state.last_image is None:
        st.warning("请先在「缺陷检测」页面上传图像并完成检测")
        st.stop()

    img_array = st.session_state.last_image
    detections = st.session_state.last_detection
    defects = [d for d in detections if d.class_name != "good"]

    if not defects:
        st.info("未检测到缺陷，无需分割分析")
        st.stop()

    col1, col2 = st.columns([1, 1])

    with col1:
        st.subheader("缺陷分割可视化")

        # Create segmentation overlay
        overlay = img_array.copy()
        draw = ImageDraw.Draw(overlay)

        SEG_COLORS = [
            (255, 0, 0, 128), (0, 255, 0, 128), (0, 0, 255, 128),
            (255, 255, 0, 128), (255, 0, 255, 128), (0, 255, 255, 128),
        ]

        for i, d in enumerate(defects):
            color = SEG_COLORS[i % len(SEG_COLORS)]
            x1, y1, x2, y2 = int(d.bbox[0]), int(d.bbox[1]), int(d.bbox[2]), int(d.bbox[3])
            # Mock segmentation: fill bbox with semi-transparent color
            for y in range(y1, min(y2, img_array.shape[0])):
                for x in range(x1, min(x2, img_array.shape[1])):
                    overlay[y, x] = (
                        int(overlay[y, x, 0] * 0.5 + color[0] * 0.5),
                        int(overlay[y, x, 1] * 0.5 + color[1] * 0.5),
                        int(overlay[y, x, 2] * 0.5 + color[2] * 0.5),
                    )
            draw.rectangle([x1, y1, x2, y2], outline=color[:3], width=2)
            draw.text((x1+3, y1+3), f"#{i+1} {d.class_name}", fill="white")

        st.image(overlay, use_container_width=True, caption="缺陷分割叠加图")

    with col2:
        st.subheader("形态学分析")

        for i, d in enumerate(defects):
            with st.expander(f"#{i+1} {d.class_name} — {d.severity}", expanded=(i == 0)):
                # Mock segmentation
                seg_result = st.session_state.segmentor.segment(
                    img_array, [int(d.bbox[0]), int(d.bbox[1]), int(d.bbox[2]), int(d.bbox[3])]
                )

                st.markdown(f"""
                **置信度**: {d.confidence:.1%}

                | 指标 | 值 |
                |------|-----|
                | 面积 | {seg_result.area:,} px² |
                | 周长 | {seg_result.perimeter:.1f} px |
                | 圆度 | {seg_result.circularity:.3f} |
                | 实度 | {seg_result.solidity:.3f} |
                | 长宽比 | {seg_result.aspect_ratio:.2f} |
                | 质心 | ({seg_result.centroid[0]:.0f}, {seg_result.centroid[1]:.0f}) |

                **说明**: {DEFECT_DESCRIPTIONS.get(d.class_name, 'N/A')}
                """)

    # Grad-CAM mock
    st.subheader("🔍 Grad-CAM 可解释性分析")
    st.caption("展示模型关注区域，帮助质量工程师理解检测决策")

    if defects:
        # Mock heatmap
        h, w = img_array.shape[:2]
        heatmap = np.zeros((h, w), dtype=np.float32)
        for d in defects:
            x1, y1, x2, y2 = int(d.bbox[0]), int(d.bbox[1]), int(d.bbox[2]), int(d.bbox[3])
            # Gaussian-like heatmap centered on defect
            cy, cx = (y1 + y2) // 2, (x1 + x2) // 2
            for y in range(max(0, y1-20), min(h, y2+20)):
                for x in range(max(0, x1-20), min(w, x2+20)):
                    dist = np.sqrt((x - cx)**2 + (y - cy)**2)
                    heatmap[y, x] = max(heatmap[y, x], np.exp(-dist**2 / (2 * 15**2)))

        # Normalize and apply colormap
        heatmap_norm = (heatmap / max(heatmap.max(), 1e-6) * 255).astype(np.uint8)
        heatmap_rgb = np.zeros((h, w, 3), dtype=np.uint8)
        heatmap_rgb[:, :, 0] = heatmap_norm  # Red channel
        heatmap_rgb[:, :, 1] = (heatmap_norm * 0.3).astype(np.uint8)  # Some green

        # Blend
        blend = (img_array.astype(np.float32) * 0.6 + heatmap_rgb.astype(np.float32) * 0.4).astype(np.uint8)

        col_g1, col_g2 = st.columns(2)
        with col_g1:
            st.image(heatmap_rgb, use_container_width=True, caption="Grad-CAM 热力图")
        with col_g2:
            st.image(blend, use_container_width=True, caption="叠加可视化")

        # Analysis report
        worst = max(defects, key=lambda d: d.confidence)
        st.markdown(f"""
        ### 📊 分析报告

        **最高置信度缺陷**: {worst.class_name} ({worst.confidence:.1%})
        **严重度**: {worst.severity}

        - 模型关注区域与检测到的缺陷位置**高度吻合**
        - {"🔴 存在严重缺陷，建议立即复检" if any(d.severity == "critical" for d in defects) else "🟡 缺陷程度可控，建议常规处理"}
        - 检测到 **{len(defects)}** 个缺陷区域，覆盖图像 **{sum((d.bbox[2]-d.bbox[0])*(d.bbox[3]-d.bbox[1]) for d in defects) / (h*w) * 100:.1f}%** 面积
        """)


    # ============================================================
    # Tab 3: Federated Learning
    # ============================================================
