"""about module for Defect-FL."""

import streamlit as st
import numpy as np
from PIL import Image, ImageDraw
import time



def render():
    st.header("关于 Defect-FL")

    st.markdown("""
    ### 🔧 项目简介

    **Defect-FL** 是一个基于联邦学习的PCB缺陷智能检测平台，实现多工厂协同训练，PCB图像数据不出厂。

    ### 🔬 核心技术

    | 技术 | 用途 |
    |------|------|
    | YOLOv11 | 6类PCB缺陷实时检测 |
    | SAM2 | 像素级缺陷分割 |
    | DINOv2 | 768维PCB特征提取 |
    | Grad-CAM | 模型决策可解释性 |
    | FedAvg | 多工厂联邦聚合 |
    | HNSW | 缺陷模式相似检索 |

    ### 🏭 支持工厂

    | 工厂 | 产线数 | 日产能 |
    |------|--------|--------|
    | 深圳SMT厂 | 8条 | 50,000片 |
    | 东莞PCB厂 | 5条 | 30,000片 |
    | 苏州HDI厂 | 3条 | 15,000片 |

    ### 📊 检测能力

    - 缺陷类型: 6类（漏孔/鼠咬/开路/短路/毛刺/多余铜）
    - 检测精度: >95%（YOLOv11）
    - 推理速度: <50ms/图
    - 分割精度: 像素级（SAM2）

    ### 📄 开源协议

    Apache-2.0 | [GitHub](https://github.com/dechang64)
    """)

