"""detection module for Defect-FL."""

import streamlit as st
import numpy as np
from PIL import Image, ImageDraw
import time

from utils.constants import DEFECT_DESCRIPTIONS, SEVERITY_LEVELS



def render():
    st.header("PCB缺陷智能检测")
    st.caption("支持6类缺陷：漏孔、鼠咬、开路、短路、毛刺、多余铜")

    col_upload, col_info = st.columns([2, 1])

    with col_upload:
        uploaded = st.file_uploader(
            "上传PCB图像",
            type=["png", "jpg", "jpeg", "webp"],
            key="detect_upload",
        )

    with col_info:
        st.markdown("""
        ### 缺陷类型说明
        | 类型 | 严重度 | 说明 |
        |------|--------|------|
        | missing_hole | 🔴 严重 | 漏孔，无法安装元件 |
        | open_circuit | 🔴 严重 | 开路，信号中断 |
        | short | 🔴 严重 | 短路，信号异常 |
        | mouse_bite | 🟡 中等 | 鼠咬，可能开路 |
        | spurious_copper | 🟡 中等 | 多余铜，制造污染 |
        | spur | 🟢 轻微 | 毛刺，潜在短路 |
        """)

    if uploaded:
        img = Image.open(uploaded).convert("RGB")
        img_array = np.array(img)

        st.session_state.last_image = img_array

        col1, col2 = st.columns([1, 1])

        with col1:
            st.subheader("原始PCB图像")
            st.image(img, use_container_width=True)
            st.caption(f"尺寸: {img.width} × {img.height} px")

        with col2:
            with st.spinner("🔍 正在检测缺陷..."):
                t0 = time.time()
                result = st.session_state.detector.detect(img_array, conf_threshold=conf_threshold)
                dt = (time.time() - t0) * 1000

            st.session_state.last_detection = result

            # Draw detections
            annotated = img.copy()
            draw = ImageDraw.Draw(annotated)

            DEFECT_COLORS = {
                "missing_hole": "#ef4444",
                "mouse_bite": "#f59e0b",
                "open_circuit": "#ef4444",
                "short": "#ef4444",
                "spur": "#22c55e",
                "spurious_copper": "#f59e0b",
            }

            for d in result:
                color = DEFECT_COLORS.get(d.class_name, "#ef4444")
                draw.rectangle([d.bbox[0], d.bbox[1], d.bbox[2], d.bbox[3]], outline=color, width=2)
                label = f"{d.class_name} {d.confidence:.0%}"
                draw.rectangle([d.bbox[0], d.bbox[1]-16, d.bbox[0]+len(label)*8+6, d.bbox[1]], fill=color)
                draw.text((d.bbox[0]+3, d.bbox[1]-14), label, fill="white")

            st.subheader("检测结果")
            st.image(annotated, use_container_width=True)
            st.caption(f"检测耗时: {dt:.0f} ms")

        # Metrics
        summary = st.session_state.detector.summary(result)
        defects = [d for d in result if d.class_name != "good"]

        m1, m2, m3, m4 = st.columns(4)

        with m1:
            st.markdown(f"""
            <div class="metric-card {'danger' if defects else 'success'}">
                <div style="font-size:2rem;font-weight:700">{len(defects)}</div>
                <div style="color:#666">检测到缺陷</div>
            </div>
            """, unsafe_allow_html=True)

        with m2:
            st.markdown(f"""
            <div class="metric-card">
                <div style="font-size:2rem;font-weight:700">{summary.get('avg_confidence', 0):.0%}</div>
                <div style="color:#666">平均置信度</div>
            </div>
            """, unsafe_allow_html=True)

        with m3:
            critical = sum(1 for d in defects if d.severity == "critical")
            st.markdown(f"""
            <div class="metric-card {'danger' if critical else ''}">
                <div style="font-size:2rem;font-weight:700">{critical}</div>
                <div style="color:#666">严重缺陷</div>
            </div>
            """, unsafe_allow_html=True)

        with m4:
            st.markdown(f"""
            <div class="metric-card">
                <div style="font-size:2rem;font-weight:700">{dt:.0f}</div>
                <div style="color:#666">耗时 (ms)</div>
            </div>
            """, unsafe_allow_html=True)

        # Defect details table
        if defects:
            st.subheader("📋 缺陷详情")
            table_data = []
            for d in defects:
                sev_class = f"severity-{d.severity}" if d.severity != "moderate" else "severity-moderate"
                table_data.append({
                    "类型": d.class_name,
                    "严重度": d.severity,
                    "置信度": f"{d.confidence:.1%}",
                    "位置": f"({d.cx:.0f}, {d.cy:.0f})",
                    "面积": f"{d.area:.0f} px²",
                    "说明": DEFECT_DESCRIPTIONS.get(d.class_name, ""),
                })
            st.dataframe(table_data, use_container_width=True, hide_index=True)

            # Save to history
            st.session_state.history.append({
                "factory": factory_info["name"],
                "defects": len(defects),
                "time": time.strftime("%H:%M:%S"),
            })
        else:
            st.success("✅ 未检测到缺陷，PCB质量合格！")
            st.session_state.history.append({
                "factory": factory_info["name"],
                "defects": 0,
                "time": time.strftime("%H:%M:%S"),
            })


    # ============================================================
    # Tab 2: Segmentation Analysis
    # ============================================================
