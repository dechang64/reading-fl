"""Tests for PCBDefectDetector."""

import sys
import os
import pytest
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from analysis.detector import PCBDefectDetector, DefectDetection


class TestDefectDetection:
    """Test DefectDetection dataclass."""

    def test_creation(self):
        d = DefectDetection(
            bbox=[10, 20, 100, 200],
            class_name="short",
            class_id=3,
            confidence=0.95,
            cx=55, cy=110,
            width=90, height=180,
            area=16200,
            severity="critical",
        )
        assert d.class_name == "short"
        assert d.confidence == 0.95
        assert d.area == 16200
        assert d.severity == "critical"

    def test_to_dict(self):
        d = DefectDetection(
            bbox=[0, 0, 50, 50],
            class_name="spur",
            class_id=4,
            confidence=0.8,
            cx=25, cy=25,
            width=50, height=50,
            area=2500,
            severity="minor",
        )
        result = d.to_dict()
        assert isinstance(result, dict)
        assert result["class_name"] == "spur"
        assert result["confidence"] == 0.8
        assert "bbox" in result

    def test_all_defect_classes_have_severity(self):
        det = PCBDefectDetector(mode="mock")
        for cls in det.DEFECT_CLASSES:
            assert cls in det.SEVERITY_MAP, f"Missing severity for {cls}"


class TestPCBDefectDetector:
    """Test PCBDefectDetector."""

    def test_mock_mode_init(self):
        det = PCBDefectDetector(mode="mock")
        assert det.mode == "mock"
        assert det.model is None

    def test_yolo_mode_init(self):
        det = PCBDefectDetector(mode="yolo")
        assert det.mode == "yolo"

    def test_mock_detect_returns_list(self):
        det = PCBDefectDetector(mode="mock")
        img = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
        results = det.detect(img)
        assert isinstance(results, list)
        assert len(results) > 0

    def test_mock_detect_result_types(self):
        det = PCBDefectDetector(mode="mock")
        img = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
        results = det.detect(img)
        for r in results:
            assert isinstance(r, DefectDetection)
            assert 0 <= r.confidence <= 1
            assert isinstance(r.bbox, list)
            assert len(r.bbox) == 4
            assert r.severity in ("critical", "major", "minor", "none")

    def test_mock_detect_conf_threshold(self):
        det = PCBDefectDetector(mode="mock")
        img = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
        results_high = det.detect(img, conf_threshold=0.9)
        results_low = det.detect(img, conf_threshold=0.1)
        assert len(results_high) <= len(results_low)

    def test_mock_detect_deterministic(self):
        det = PCBDefectDetector(mode="mock")
        img = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
        r1 = det.detect(img)
        r2 = det.detect(img)
        assert [d.class_name for d in r1] == [d.class_name for d in r2]

    def test_summary_empty(self):
        det = PCBDefectDetector(mode="mock")
        result = det.summary([])
        assert result["total"] == 0
        assert result["defects"] == 0

    def test_summary_with_detections(self):
        det = PCBDefectDetector(mode="mock")
        img = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
        detections = det.detect(img)
        summary = det.summary(detections)
        assert summary["total"] == len(detections)
        assert summary["defect_rate"] >= 0
        assert "severity" in summary
