"""Tests for DefectFLEngine."""

import sys
import os
import pytest
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from analysis.fl_engine import DefectFLEngine


class TestDefectFLEngine:
    """Test DefectFLEngine."""

    def test_default_init(self):
        engine = DefectFLEngine()
        assert engine.num_classes == 6
        assert engine.lr == 0.001
        assert engine.local_epochs == 2

    def test_custom_init(self):
        engine = DefectFLEngine(num_classes=10, lr=0.01, local_epochs=5)
        assert engine.num_classes == 10
        assert engine.lr == 0.01
        assert engine.local_epochs == 5

    def test_split_data_returns_splits(self):
        engine = DefectFLEngine()
        features = np.random.randn(100, 768).astype(np.float32)
        labels = np.random.randint(0, 6, 100)
        train_X, train_y, val_X, val_y, client_splits = engine._split_data(features, labels, n_clients=3)
        # Returns (train_X, train_y, val_X, val_y, client_splits)
        assert train_X.shape[1] == 768
        assert len(train_y) > 0
        assert len(val_y) > 0
        assert len(client_splits) == 3
        assert all(isinstance(s, np.ndarray) for s in client_splits)

    def test_fedavg_with_torch_tensors(self):
        engine = DefectFLEngine()
        try:
            import torch
        except ImportError:
            pytest.skip("torch not available")
        params_list = [
            {"w1": torch.randn(10, 5), "b1": torch.randn(5)}
            for _ in range(3)
        ]
        avg = engine._fedavg(params_list)
        assert "w1" in avg
        assert avg["w1"].shape == (10, 5)

    def test_run_federated(self):
        engine = DefectFLEngine(local_epochs=1)
        features = np.random.randn(60, 768).astype(np.float32)
        labels = np.random.randint(0, 6, 60)
        history = engine.run(features, labels, n_clients=3, rounds=2)
        assert len(history) == 2
        # Check for actual key names returned by run()
        assert "avg_train_loss" in history[0] or "train_loss" in history[0]
        assert "client_metrics" in history[0]

    def test_run_improves(self):
        engine = DefectFLEngine(local_epochs=1)
        features = np.random.randn(60, 768).astype(np.float32)
        labels = np.random.randint(0, 6, 60)
        history = engine.run(features, labels, n_clients=2, rounds=5)
        # Get accuracy key (may be avg_train_acc or train_acc)
        acc_key = "avg_train_acc" if "avg_train_acc" in history[0] else "train_acc"
        accs = [h[acc_key] for h in history]
        # Should not crash; accuracy may fluctuate on random data
        assert all(0 <= a <= 1 for a in accs)

    def test_progress_callback(self):
        engine = DefectFLEngine(local_epochs=1)
        features = np.random.randn(40, 768).astype(np.float32)
        labels = np.random.randint(0, 6, 40)
        callbacks = []
        engine.run(features, labels, n_clients=2, rounds=2,
                   progress_callback=lambda r, m: callbacks.append((r, m)))
        assert len(callbacks) == 2
