"""Tests for PCBDefectSegmentor."""

import sys
import os
import pytest
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from analysis.segmentor import PCBDefectSegmentor, DefectSegmentation


class TestDefectSegmentation:
    """Test DefectSegmentation dataclass."""

    def test_creation(self):
        mask = np.zeros((100, 100), dtype=np.uint8)
        s = DefectSegmentation(
            mask=mask, area=0, perimeter=0, circularity=0,
            solidity=0, aspect_ratio=0, bbox=[0,0,0,0],
            centroid=(0, 0), defect_type="short",
        )
        assert s.defect_type == "short"
        assert s.area == 0

    def test_to_dict_excludes_mask(self):
        mask = np.zeros((100, 100), dtype=np.uint8)
        s = DefectSegmentation(
            mask=mask, area=100, perimeter=40, circularity=0.78,
            solidity=0.9, aspect_ratio=1.2, bbox=[10,10,50,50],
            centroid=(30, 30), defect_type="open_circuit",
        )
        d = s.to_dict()
        assert "mask" not in d
        assert d["area"] == 100
        assert d["defect_type"] == "open_circuit"


class TestPCBDefectSegmentor:
    """Test PCBDefectSegmentor."""

    def test_mock_mode_init(self):
        seg = PCBDefectSegmentor(mode="mock")
        assert seg.mode == "mock"

    def test_mock_segment_returns_list(self):
        seg = PCBDefectSegmentor(mode="mock")
        img = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
        boxes = [[100, 100, 200, 200], [300, 300, 400, 400]]
        results = seg.segment(img, boxes, defect_types=["short", "open_circuit"])
        assert isinstance(results, list)
        assert len(results) == 2

    def test_mock_segment_mask_shape(self):
        seg = PCBDefectSegmentor(mode="mock")
        img = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
        results = seg.segment(img, [[10, 10, 50, 50]])
        assert results[0].mask.shape == (480, 640)

    def test_mock_segment_defect_type(self):
        seg = PCBDefectSegmentor(mode="mock")
        img = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
        results = seg.segment(img, [[10, 10, 50, 50]], defect_types=["spur"])
        assert results[0].defect_type == "spur"

    def test_mock_segment_without_defect_types(self):
        seg = PCBDefectSegmentor(mode="mock")
        img = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
        results = seg.segment(img, [[10, 10, 50, 50]])
        assert results[0].defect_type == "unknown"

    def test_compute_morphology(self):
        seg = PCBDefectSegmentor(mode="mock")
        mask = np.zeros((100, 100), dtype=np.uint8)
        mask[20:80, 20:80] = 255
        result = seg._compute_morphology(mask, [20, 20, 80, 80])
        assert result["area"] == 60 * 60 * 255  # mask values are 0/255
        assert result["perimeter"] > 0
