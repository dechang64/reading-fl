"""Tests for utils/constants."""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from utils.constants import (
    DEFECT_CLASSES, DEFECT_DESCRIPTIONS, SEVERITY_LEVELS,
    FACTORY_PRESETS, COLORS,
)


class TestDefectClasses:
    def test_has_six_classes(self):
        assert len(DEFECT_CLASSES) == 6

    def test_no_duplicates(self):
        assert len(DEFECT_CLASSES) == len(set(DEFECT_CLASSES))

    def test_all_have_descriptions(self):
        for cls in DEFECT_CLASSES:
            assert cls in DEFECT_DESCRIPTIONS, f"Missing description for {cls}"

    def test_all_have_severity(self):
        for cls in DEFECT_CLASSES:
            assert cls in SEVERITY_LEVELS, f"Missing severity for {cls}"

    def test_all_have_colors(self):
        for cls in DEFECT_CLASSES:
            assert cls in COLORS, f"Missing color for {cls}"


class TestSeverityLevels:
    def test_all_have_severity_key(self):
        for cls, level in SEVERITY_LEVELS.items():
            assert "severity" in level, f"{cls} missing severity key"
            assert "color" in level, f"{cls} missing color key"

    def test_valid_severity_values(self):
        valid = {"critical", "major", "minor"}
        for cls, level in SEVERITY_LEVELS.items():
            assert level["severity"] in valid, f"{cls} has invalid severity: {level['severity']}"


class TestFactoryPresets:
    def test_has_three_factories(self):
        assert len(FACTORY_PRESETS) == 3

    def test_all_have_required_keys(self):
        for name, fp in FACTORY_PRESETS.items():
            assert "name" in fp, f"{name} missing 'name'"
            assert "lines" in fp, f"{name} missing 'lines'"
            assert "capacity" in fp, f"{name} missing 'capacity'"
            assert "defect_dist" in fp, f"{name} missing 'defect_dist'"

    def test_defect_dist_sums_to_one(self):
        for name, fp in FACTORY_PRESETS.items():
            total = sum(fp["defect_dist"].values())
            assert abs(total - 1.0) < 0.01, f"{name} defect_dist sums to {total}"

    def test_defect_dist_covers_all_classes(self):
        from utils.constants import DEFECT_CLASSES
        for name, fp in FACTORY_PRESETS.items():
            for cls in DEFECT_CLASSES:
                assert cls in fp["defect_dist"], f"{name} missing {cls} in defect_dist"


class TestColors:
    def test_has_ui_colors(self):
        assert "primary" in COLORS
        assert "secondary" in COLORS
        assert "accent" in COLORS

    def test_color_format(self):
        for name, color in COLORS.items():
            assert color.startswith("#"), f"{name}: {color} not hex format"
            assert len(color) == 7, f"{name}: {color} not #RRGGBB format"
