"""Tests for synthetic data generation."""

import os
import sys
import pytest
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


class TestSyntheticData:
    """Test data/synthetic.py."""

    def test_import(self):
        """Module should import without errors."""
        from data.synthetic import generate_pcb_image
        assert callable(generate_pcb_image)

    def test_generate_pcb_image_shape(self):
        """Generated image should have correct shape."""
        from data.synthetic import generate_pcb_image
        img = generate_pcb_image(height=480, width=640)
        assert img.shape == (480, 640, 3)
        assert img.dtype == np.uint8

    def test_generate_pcb_image_range(self):
        """Pixel values should be in valid range."""
        from data.synthetic import generate_pcb_image
        img = generate_pcb_image()
        assert img.min() >= 0
        assert img.max() <= 255

    def test_generate_pcb_image_custom_size(self):
        """Custom dimensions should work."""
        from data.synthetic import generate_pcb_image
        img = generate_pcb_image(height=200, width=300)
        assert img.shape == (200, 300, 3)

    def test_generate_pcb_image_reproducible(self):
        """Same seed should produce same image."""
        from data.synthetic import generate_pcb_image
        img1 = generate_pcb_image(seed=42)
        img2 = generate_pcb_image(seed=42)
        np.testing.assert_array_equal(img1, img2)

    def test_generate_pcb_image_different_seeds(self):
        """Different seeds should produce different images."""
        from data.synthetic import generate_pcb_image
        img1 = generate_pcb_image(seed=1)
        img2 = generate_pcb_image(seed=2)
        assert not np.array_equal(img1, img2)
