"""Tests for Grad-CAM module."""

import sys
import os
import pytest
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from analysis.gradcam import generate_defect_report


class TestGenerateDefectReport:
    """Test generate_defect_report function."""

    def test_basic_report(self):
        heatmap = np.random.rand(100, 100).astype(np.float32)
        report = generate_defect_report(
            heatmap=heatmap,
            defect_type="short",
            confidence=0.95,
            severity="critical",
        )
        assert isinstance(report, str)
        assert len(report) > 0
        assert "short" in report.lower()
        assert "critical" in report.lower()

    def test_report_with_morphology(self):
        heatmap = np.random.rand(100, 100).astype(np.float32)
        report = generate_defect_report(
            heatmap=heatmap,
            defect_type="missing_hole",
            confidence=0.85,
            severity="major",
            morphology={"area": 500, "perimeter": 90},
        )
        assert "500" in report or "area" in report.lower()

    def test_center_focused_heatmap(self):
        heatmap = np.zeros((100, 100), dtype=np.float32)
        heatmap[30:70, 30:70] = 1.0
        report = generate_defect_report(
            heatmap=heatmap,
            defect_type="spur",
            confidence=0.7,
            severity="minor",
        )
        assert "central" in report.lower() or "center" in report.lower()

    def test_edge_focused_heatmap(self):
        heatmap = np.zeros((100, 100), dtype=np.float32)
        heatmap[0:10, :] = 1.0
        heatmap[-10:, :] = 1.0
        report = generate_defect_report(
            heatmap=heatmap,
            defect_type="open_circuit",
            confidence=0.8,
            severity="critical",
        )
        assert isinstance(report, str)
        assert len(report) > 50
