"""Tests for DINOv2 PCB Feature Extractor."""

import os
import sys
import pytest
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


class TestDINOv2PCBExtractor:
    """Test DINOv2PCBExtractor class."""

    def test_import_without_torch(self):
        """Module should import even without torch."""
        try:
            from analysis.feature_extractor import DINOv2PCBExtractor
            assert DINOv2PCBExtractor is not None
        except ImportError:
            pytest.skip("torch not available")

    def test_model_dims(self):
        """MODEL_DIMS should cover known variants."""
        try:
            from analysis.feature_extractor import DINOv2PCBExtractor
            dims = DINOv2PCBExtractor.MODEL_DIMS
            assert "vits14" in dims
            assert dims["vits14"] == 384
            assert "base" in dims
            assert dims["base"] == 768
            assert "large" in dims
            assert dims["large"] == 1024
        except ImportError:
            pytest.skip("torch not available")

    def test_init_default_params(self):
        """Default initialization should use dinov2-base."""
        try:
            from analysis.feature_extractor import DINOv2PCBExtractor
            ext = DINOv2PCBExtractor()
            assert ext.dim == 768
            assert "base" in ext.variant
        except ImportError:
            pytest.skip("torch not available")

    def test_init_custom_model(self):
        """Custom model name should set correct dimension."""
        from analysis.feature_extractor import HAS_TORCH
        if not HAS_TORCH:
            pytest.skip("torch not available")
        from analysis.feature_extractor import DINOv2PCBExtractor
        ext = DINOv2PCBExtractor(model_name="facebook/dinov2-vits14")
        assert ext.dim == 384

    def test_has_torch_flag(self):
        """HAS_TORCH flag should exist."""
        from analysis import feature_extractor
        assert hasattr(feature_extractor, "HAS_TORCH")
        assert isinstance(feature_extractor.HAS_TORCH, bool)
