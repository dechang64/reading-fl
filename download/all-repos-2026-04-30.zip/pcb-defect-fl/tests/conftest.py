"""Shared test fixtures for defect-fl."""

import os
import sys
import pytest
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


@pytest.fixture
def mock_image():
    """Standard 640x480 RGB test image."""
    return np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)


@pytest.fixture
def mock_boxes():
    """Standard test bounding boxes."""
    return [[100, 100, 200, 200], [300, 300, 400, 400]]


@pytest.fixture
def mock_detector():
    """Detector in mock mode."""
    from analysis.detector import PCBDefectDetector
    return PCBDefectDetector(mode="mock")


@pytest.fixture
def mock_segmentor():
    """Segmentor in mock mode."""
    from analysis.segmentor import PCBDefectSegmentor
    return PCBDefectSegmentor(mode="mock")


@pytest.fixture
def mock_fl_engine():
    """FL engine with default params."""
    from analysis.fl_engine import DefectFLEngine
    return DefectFLEngine(num_classes=6)
