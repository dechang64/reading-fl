# NeuroSync v3 — fMRI 预测建模平台

🧠 **Conformity-Protected · Streamlit Cloud Ready · CPU 无需 GPU**

基于监督对比学习（SCL）+ SHAP 可解释 AI + CROWN Conformity 防御的 fMRI 预测建模平台。

🌐 **在线演示：** https://8ty9i91o1waf.space.minimaxi.com

---

## 功能模块

| 模块 | 说明 |
|------|------|
| 🧮 功能连接矩阵 | AAL90/116/Power264/Shen268 可视化，实时调阈值 |
| 🤖 SCL 模型训练 | 监督对比学习，5折CV，AUROC实时输出 |
| 🔍 SHAP 可解释AI | 真实蜜蜂图 + 神经科学解读 |
| 🧬 多模态融合 | fMRI+BDNF+行为量表三模态对比 |
| 📊 中介/调节分析 | Baron-Kenny框架 + Bootstrap置信区间 |
| 🛡️ Conformity防御 | 🆕 CROWN 置信度门控防御 |
| 📋 临床报告生成 | Conformity-Protected AI 报告 |

---

## 一键部署到 Streamlit Cloud

[![Deploy to Streamlit](https://static.streamlit.io/badges/streamlit_badge_black_heart.svg)](https://share.streamlit.io)

**部署步骤：**
1. Fork 本仓库到你的 GitHub
2. 去 [share.streamlit.io](https://share.streamlit.io) 关联 GitHub 账号
3. 选择 `app.py` 作为入口文件
4. 点击 Deploy — 完成！

---

## 本地运行

```bash
git clone https://github.com/dechang64/NeuroSync.git
cd NeuroSync
pip install -r requirements.txt
streamlit run app.py --server.headless true
```

---

## 对接真实 vLLM（可选，GPU 服务器）

```bash
# 设置环境变量
export USE_VLLM=true
export VLLM_BASE_URL=http://你的服务器:8000/v1
export VLLM_MODEL=Qwen/Qwen2.5-7B-Instruct

streamlit run app.py
```

**服务器上启动 vLLM：**
```bash
pip install vllm
python -m vllm.entrypoints.openai.api_server \
  --model Qwen/Qwen2.5-7B-Instruct \
  --tensor-parallel-size 1 \
  --quantization awq \
  --port 8000
```

---

## CROWN Conformity 防御（核心创新）

**问题：** LLM 生成临床结论时，若参考的文献本身有偏差，LLM 会 Conformity（从众）到错误结论。

**CROWN 解决方案：**
```
1. 独立推理 → 初始答案 + 初始置信度
2. 加入参考资料 → 社会答案 + 社会置信度
3. 检测：置信度下跌 > δ=0.10？
   → 是：CROWN 触发，保留初始答案
   → 否：接受社会答案
```

**效果：** 错误 Conformity 率降低约 25%（Cambridge 2025 论文）。

---

## 技术栈

- **前端：** Streamlit 1.30+
- **可视化：** Plotly 5.18+（可交互图表）
- **ML：** scikit-learn 1.3+（XGBoost / Random Forest / MLP）
- **LLM：** OpenAI-compatible API（支持 Qwen / Llama / GPT）
- **Conformity：** 内置 CROWN 防御模块（零外部依赖）

---

## 项目结构

```
NeuroSync/
├── app.py              ← 完整应用（所有页面）
├── requirements.txt    ← 依赖列表
└── README.md           ← 本文件
```

---

## 参考

- Zhu et al. (2025). *Conformity in Large Language Models*. arXiv:2410.12428
- Whitfield-Gabrieli et al. (2012). *Hyperactivity and hyperconnectivity*. Front. Hum. Neurosci.
- Chen et al. (2023). *COBRE schizophrenia dataset*. NILearn.
