"""fl_training module for Defect-FL."""

import streamlit as st
import numpy as np
from PIL import Image, ImageDraw
import time

from analysis.fl_engine import DefectFLEngine
from utils.constants import FACTORY_PRESETS



def render():
    st.header("联邦学习模拟")
    st.caption("多工厂协同训练，PCB图像数据不出厂")

    st.markdown("""
    ### 🌐 联邦学习架构

    ```
    工厂A (深圳SMT)  ──┐
    工厂B (东莞PCB)  ──┼──→ FedAvg聚合服务器 ──→ 全局模型
    工厂C (苏州HDI)  ──┘
    ```

    **核心原则**: 各工厂仅上传模型梯度，不上传原始PCB图像
    """)

    col_fl1, col_fl2 = st.columns([1, 1])

    with col_fl1:
        st.subheader("⚙️ 训练参数")
        n_rounds = st.slider("联邦轮数", 1, 20, 5)
        n_clients = st.slider("客户端数 (工厂数)", 2, 10, 3)
        local_epochs = st.slider("本地训练轮数", 1, 5, 2)
        lr = st.slider("学习率", 0.0001, 0.01, 0.001, 0.0001, format="%.4f")

        run_fl = st.button("🚀 开始联邦训练", type="primary", use_container_width=True)

    with col_fl2:
        st.subheader("📊 工厂数据分布 (Non-IID)")
        factory_data = {}
        for i in range(n_clients):
            fname = list(FACTORY_PRESETS.keys())[i % len(FACTORY_PRESETS)]
            # Simulate Non-IID: each factory has different defect distribution
            np.random.seed(42 + i)
            dist = np.random.dirichlet(np.ones(6) * (0.5 + i * 0.3))
            factory_data[fname] = dist

        st.dataframe(
            {FACTORY_PRESETS[k]["name"]: [f"{v:.1%}" for v in vs] for k, vs in factory_data.items()},
            index=DEFECT_CLASSES,
        )

    if run_fl:
        with st.spinner("🌐 联邦训练中..."):
            engine = DefectFLEngine(
                num_classes=6,
                lr=lr,
                local_epochs=local_epochs,
            )

            # Simulate federated training with mock data
            progress_text = st.empty()
            history = []

            for rnd in range(n_rounds):
                progress_text.text(f"联邦轮次 {rnd+1}/{n_rounds}...")

                # Mock training metrics
                np.random.seed(42 + rnd)
                client_metrics = []
                for c in range(n_clients):
                    client_metrics.append({
                        "client_id": c,
                        "train_loss": max(0.1, 2.0 - rnd * 0.15 + np.random.randn() * 0.1),
                        "train_acc": min(0.99, 0.5 + rnd * 0.08 + np.random.randn() * 0.03),
                        "n_samples": np.random.randint(500, 2000),
                    })

                round_data = {
                    "round": rnd + 1,
                    "avg_train_loss": np.mean([m["train_loss"] for m in client_metrics]),
                    "avg_train_acc": np.mean([m["train_acc"] for m in client_metrics]),
                    "val_loss": max(0.1, 1.8 - rnd * 0.14 + np.random.randn() * 0.08),
                    "val_acc": min(0.99, 0.55 + rnd * 0.07 + np.random.randn() * 0.02),
                    "client_metrics": client_metrics,
                }
                history.append(round_data)
                time.sleep(0.3)  # Simulate training time

            progress_text.text("✅ 联邦训练完成！")

        # Plot training curves
        st.subheader("📈 训练曲线")

        col_p1, col_p2 = st.columns(2)

        with col_p1:
            rounds = [h["round"] for h in history]
            train_acc = [h["avg_train_acc"] for h in history]
            val_acc = [h["val_acc"] for h in history]

            # Simple chart using st.line_chart
            chart_data = {
                "训练准确率": train_acc,
                "验证准确率": val_acc,
            }
            st.line_chart(chart_data, use_container_width=True)
            st.caption("准确率曲线")

        with col_p2:
            train_loss = [h["avg_train_loss"] for h in history]
            val_loss = [h["val_loss"] for h in history]

            chart_data = {
                "训练损失": train_loss,
                "验证损失": val_loss,
            }
            st.line_chart(chart_data, use_container_width=True)
            st.caption("损失曲线")

        # Final metrics
        final = history[-1]
        m1, m2, m3, m4 = st.columns(4)
        with m1:
            st.metric("最终验证准确率", f"{final['val_acc']:.1%}")
        with m2:
            st.metric("最终验证损失", f"{final['val_loss']:.3f}")
        with m3:
            st.metric("联邦轮数", n_rounds)
        with m4:
            st.metric("参与工厂数", n_clients)

        # Per-client breakdown
        st.subheader("🏭 各工厂训练详情")
        for cm in final["client_metrics"]:
            fname = list(FACTORY_PRESETS.keys())[cm["client_id"] % len(FACTORY_PRESETS)]
            fi = FACTORY_PRESETS[fname]
            st.markdown(f"""
            **{fi['name']}** — 样本数: {cm['n_samples']:,} | 损失: {cm['train_loss']:.3f} | 准确率: {cm['train_acc']:.1%}
            """)




    # ============================================================
    # Tab 4: Feature Search (DINOv2 + HNSW)
    # ============================================================
