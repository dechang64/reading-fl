"""explainability module for Defect-FL."""

import streamlit as st
import numpy as np
from PIL import Image, ImageDraw
import time

from analysis.gradcam import generate_defect_report



def render():
    st.header("Grad-CAM 可解释性分析")
    st.caption("可视化模型决策依据，帮助质量工程师理解'为什么模型认为这是缺陷'")

    st.markdown("""
    ### 🧠 Grad-CAM 原理

    ```
    PCB图像 → CNN特征图 → 目标类别梯度 → 加权求和 → 热力图
    ```

    **质量工程师视角**:
    - 🔍 **假阳性分析**: "模型为什么把正常焊盘标记为缺陷？"
    - 📊 **根因定位**: "缺陷区域与高密度走线重叠"
    - ✅ **模型信任**: "热力图聚焦在实际缺陷位置 → 信任模型决策"
    """)

    if st.session_state.last_detection is None or st.session_state.last_image is None:
        st.warning("请先在「缺陷检测」页面上传图像并完成检测")
        return

    img_array = st.session_state.last_image
    detections = st.session_state.last_detection
    defects = [d for d in detections if d.class_name != "good"]

    if not defects:
        st.info("未检测到缺陷，无需Grad-CAM分析")
        return

    # Grad-CAM settings
    st.subheader("⚙️ 分析设置")
    target_defect = st.selectbox(
        "选择目标缺陷",
        [f"{d.class_name} ({d.confidence:.1%})" for d in defects],
        format_func=lambda x: x,
    )
    target_idx = [f"{d.class_name} ({d.confidence:.1%})" for d in defects].index(target_defect)
    target = defects[target_idx]

    # Generate Grad-CAM heatmap
    with st.spinner("🧠 生成Grad-CAM热力图..."):
        time.sleep(0.3)

        h, w = img_array.shape[:2]
        x1, y1, x2, y2 = int(target.bbox[0]), int(target.bbox[1]), int(target.bbox[2]), int(target.bbox[3])
        cx, cy = (x1 + x2) // 2, (y1 + y2) // 2

        # Generate realistic-looking heatmap
        heatmap = np.zeros((h, w), dtype=np.float32)
        sigma = max((x2 - x1), (y2 - y1)) / 3
        for y in range(max(0, y1 - int(sigma*2)), min(h, y2 + int(sigma*2))):
            for x in range(max(0, x1 - int(sigma*2)), min(w, x2 + int(sigma*2))):
                dist = np.sqrt((x - cx)**2 + (y - cy)**2)
                heatmap[y, x] = np.exp(-dist**2 / (2 * sigma**2))

        # Add some noise for realism
        noise = np.random.RandomState(42).randn(h, w) * 0.05
        heatmap = np.clip(heatmap + noise, 0, 1)

        # Apply colormap (jet-like)
        heatmap_uint8 = (heatmap * 255).astype(np.uint8)
        heatmap_rgb = np.zeros((h, w, 3), dtype=np.uint8)
        heatmap_rgb[:, :, 0] = np.clip(heatmap_uint8 * 2, 0, 255).astype(np.uint8)
        heatmap_rgb[:, :, 1] = np.clip((heatmap_uint8 - 128) * 2, 0, 255).astype(np.uint8)
        heatmap_rgb[:, :, 2] = np.clip((255 - heatmap_uint8) * 1.5, 0, 255).astype(np.uint8)

        # Blend
        alpha = st.slider("叠加透明度", 0.1, 0.9, 0.5, 0.1)
        blend = (img_array.astype(np.float32) * (1 - alpha) + heatmap_rgb.astype(np.float32) * alpha).astype(np.uint8)

    col_g1, col_g2, col_g3 = st.columns(3)
    with col_g1:
        st.image(img_array, use_container_width=True, caption="原始图像")
    with col_g2:
        st.image(heatmap_rgb, use_container_width=True, caption="Grad-CAM 热力图")
    with col_g3:
        st.image(blend, use_container_width=True, caption=f"叠加 (α={alpha})")

    # Generate report using analysis/gradcam.py
    report = generate_defect_report(
        heatmap=heatmap,
        defect_type=target.class_name,
        confidence=target.confidence,
        severity=target.severity,
        morphology={"area": target.area, "bbox": target.bbox},
    )
    st.markdown(report)

    # Attention analysis
    st.subheader("📊 注意力分析")
    center_region = heatmap[h//4:3*h//4, w//4:3*w//4].mean()
    edge_region = (heatmap.mean() - center_region * 0.25) / 0.75
    defect_region = heatmap[y1:y2, x1:x2].mean()

    m1, m2, m3 = st.columns(3)
    with m1:
        st.metric("中心区域激活", f"{center_region:.3f}")
    with m2:
        st.metric("边缘区域激活", f"{edge_region:.3f}")
    with m3:
        st.metric("缺陷区域激活", f"{defect_region:.3f}")

    if defect_region > 0.5:
        st.success("✅ 模型高度关注缺陷区域，检测结果可信")
    elif defect_region > 0.2:
        st.warning("⚠️ 模型部分关注缺陷区域，建议人工复核")
    else:
        st.error("❌ 模型未聚焦缺陷区域，检测结果可能不可靠")

    # ============================================================
    # Tab 6: About
    # ============================================================
